import bpy
import json
import os
import time
import base64
import tempfile
import re
from bpy.app.handlers import persistent

from ..core import gimp_manager
from . import preferences as blendgimp_preferences
from ..ipc.connection import (
    connection_manager,
    direct_paint_owns_refresh,
    GimpEngineShutdownRefusedError,
    GimpImageNotFoundError,
    set_direct_paint_refresh_owner,
)
from ..painting.stroke_tool import (
    BLENDGIMP_OT_direct_gimp_brush_paint,
    cache_blender_texture_paint_color,
)


try:
    import numpy as np
except Exception:
    np = None


# Fast full-image float mirrors used by dirty-region updates.
# Object Paint and Auto Sync share this path so a tight GIMP rectangle can be
# patched in CPU memory and published through one bpy_prop_array.foreach_set()
# call instead of hundreds of slow RNA slice assignments.
_DIRTY_PIXEL_CACHE = {}


def _dirty_cache_key(blender_image, image_id, sync_token, width, height):
    return (
        int(image_id),
        str(sync_token or ""),
        int(width),
        int(height),
        int(blender_image.as_pointer()),
    )


def _drop_dirty_pixel_cache_for_image(image_id):
    image_id = int(image_id)
    for key in list(_DIRTY_PIXEL_CACHE.keys()):
        if int(key[0]) == image_id:
            _DIRTY_PIXEL_CACHE.pop(key, None)


# ============================================================
# GIMP ENGINE LIFECYCLE RUNTIME
# ============================================================

ENGINE_LIFECYCLE_POLL_INTERVAL = 0.5
ENGINE_HEALTHCHECK_INTERVAL = 5.0
ENGINE_CONNECT_BACKOFF_MAX = 5.0
ENGINE_RESTART_BACKOFF_MAX = 30.0

_ENGINE_LIFECYCLE_RUNTIME = {
    "next_connect_at": 0.0,
    "next_healthcheck_at": 0.0,
    "next_restart_at": 0.0,
    "connect_failures": 0,
    "restart_failures": 0,
}

_EXIT_PRE_HANDLED = False


def _scene_from_context(context=None):
    """Resolve the active Scene even when invoked from Blender Preferences."""
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        scene = getattr(bpy.context, "scene", None)
    if scene is None and getattr(bpy.data, "scenes", None):
        try:
            scene = bpy.data.scenes[0]
        except Exception:
            scene = None
    return scene


def reset_engine_lifecycle_runtime():
    _ENGINE_LIFECYCLE_RUNTIME.update(
        {
            "next_connect_at": 0.0,
            "next_healthcheck_at": 0.0,
            "next_restart_at": 0.0,
            "connect_failures": 0,
            "restart_failures": 0,
        }
    )


# ============================================================
# AUTOMATIC TEXTURE SYNC RUNTIME
# ============================================================

AUTO_SYNC_POLL_INTERVAL = 0.5

_AUTO_SYNC_RUNTIME = {
    "image_id": -1,
    "last_seen_revision": None,
    "last_synced_revision": None,
    "pending_revision": None,
    "pending_since": 0.0,
}

BLENDER_PAINT_SYNC_POLL_INTERVAL = 0.10
BLENDER_PAINT_LAYER_NAME = "BlendGimp Paint"

_BLENDER_PAINT_SYNC_RUNTIME = {
    "image_id": -1,
    "layer_id": -1,
    "baseline": None,
    "pending_pixels": None,
    "pending_bbox": None,
    "pending_since": 0.0,
    "buffer_image_name": "",
}


def reset_blender_paint_sync_runtime(
    image_id=-1,
    layer_id=-1,
    baseline=None
):
    _BLENDER_PAINT_SYNC_RUNTIME[
        "image_id"
    ] = int(
        image_id
    )

    _BLENDER_PAINT_SYNC_RUNTIME[
        "layer_id"
    ] = int(
        layer_id
    )

    _BLENDER_PAINT_SYNC_RUNTIME[
        "baseline"
    ] = baseline

    _BLENDER_PAINT_SYNC_RUNTIME[
        "pending_pixels"
    ] = None

    _BLENDER_PAINT_SYNC_RUNTIME[
        "pending_bbox"
    ] = None

    _BLENDER_PAINT_SYNC_RUNTIME[
        "pending_since"
    ] = 0.0

    if baseline is None and int(image_id) < 0:
        _BLENDER_PAINT_SYNC_RUNTIME["buffer_image_name"] = ""


def reset_auto_sync_runtime(
    image_id=-1,
    revision=None
):
    _AUTO_SYNC_RUNTIME[
        "image_id"
    ] = int(image_id)

    _AUTO_SYNC_RUNTIME[
        "last_seen_revision"
    ] = (
        None
        if revision is None
        else int(revision)
    )

    _AUTO_SYNC_RUNTIME[
        "last_synced_revision"
    ] = (
        None
        if revision is None
        else int(revision)
    )

    _AUTO_SYNC_RUNTIME[
        "pending_revision"
    ] = None

    _AUTO_SYNC_RUNTIME[
        "pending_since"
    ] = 0.0


# ============================================================
# GIMP LAYER MODES
# ============================================================

BLENDGIMP_LAYER_MODE_ITEMS = [
    ("NORMAL_LEGACY", "Normal (Legacy)", "GIMP Normal (Legacy) blend mode"),
    ("DISSOLVE", "Dissolve", "GIMP Dissolve blend mode"),
    ("BEHIND_LEGACY", "Behind (Legacy)", "GIMP Behind (Legacy) blend mode"),
    ("MULTIPLY_LEGACY", "Multiply (Legacy)", "GIMP Multiply (Legacy) blend mode"),
    ("SCREEN_LEGACY", "Screen (Legacy)", "GIMP Screen (Legacy) blend mode"),
    ("OVERLAY_LEGACY", "Overlay (Legacy)", "GIMP Overlay (Legacy) blend mode"),
    ("DIFFERENCE_LEGACY", "Difference (Legacy)", "GIMP Difference (Legacy) blend mode"),
    ("ADDITION_LEGACY", "Addition (Legacy)", "GIMP Addition (Legacy) blend mode"),
    ("SUBTRACT_LEGACY", "Subtract (Legacy)", "GIMP Subtract (Legacy) blend mode"),
    ("DARKEN_ONLY_LEGACY", "Darken Only (Legacy)", "GIMP Darken Only (Legacy) blend mode"),
    ("LIGHTEN_ONLY_LEGACY", "Lighten Only (Legacy)", "GIMP Lighten Only (Legacy) blend mode"),
    ("HSV_HUE_LEGACY", "HSV Hue (Legacy)", "GIMP HSV Hue (Legacy) blend mode"),
    ("HSV_SATURATION_LEGACY", "HSV Saturation (Legacy)", "GIMP HSV Saturation (Legacy) blend mode"),
    ("HSL_COLOR_LEGACY", "HSL Color (Legacy)", "GIMP HSL Color (Legacy) blend mode"),
    ("HSV_VALUE_LEGACY", "HSV Value (Legacy)", "GIMP HSV Value (Legacy) blend mode"),
    ("DIVIDE_LEGACY", "Divide (Legacy)", "GIMP Divide (Legacy) blend mode"),
    ("DODGE_LEGACY", "Dodge (Legacy)", "GIMP Dodge (Legacy) blend mode"),
    ("BURN_LEGACY", "Burn (Legacy)", "GIMP Burn (Legacy) blend mode"),
    ("HARDLIGHT_LEGACY", "Hardlight (Legacy)", "GIMP Hardlight (Legacy) blend mode"),
    ("SOFTLIGHT_LEGACY", "Softlight (Legacy)", "GIMP Softlight (Legacy) blend mode"),
    ("GRAIN_EXTRACT_LEGACY", "Grain Extract (Legacy)", "GIMP Grain Extract (Legacy) blend mode"),
    ("GRAIN_MERGE_LEGACY", "Grain Merge (Legacy)", "GIMP Grain Merge (Legacy) blend mode"),
    ("COLOR_ERASE_LEGACY", "Color Erase (Legacy)", "GIMP Color Erase (Legacy) blend mode"),
    ("OVERLAY", "Overlay", "GIMP Overlay blend mode"),
    ("LCH_HUE", "LCh Hue", "GIMP LCh Hue blend mode"),
    ("LCH_CHROMA", "LCh Chroma", "GIMP LCh Chroma blend mode"),
    ("LCH_COLOR", "LCh Color", "GIMP LCh Color blend mode"),
    ("LCH_LIGHTNESS", "LCh Lightness", "GIMP LCh Lightness blend mode"),
    ("NORMAL", "Normal", "GIMP Normal blend mode"),
    ("BEHIND", "Behind", "GIMP Behind blend mode"),
    ("MULTIPLY", "Multiply", "GIMP Multiply blend mode"),
    ("SCREEN", "Screen", "GIMP Screen blend mode"),
    ("DIFFERENCE", "Difference", "GIMP Difference blend mode"),
    ("ADDITION", "Addition", "GIMP Addition blend mode"),
    ("SUBTRACT", "Subtract", "GIMP Subtract blend mode"),
    ("DARKEN_ONLY", "Darken Only", "GIMP Darken Only blend mode"),
    ("LIGHTEN_ONLY", "Lighten Only", "GIMP Lighten Only blend mode"),
    ("HSV_HUE", "HSV Hue", "GIMP HSV Hue blend mode"),
    ("HSV_SATURATION", "HSV Saturation", "GIMP HSV Saturation blend mode"),
    ("HSL_COLOR", "HSL Color", "GIMP HSL Color blend mode"),
    ("HSV_VALUE", "HSV Value", "GIMP HSV Value blend mode"),
    ("DIVIDE", "Divide", "GIMP Divide blend mode"),
    ("DODGE", "Dodge", "GIMP Dodge blend mode"),
    ("BURN", "Burn", "GIMP Burn blend mode"),
    ("HARDLIGHT", "Hardlight", "GIMP Hardlight blend mode"),
    ("SOFTLIGHT", "Softlight", "GIMP Softlight blend mode"),
    ("GRAIN_EXTRACT", "Grain Extract", "GIMP Grain Extract blend mode"),
    ("GRAIN_MERGE", "Grain Merge", "GIMP Grain Merge blend mode"),
    ("VIVID_LIGHT", "Vivid Light", "GIMP Vivid Light blend mode"),
    ("PIN_LIGHT", "Pin Light", "GIMP Pin Light blend mode"),
    ("LINEAR_LIGHT", "Linear Light", "GIMP Linear Light blend mode"),
    ("HARD_MIX", "Hard Mix", "GIMP Hard Mix blend mode"),
    ("EXCLUSION", "Exclusion", "GIMP Exclusion blend mode"),
    ("LINEAR_BURN", "Linear Burn", "GIMP Linear Burn blend mode"),
    ("LUMA_DARKEN_ONLY", "Luma Darken Only", "GIMP Luma Darken Only blend mode"),
    ("LUMA_LIGHTEN_ONLY", "Luma Lighten Only", "GIMP Luma Lighten Only blend mode"),
    ("LUMINANCE", "Luminance", "GIMP Luminance blend mode"),
    ("COLOR_ERASE", "Color Erase", "GIMP Color Erase blend mode"),
    ("ERASE", "Erase", "GIMP Erase blend mode"),
    ("MERGE", "Merge", "GIMP Merge blend mode"),
    ("SPLIT", "Split", "GIMP Split blend mode"),
    ("PASS_THROUGH", "Pass Through", "GIMP Pass Through blend mode"),
    ("REPLACE", "Replace", "GIMP Replace blend mode"),
    ("OVERWRITE", "Overwrite", "GIMP Overwrite blend mode"),
]


def blendgimp_layer_mode_label(
    mode_name
):

    mode_name = str(
        mode_name or ""
    )

    for identifier, label, description in (
        BLENDGIMP_LAYER_MODE_ITEMS
    ):

        if identifier == mode_name:
            return label

    return mode_name or "Unknown"


# ============================================================
# IMAGE RESULT HELPERS
# ============================================================

def clear_image_results(
    scene
):

    scene.blendgimp_images_queried = False
    scene.blendgimp_image_count = 0
    scene.blendgimp_images_json = "[]"
    scene.blendgimp_layers_json = "{}"
    scene.blendgimp_texture_sync_json = "{}"


def clear_gimp_session_bindings(
    scene,
    status="No GIMP image selected"
):
    """Clear IDs that are valid only for one GIMP process session."""

    clear_image_results(
        scene
    )

    scene.blendgimp_auto_sync_enabled = False
    scene.blendgimp_auto_sync_image_id = -1
    scene.blendgimp_auto_sync_revision = 0
    scene.blendgimp_auto_sync_status = str(status)
    scene.blendgimp_auto_sync_detector = ""

    scene.blendgimp_blender_paint_sync_enabled = False
    scene.blendgimp_blender_paint_sync_image_id = -1
    scene.blendgimp_blender_paint_sync_layer_id = -1
    scene.blendgimp_blender_paint_sync_status = "Off"

    set_direct_paint_refresh_owner(
        False
    )
    reset_auto_sync_runtime()
    reset_blender_paint_sync_runtime()


def store_engine_connection(
    scene,
    response
):
    """Store a successful HELLO/READY handshake in Blender scene state."""

    scene.blendgimp_connected = True

    scene.blendgimp_protocol_version = int(
        response.get(
            "protocol",
            0
        )
    )

    scene.blendgimp_remote_version = str(
        response.get(
            "blendgimp_version",
            response.get(
                "server",
                ""
            )
        )
    )

    scene.blendgimp_runtime_gimp_version = str(
        response.get(
            "gimp_version",
            ""
        )
    )

    scene.blendgimp_engine_state = (
        gimp_manager.ENGINE_STATE_CONNECTED
    )
    scene.blendgimp_engine_last_error = ""

    gimp_manager.mark_engine_connected()

    _ENGINE_LIFECYCLE_RUNTIME[
        "connect_failures"
    ] = 0
    _ENGINE_LIFECYCLE_RUNTIME[
        "restart_failures"
    ] = 0
    _ENGINE_LIFECYCLE_RUNTIME[
        "next_restart_at"
    ] = 0.0
    _ENGINE_LIFECYCLE_RUNTIME[
        "next_healthcheck_at"
    ] = (
        time.monotonic()
        + ENGINE_HEALTHCHECK_INTERVAL
    )


def clear_engine_connection(
    scene,
    clear_results=True
):
    scene.blendgimp_connected = False
    scene.blendgimp_protocol_version = 0
    scene.blendgimp_remote_version = ""
    scene.blendgimp_runtime_gimp_version = ""

    if clear_results:
        clear_image_results(
            scene
        )


def detect_gimp_for_scene(scene, clear_on_failure=True):
    """Detect GIMP and cache the executable/version on the active scene.

    Phase 7.0 usability rule: detection is an implementation detail, not a
    required production-workflow step. The Start GIMP operator calls this
    automatically whenever the cached executable is missing or stale.
    """

    gimp_path = gimp_manager.find_gimp()

    if gimp_path and os.path.isfile(gimp_path):
        version = gimp_manager.get_gimp_version(gimp_path)
        scene.blendgimp_gimp_path = gimp_path
        scene.blendgimp_gimp_version = version or "Unknown Version"
        scene.blendgimp_gimp_detected = True
        scene.blendgimp_engine_last_error = ""
        print(f"BLENDGIMP: GIMP auto-detected at {gimp_path}")
        print(f"BLENDGIMP: Detected GIMP version = {version}")
        return True, gimp_path, version

    if clear_on_failure:
        scene.blendgimp_gimp_detected = False
        scene.blendgimp_gimp_path = ""
        scene.blendgimp_gimp_version = ""
        scene.blendgimp_gimp_running = False
        scene.blendgimp_connected = False

    return False, None, None


def start_scene_engine(
    scene,
    automatic=False
):
    """Detect if needed, start the selected GIMP mode, then connect.

    The user should never have to press Detect GIMP before Start GIMP.
    """

    gimp_path = str(scene.blendgimp_gimp_path or "")

    # First-run and stale-path behavior: one Start GIMP click performs the
    # detection step automatically, stores the result, and continues launch.
    if not gimp_path or not os.path.isfile(gimp_path):
        detected, gimp_path, _version = detect_gimp_for_scene(scene)
        if not detected:
            scene.blendgimp_engine_state = gimp_manager.ENGINE_STATE_FAILED
            scene.blendgimp_engine_last_error = (
                "GIMP could not be detected automatically. "
                "Open BlendGimp Preferences only if you need to troubleshoot the installation."
            )
            return False, None
    else:
        scene.blendgimp_gimp_detected = True

    process_was_running = (
        gimp_manager.is_gimp_running()
    )

    selected_mode = blendgimp_preferences.engine_mode(scene=scene)
    if hasattr(scene, "blendgimp_engine_mode"):
        scene.blendgimp_engine_mode = selected_mode

    success, pid = gimp_manager.launch_gimp(
        gimp_path,
        selected_mode
    )

    if not success:
        snapshot = (
            gimp_manager.get_engine_snapshot()
        )
        scene.blendgimp_gimp_running = False
        scene.blendgimp_engine_state = str(
            snapshot.get(
                "state",
                gimp_manager.ENGINE_STATE_FAILED
            )
        )
        scene.blendgimp_engine_last_error = str(
            snapshot.get(
                "last_error",
                "Could not launch GIMP"
            )
        )
        return False, None

    if not process_was_running:
        clear_gimp_session_bindings(
            scene,
            status=(
                "Waiting for a Blender-owned texture"
            )
        )

    scene.blendgimp_engine_should_run = True
    scene.blendgimp_gimp_running = True
    scene.blendgimp_engine_state = (
        gimp_manager.ENGINE_STATE_STARTING
    )
    scene.blendgimp_engine_last_error = ""

    if automatic:
        scene.blendgimp_engine_restart_count += 1

    _ENGINE_LIFECYCLE_RUNTIME[
        "next_connect_at"
    ] = time.monotonic() + 0.25
    _ENGINE_LIFECYCLE_RUNTIME[
        "next_restart_at"
    ] = 0.0

    return True, pid


def connect_scene_engine(
    scene
):
    """Attempt one handshake; the lifecycle timer owns retry scheduling."""

    scene.blendgimp_engine_state = (
        gimp_manager.ENGINE_STATE_CONNECTING
    )
    gimp_manager.mark_engine_connecting()

    try:
        response = (
            connection_manager.connect()
        )

        store_engine_connection(
            scene,
            response
        )

        clear_image_results(
            scene
        )

        print(
            "BLENDGIMP: "
            "GIMP engine connection established"
        )

        return response

    except Exception as exc:
        clear_engine_connection(
            scene
        )

        gimp_manager.mark_engine_disconnected(
            str(exc)
        )

        snapshot = (
            gimp_manager.get_engine_snapshot()
        )

        scene.blendgimp_engine_state = str(
            snapshot.get(
                "state",
                gimp_manager.ENGINE_STATE_DISCONNECTED
            )
        )
        scene.blendgimp_engine_last_error = str(
            exc
        )

        raise


def stop_scene_engine(
    scene,
    force=False
):
    """Disconnect Blender and stop only the GIMP process BlendGimp owns."""

    scene.blendgimp_engine_should_run = False

    graceful_requested = False

    if connection_manager.is_connected():
        try:
            connection_manager.shutdown_engine(
                force=bool(force)
            )
            graceful_requested = True

        except GimpEngineShutdownRefusedError as exc:
            scene.blendgimp_engine_should_run = True
            scene.blendgimp_engine_state = (
                gimp_manager.ENGINE_STATE_CONNECTED
            )
            scene.blendgimp_engine_last_error = str(exc)
            print(
                "BLENDGIMP: "
                f"GIMP shutdown refused: {exc}"
            )
            return False, None, False

        except Exception as exc:
            # If the plug-in or socket disappeared, the process manager still
            # performs its bounded platform-termination fallback.
            print(
                "BLENDGIMP: "
                "Clean shutdown request failed; "
                f"using fallback: {exc}"
            )

    connection_manager.disconnect()
    clear_engine_connection(
        scene
    )

    success, exit_code, forced = (
        gimp_manager.stop_gimp(
            graceful_requested=graceful_requested
        )
    )

    if success:
        clear_gimp_session_bindings(
            scene,
            status="Engine stopped"
        )

    reset_engine_lifecycle_runtime()

    scene.blendgimp_gimp_running = (
        gimp_manager.is_gimp_running()
    )

    snapshot = (
        gimp_manager.get_engine_snapshot()
    )
    scene.blendgimp_engine_state = str(
        snapshot.get(
            "state",
            gimp_manager.ENGINE_STATE_STOPPED
        )
    )
    scene.blendgimp_engine_last_error = str(
        snapshot.get(
            "last_error",
            ""
        )
    )

    return success, exit_code, forced


def blendgimp_engine_lifecycle_timer():
    """Monitor, reconnect, and recover the persistent GIMP engine."""

    if not hasattr(
        bpy.types.Scene,
        "blendgimp_engine_state"
    ):
        return None

    scene = getattr(
        bpy.context,
        "scene",
        None
    )

    if scene is None:
        return ENGINE_LIFECYCLE_POLL_INTERVAL

    now = time.monotonic()
    running = (
        gimp_manager.is_gimp_running()
    )

    scene.blendgimp_gimp_running = running

    # A socket can look connected until the next read. Use a quiet, infrequent
    # PING so disappearance is detected even when painting and Auto Sync are
    # idle. During live 2D/3D painting the paint path itself continuously proves
    # the connection is healthy, and a main-thread PING could wait behind the
    # asynchronous paint worker's serialized socket lock. Skip that healthcheck
    # until paint releases refresh ownership so Blender's UI never stalls for a
    # heartbeat while the artist is drawing.
    if connection_manager.is_connected() and direct_paint_owns_refresh():
        scene.blendgimp_connected = True
        scene.blendgimp_engine_state = gimp_manager.ENGINE_STATE_CONNECTED
        return ENGINE_LIFECYCLE_POLL_INTERVAL

    if connection_manager.is_connected():
        if now >= float(
            _ENGINE_LIFECYCLE_RUNTIME.get(
                "next_healthcheck_at",
                0.0
            )
        ):
            try:
                connection_manager.ping(
                    quiet=True
                )

                store_engine_connection(
                    scene,
                    {
                        "protocol": connection_manager.remote_protocol,
                        "blendgimp_version": connection_manager.remote_version,
                        "gimp_version": connection_manager.remote_gimp_version,
                    }
                )

            except Exception as exc:
                clear_engine_connection(
                    scene
                )
                gimp_manager.mark_engine_disconnected(
                    str(exc)
                )
                scene.blendgimp_engine_last_error = str(
                    exc
                )

        else:
            scene.blendgimp_connected = True
            scene.blendgimp_engine_state = (
                gimp_manager.ENGINE_STATE_CONNECTED
            )

    if connection_manager.is_connected():
        return ENGINE_LIFECYCLE_POLL_INTERVAL

    scene.blendgimp_connected = False

    if not scene.blendgimp_engine_should_run:
        snapshot = (
            gimp_manager.get_engine_snapshot()
        )
        scene.blendgimp_engine_state = str(
            snapshot.get(
                "state",
                gimp_manager.ENGINE_STATE_STOPPED
            )
        )
        return ENGINE_LIFECYCLE_POLL_INTERVAL

    if running:
        scene.blendgimp_engine_state = (
            gimp_manager.ENGINE_STATE_CONNECTING
        )
        gimp_manager.mark_engine_connecting()

        if now >= float(
            _ENGINE_LIFECYCLE_RUNTIME.get(
                "next_connect_at",
                0.0
            )
        ):
            try:
                connect_scene_engine(
                    scene
                )

            except Exception as exc:
                failures = int(
                    _ENGINE_LIFECYCLE_RUNTIME.get(
                        "connect_failures",
                        0
                    )
                ) + 1

                _ENGINE_LIFECYCLE_RUNTIME[
                    "connect_failures"
                ] = failures

                delay = min(
                    ENGINE_CONNECT_BACKOFF_MAX,
                    0.5 * (2 ** min(failures - 1, 4))
                )

                _ENGINE_LIFECYCLE_RUNTIME[
                    "next_connect_at"
                ] = now + delay

                print(
                    "BLENDGIMP: "
                    "Engine connection not ready; "
                    f"retrying in {delay:.1f}s: {exc}"
                )

        return ENGINE_LIFECYCLE_POLL_INTERVAL

    # The owned process exited. Close any stale socket state and either wait
    # in FAILED or schedule an automatic restart with bounded backoff.
    connection_manager.disconnect()
    clear_engine_connection(
        scene
    )

    snapshot = (
        gimp_manager.get_engine_snapshot()
    )
    scene.blendgimp_engine_last_error = str(
        snapshot.get(
            "last_error",
            "GIMP engine is not running"
        )
    )

    if not blendgimp_preferences.automatic_recovery_enabled(scene=scene):
        scene.blendgimp_engine_state = (
            gimp_manager.ENGINE_STATE_FAILED
        )
        return ENGINE_LIFECYCLE_POLL_INTERVAL

    next_restart_at = float(
        _ENGINE_LIFECYCLE_RUNTIME.get(
            "next_restart_at",
            0.0
        )
    )

    if next_restart_at <= 0.0:
        failures = int(
            _ENGINE_LIFECYCLE_RUNTIME.get(
                "restart_failures",
                0
            )
        )
        delay = min(
            ENGINE_RESTART_BACKOFF_MAX,
            1.0 * (2 ** min(failures, 5))
        )
        _ENGINE_LIFECYCLE_RUNTIME[
            "next_restart_at"
        ] = now + delay
        scene.blendgimp_engine_state = (
            gimp_manager.ENGINE_STATE_DISCONNECTED
        )
        return ENGINE_LIFECYCLE_POLL_INTERVAL

    if now >= next_restart_at:
        failures = int(
            _ENGINE_LIFECYCLE_RUNTIME.get(
                "restart_failures",
                0
            )
        ) + 1
        _ENGINE_LIFECYCLE_RUNTIME[
            "restart_failures"
        ] = failures

        success, _pid = start_scene_engine(
            scene,
            automatic=True
        )

        if not success:
            _ENGINE_LIFECYCLE_RUNTIME[
                "next_restart_at"
            ] = 0.0

    return ENGINE_LIFECYCLE_POLL_INTERVAL


def get_stored_images(
    scene
):

    try:

        images = json.loads(
            scene.blendgimp_images_json
            or
            "[]"
        )

        if isinstance(
            images,
            list
        ):

            return images

    except Exception:

        pass

    return []


def _refresh_gimp_images_snapshot(scene):
    response = connection_manager.get_images()
    images = response.get("images", [])
    scene.blendgimp_images_queried = True
    scene.blendgimp_image_count = len(images)
    scene.blendgimp_images_json = json.dumps(
        images,
        ensure_ascii=False
    )
    return images


def _safe_xcf_component(value, fallback="BlendGimp"): 
    text = str(value or "").strip() or str(fallback)
    text = re.sub(r'[<>:"/\\|?*]+', "_", text)
    text = re.sub(r"\s+", " ", text).strip().rstrip(".")
    return text[:96] or str(fallback)


def _default_blendgimp_save_directory():
    if bpy.data.filepath:
        return os.path.join(
            os.path.dirname(bpy.data.filepath),
            "BlendGimp Textures"
        )

    documents = os.path.join(
        os.path.expanduser("~"),
        "Documents"
    )
    base = documents if os.path.isdir(documents) else os.path.expanduser("~")
    return os.path.join(base, "BlendGimp Textures")


def _default_xcf_filename(scene, image):
    image_id = int(image.get("id", -1))
    sync_result = get_texture_sync_result(scene, image_id) or {}
    owner = _safe_xcf_component(
        sync_result.get("owner_object", ""),
        fallback="Object"
    )
    image_name = _safe_xcf_component(
        image.get("name", ""),
        fallback=f"Image-{image_id}"
    )
    return f"{owner}__{image_name}.xcf"


def _store_saved_xcf_path(scene, image_id, response):
    image_id = int(image_id)
    path = str(response.get("path", "") or "")
    sync_token = str(response.get("sync_token", "") or "")

    result = dict(
        get_texture_sync_result(scene, image_id)
        or {}
    )
    if path:
        result["xcf_path"] = path
    if sync_token:
        result["sync_token"] = sync_token
    if result:
        store_texture_sync_result(scene, image_id, result)

    blender_image = _find_blendgimp_image(
        image_id,
        sync_token or result.get("sync_token", "")
    )
    if blender_image is not None and path:
        blender_image["blendgimp_xcf_path"] = path
        blender_image.update()


def save_gimp_image_xcf(scene, image_id, path=""):
    response = connection_manager.save_image(
        int(image_id),
        str(path or "")
    )
    _store_saved_xcf_path(scene, image_id, response)
    try:
        _refresh_gimp_images_snapshot(scene)
    except Exception as exc:
        print(
            "BLENDGIMP: Saved XCF but could not refresh image list: "
            f"{exc}"
        )
    return response


def _recovery_save_directory():
    if bpy.data.filepath:
        base = os.path.dirname(bpy.data.filepath)
        return os.path.join(base, "BlendGimp Recovery")

    documents = os.path.join(os.path.expanduser("~"), "Documents")
    base = documents if os.path.isdir(documents) else os.path.expanduser("~")
    return os.path.join(base, "BlendGimp Recovery")


def _save_dirty_images_for_exit(scene):
    """Save dirty headless documents before Blender exits.

    Existing XCF documents save in place. Newly created unsaved documents are
    written as recovery XCF files so Blender never has to silently abandon an
    invisible dirty GIMP process.
    """

    images = _refresh_gimp_images_snapshot(scene)
    dirty_images = [image for image in images if bool(image.get("dirty", False))]
    if not dirty_images:
        return {"saved": 0, "recovery": 0, "failed": []}

    recovery_dir = _recovery_save_directory()
    os.makedirs(recovery_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    saved = 0
    recovery = 0
    failed = []
    used_paths = set()

    for image in dirty_images:
        image_id = int(image.get("id", -1))
        current_path = str(image.get("xcf_path", "") or "")
        try:
            if current_path:
                response = save_gimp_image_xcf(scene, image_id, "")
            else:
                base_name = _default_xcf_filename(scene, image)
                stem = os.path.splitext(base_name)[0]
                candidate = os.path.join(
                    recovery_dir,
                    f"{stem}__recovery-{stamp}.xcf"
                )
                suffix = 2
                while candidate.lower() in used_paths or os.path.exists(candidate):
                    candidate = os.path.join(
                        recovery_dir,
                        f"{stem}__recovery-{stamp}-{suffix}.xcf"
                    )
                    suffix += 1
                used_paths.add(candidate.lower())
                response = save_gimp_image_xcf(scene, image_id, candidate)
                recovery += 1
                print(
                    "BLENDGIMP: Exit recovery saved image ID "
                    f"{image_id} -> {response.get('path', candidate)}"
                )
            saved += 1
        except Exception as exc:
            failed.append((image_id, str(exc)))
            print(
                "BLENDGIMP: Exit recovery save failed for image ID "
                f"{image_id}: {exc}"
            )

    return {"saved": saved, "recovery": recovery, "failed": failed}


def get_stored_layer_results(
    scene
):

    try:

        results = json.loads(
            scene.blendgimp_layers_json
            or
            "{}"
        )

        if isinstance(
            results,
            dict
        ):

            return results

    except Exception:

        pass

    return {}


def get_stored_layer_result(
    scene,
    image_id
):

    results = (
        get_stored_layer_results(
            scene
        )
    )

    return results.get(
        str(int(image_id))
    )


def store_layer_result(
    scene,
    image_id,
    response
):

    results = (
        get_stored_layer_results(
            scene
        )
    )

    results[
        str(int(image_id))
    ] = response

    scene.blendgimp_layers_json = (
        json.dumps(
            results,
            ensure_ascii=False
        )
    )


def get_texture_sync_results(
    scene
):

    try:
        result = json.loads(
            scene.blendgimp_texture_sync_json
            or
            "{}"
        )

        if isinstance(
            result,
            dict
        ):
            return result

    except Exception:
        pass

    return {}


def get_texture_sync_result(
    scene,
    image_id
):

    return get_texture_sync_results(
        scene
    ).get(
        str(int(image_id))
    )


def store_texture_sync_result(
    scene,
    image_id,
    result
):

    results = get_texture_sync_results(
        scene
    )

    results[
        str(int(image_id))
    ] = result

    scene.blendgimp_texture_sync_json = json.dumps(
        results,
        ensure_ascii=False
    )


def _find_selected_gimp_layer(
    layers
):
    """
    Return the first selected non-group layer from a nested GIMP layer tree.
    """

    for layer in layers or []:

        if (
            layer.get(
                "selected",
                False
            )
            and not layer.get(
                "is_group",
                False
            )
        ):
            return layer

        selected = _find_selected_gimp_layer(
            layer.get(
                "children",
                []
            )
        )

        if selected is not None:
            return selected

    return None


def resolve_gimp_paint_target(
    scene,
    image_id,
    create_if_missing=True
):
    """Resolve the artist-selected raster layer and baseline fallback creation."""

    target = connection_manager.resolve_active_raster_layer(
        image_id,
        BLENDER_PAINT_LAYER_NAME,
        create_if_missing=create_if_missing
    )

    layers_response = target.get(
        "layers_response"
    )

    if isinstance(layers_response, dict):
        store_layer_result(
            scene,
            image_id,
            layers_response
        )

    if bool(target.get("created", False)):
        try:
            baseline = connection_manager.consume_dirty_baseline(
                image_id
            )
            print(
                "BLENDGIMP: "
                f"Paint-layer structural damage baselined for image ID {image_id}; "
                f"changed={bool(baseline.get('changed', False))}"
            )
        except Exception as exc:
            print(
                "BLENDGIMP: "
                f"Paint-layer structural baseline warning for image ID {image_id}: {exc}"
            )

    return target


def _blender_image_to_top_left_rgba8(
    blender_image
):
    """
    Read a Blender Image and return straight RGBA8 bytes in top-left row order
    for GIMP/GEGL.
    """

    width = int(
        blender_image.size[0]
    )

    height = int(
        blender_image.size[1]
    )

    if width <= 0 or height <= 0:
        raise RuntimeError(
            "Blender Image has invalid dimensions"
        )

    total_values = (
        width
        * height
        * 4
    )

    if np is not None:

        pixels = np.empty(
            total_values,
            dtype=np.float32
        )

        blender_image.pixels.foreach_get(
            pixels
        )

        rgba = pixels.reshape(
            (
                height,
                width,
                4,
            )
        )

        # Blender Image rows -> GIMP top-left rows.
        rgba = np.flip(
            rgba,
            axis=0
        )

        rgba_u8 = np.clip(
            np.rint(
                rgba
                * 255.0
            ),
            0,
            255
        ).astype(
            np.uint8
        )

        return (
            width,
            height,
            rgba_u8.tobytes()
        )

    from array import array

    pixels = array(
        "f",
        [0.0]
        * total_values
    )

    blender_image.pixels.foreach_get(
        pixels
    )

    row_values = (
        width
        * 4
    )

    result = bytearray(
        width
        * height
        * 4
    )

    destination = 0

    for blender_y in range(
        height - 1,
        -1,
        -1
    ):

        start = (
            blender_y
            * row_values
        )

        end = (
            start
            + row_values
        )

        for value in pixels[
            start:
            end
        ]:

            converted = int(
                round(
                    max(
                        0.0,
                        min(
                            1.0,
                            float(
                                value
                            )
                        )
                    )
                    * 255.0
                )
            )

            result[
                destination
            ] = converted

            destination += 1

    return (
        width,
        height,
        bytes(
            result
        )
    )


def _blendgimp_rgba_dirty_bbox(
    previous_pixels,
    current_pixels,
    width,
    height
):
    if (
        previous_pixels is None
        or len(
            previous_pixels
        ) != len(
            current_pixels
        )
    ):
        return (
            0,
            0,
            int(
                width
            ),
            int(
                height
            ),
        )

    if previous_pixels == current_pixels:
        return None

    if np is not None:

        previous = np.frombuffer(
            previous_pixels,
            dtype=np.uint8
        ).reshape(
            (
                height,
                width,
                4,
            )
        )

        current = np.frombuffer(
            current_pixels,
            dtype=np.uint8
        ).reshape(
            (
                height,
                width,
                4,
            )
        )

        changed = np.any(
            previous
            != current,
            axis=2
        )

        positions = np.argwhere(
            changed
        )

        if positions.size == 0:
            return None

        min_y, min_x = positions.min(
            axis=0
        )

        max_y, max_x = positions.max(
            axis=0
        )

        return (
            int(
                min_x
            ),
            int(
                min_y
            ),
            int(
                max_x - min_x + 1
            ),
            int(
                max_y - min_y + 1
            ),
        )

    row_bytes = (
        width
        * 4
    )

    min_x = width
    min_y = height
    max_x = -1
    max_y = -1

    previous = memoryview(
        previous_pixels
    )

    current = memoryview(
        current_pixels
    )

    for y in range(
        height
    ):
        start = (
            y
            * row_bytes
        )

        end = (
            start
            + row_bytes
        )

        old_row = previous[
            start:
            end
        ]

        new_row = current[
            start:
            end
        ]

        if old_row == new_row:
            continue

        min_y = min(
            min_y,
            y
        )

        max_y = max(
            max_y,
            y
        )

        for x in range(
            width
        ):
            pixel = (
                x
                * 4
            )

            if (
                old_row[
                    pixel:
                    pixel + 4
                ]
                !=
                new_row[
                    pixel:
                    pixel + 4
                ]
            ):
                min_x = min(
                    min_x,
                    x
                )
                break

        for x in range(
            width - 1,
            -1,
            -1
        ):
            pixel = (
                x
                * 4
            )

            if (
                old_row[
                    pixel:
                    pixel + 4
                ]
                !=
                new_row[
                    pixel:
                    pixel + 4
                ]
            ):
                max_x = max(
                    max_x,
                    x
                )
                break

    if (
        max_x < min_x
        or max_y < min_y
    ):
        return None

    return (
        int(
            min_x
        ),
        int(
            min_y
        ),
        int(
            max_x - min_x + 1
        ),
        int(
            max_y - min_y + 1
        ),
    )


def _blendgimp_extract_top_left_rgba_region(
    raw_pixels,
    image_width,
    x,
    y,
    width,
    height
):
    image_row_bytes = (
        image_width
        * 4
    )

    region_row_bytes = (
        width
        * 4
    )

    result = bytearray(
        region_row_bytes
        * height
    )

    for row in range(
        height
    ):

        source_start = (
            (
                y
                + row
            )
            * image_row_bytes
            + x
            * 4
        )

        source_end = (
            source_start
            + region_row_bytes
        )

        destination_start = (
            row
            * region_row_bytes
        )

        result[
            destination_start:
            destination_start + region_row_bytes
        ] = raw_pixels[
            source_start:
            source_end
        ]

    return bytes(
        result
    )


def _find_blendgimp_active_layer_buffer(image_id):
    image_id = int(image_id)
    for candidate in bpy.data.images:
        try:
            if (
                str(candidate.get("blendgimp_role", "")) == "active-layer-buffer"
                and int(candidate.get("blendgimp_parent_gimp_image_id", -1)) == image_id
            ):
                return candidate
        except Exception:
            continue
    return None


def _get_or_create_blendgimp_active_layer_buffer(image_id, width, height, sync_token=""):
    image_id = int(image_id)
    width = int(width)
    height = int(height)
    blender_image = _find_blendgimp_active_layer_buffer(image_id)
    desired_name = f"BlendGimp::ActiveLayer-{str(sync_token or image_id)[:12]}"
    if blender_image is None:
        blender_image = bpy.data.images.new(
            name=desired_name, width=width, height=height, alpha=True, float_buffer=False
        )
    elif int(blender_image.size[0]) != width or int(blender_image.size[1]) != height:
        blender_image.scale(width, height)
    blender_image.name = desired_name
    blender_image["blendgimp_role"] = "active-layer-buffer"
    blender_image["blendgimp_parent_gimp_image_id"] = image_id
    blender_image["blendgimp_parent_sync_token"] = str(sync_token or "")
    try:
        blender_image.colorspace_settings.name = "sRGB"
        blender_image.alpha_mode = "STRAIGHT"
    except Exception:
        pass
    _BLENDER_PAINT_SYNC_RUNTIME["buffer_image_name"] = blender_image.name
    return blender_image


def _clear_blendgimp_rgba_image(blender_image):
    total = int(blender_image.size[0]) * int(blender_image.size[1]) * 4
    if np is not None:
        blender_image.pixels.foreach_set(np.zeros(total, dtype=np.float32))
    else:
        from array import array
        blender_image.pixels.foreach_set(array("f", [0.0]) * total)
    blender_image.update()


def _patch_blendgimp_layer_buffer(blender_image, response, clear_first=False):
    image_width = int(response.get("image_width", blender_image.size[0]))
    image_height = int(response.get("image_height", blender_image.size[1]))
    if int(blender_image.size[0]) != image_width or int(blender_image.size[1]) != image_height:
        blender_image.scale(image_width, image_height)
        clear_first = True
    if clear_first:
        _clear_blendgimp_rgba_image(blender_image)
    region_width = int(response.get("width", 0))
    region_height = int(response.get("height", 0))
    if region_width <= 0 or region_height <= 0:
        return blender_image
    x = int(response.get("x", 0))
    y = int(response.get("y", 0))
    raw = response.get("pixels_raw", b"")
    if not isinstance(raw, bytes):
        raw = bytes(raw)
    expected = region_width * region_height * 4
    if len(raw) != expected:
        raise RuntimeError(f"Active-layer payload mismatch: expected {expected}, got {len(raw)}")
    total = image_width * image_height * 4
    if np is not None:
        pixels = np.empty(total, dtype=np.float32)
        blender_image.pixels.foreach_get(pixels)
        full = pixels.reshape((image_height, image_width, 4))
        region = np.frombuffer(raw, dtype=np.uint8).reshape((region_height, region_width, 4))
        row_start = image_height - (y + region_height)
        row_end = image_height - y
        full[row_start:row_end, x:x + region_width, :] = region[::-1].astype(np.float32) * (1.0 / 255.0)
        blender_image.pixels.foreach_set(pixels)
    else:
        # Compatibility fallback: rebuild from top-left bytes through the existing converter logic.
        width, height, current = _blender_image_to_top_left_rgba8(blender_image)
        mutable = bytearray(current)
        row_bytes = width * 4
        region_row_bytes = region_width * 4
        for row in range(region_height):
            dst = (y + row) * row_bytes + x * 4
            src = row * region_row_bytes
            mutable[dst:dst + region_row_bytes] = raw[src:src + region_row_bytes]
        from array import array
        floats = array("f")
        for row in range(height - 1, -1, -1):
            base = row * row_bytes
            floats.extend(v / 255.0 for v in mutable[base:base + row_bytes])
        blender_image.pixels.foreach_set(floats)
    blender_image.update()
    return blender_image


def _ensure_active_layer_paint_node(context, composite_image, layer_buffer, image_id):
    obj, material = find_blendgimp_image_owner(composite_image, image_id)
    if obj is None:
        obj = getattr(context, "active_object", None)
        material = getattr(obj, "active_material", None) if obj is not None else material
    if material is None or not material.use_nodes or material.node_tree is None:
        return None
    nodes = material.node_tree.nodes
    node = next((n for n in nodes if bool(n.get("blendgimp_active_layer_paint_target", False))), None)
    if node is None:
        node = nodes.new("ShaderNodeTexImage")
        node.name = "BlendGimp Active Layer Paint Target"
        node.label = "BlendGimp Active Layer Paint Target (unconnected)"
        node["blendgimp_active_layer_paint_target"] = True
    node.image = layer_buffer
    node["blendgimp_gimp_image_id"] = int(image_id)
    node["blendgimp_gimp_layer_id"] = int(layer_buffer.get("blendgimp_gimp_layer_id", -1))
    for candidate in nodes:
        candidate.select = False
    node.select = True
    nodes.active = node

    # Blender 5.2 Material Texture Paint exposes every Image Texture node as a
    # paint slot. Select the slot that corresponds to the reusable layer
    # buffer while leaving the connected composite node untouched.
    try:
        paint_images = list(material.texture_paint_images)
        for index, paint_image in enumerate(paint_images):
            if paint_image == layer_buffer:
                material.paint_active_slot = int(index)
                break
    except Exception as exc:
        print(f"BLENDGIMP: Active texture paint slot selection warning: {exc}")

    return node


def load_active_layer_buffer_from_gimp(scene, image_id, layer_id, *, region=None, clear_first=True, activate_target=True):
    image_id = int(image_id)
    layer_id = int(layer_id)
    sync_result = get_texture_sync_result(scene, image_id) or {}
    composite = _find_blendgimp_image(image_id, sync_result.get("sync_token", ""))
    if composite is None:
        raise RuntimeError("No synchronized BlendGimp composite image is available")
    if region is None:
        response = connection_manager.get_layer_pixels_binary(image_id, layer_id)
    else:
        x, y, width, height = [int(v) for v in region]
        response = connection_manager.get_layer_pixels_binary(image_id, layer_id, x, y, width, height)
    buffer_image = _get_or_create_blendgimp_active_layer_buffer(
        image_id, int(composite.size[0]), int(composite.size[1]), sync_result.get("sync_token", "")
    )
    _patch_blendgimp_layer_buffer(buffer_image, response, clear_first=clear_first)
    buffer_image["blendgimp_gimp_layer_id"] = layer_id
    buffer_image["blendgimp_layer_offset_x"] = int(response.get("layer_offset_x", 0))
    buffer_image["blendgimp_layer_offset_y"] = int(response.get("layer_offset_y", 0))
    scene.blendgimp_blender_paint_sync_image_id = image_id
    scene.blendgimp_blender_paint_sync_layer_id = layer_id
    scene.blendgimp_blender_paint_sync_enabled = True
    width, height, baseline = _blender_image_to_top_left_rgba8(buffer_image)
    reset_blender_paint_sync_runtime(image_id=image_id, layer_id=layer_id, baseline=baseline)
    _BLENDER_PAINT_SYNC_RUNTIME["buffer_image_name"] = buffer_image.name
    scene.blendgimp_blender_paint_sync_status = f"Synced layer {layer_id}"
    if activate_target:
        _ensure_active_layer_paint_node(bpy.context, composite, buffer_image, image_id)
    print(
        "BLENDGIMP: Active Layer Buffer loaded "
        f"image ID {image_id} layer ID {layer_id} "
        f"canvas={width}x{height} source={int(response.get('width',0))}x{int(response.get('height',0))}"
    )
    return buffer_image


def _active_layer_buffer_for_sync(scene, image_id):
    buffer_image = _find_blendgimp_active_layer_buffer(image_id)
    if buffer_image is not None:
        return buffer_image
    return None


def flush_blender_paint_changes(scene, *, reason="manual", fail_if_unsent=False):
    """Synchronously commit Blender's active-layer working buffer to GIMP."""
    if scene is None or not bool(getattr(scene, "blendgimp_blender_paint_sync_enabled", False)):
        return False
    image_id = int(getattr(scene, "blendgimp_blender_paint_sync_image_id", -1))
    layer_id = int(getattr(scene, "blendgimp_blender_paint_sync_layer_id", -1))
    if image_id < 0 or layer_id < 0:
        return False
    buffer_image = _active_layer_buffer_for_sync(scene, image_id)
    if buffer_image is None:
        return False
    try:
        width, height, current_pixels = _blender_image_to_top_left_rgba8(buffer_image)
        baseline = _BLENDER_PAINT_SYNC_RUNTIME.get("baseline")
        runtime_image = int(_BLENDER_PAINT_SYNC_RUNTIME.get("image_id", -1))
        runtime_layer = int(_BLENDER_PAINT_SYNC_RUNTIME.get("layer_id", -1))
        if baseline is None or runtime_image != image_id or runtime_layer != layer_id:
            reset_blender_paint_sync_runtime(image_id=image_id, layer_id=layer_id, baseline=current_pixels)
            _BLENDER_PAINT_SYNC_RUNTIME["buffer_image_name"] = buffer_image.name
            return False
        bbox = _blendgimp_rgba_dirty_bbox(baseline, current_pixels, width, height)
        if bbox is None:
            scene.blendgimp_blender_paint_sync_status = "Synced"
            return False
        x, y, region_width, region_height = bbox
        region_pixels = _blendgimp_extract_top_left_rgba_region(
            current_pixels, width, x, y, region_width, region_height
        )
        scene.blendgimp_blender_paint_sync_status = "Sending Blender changes to GIMP"
        response = connection_manager.set_layer_pixels_binary(
            image_id, layer_id, x, y, region_width, region_height, region_pixels
        )
        # GIMP already recomposited and rebased its echo detector while
        # accepting the write. Apply only that returned composite rectangle to
        # the material image; no second full-image render/pull is necessary.
        composite_raw = response.get("pixels_raw", b"")
        if composite_raw:
            dirty_response = {
                "image_id": image_id,
                "sync_token": str(response.get("sync_token", "")),
                "width": int(response.get("image_width", width)),
                "height": int(response.get("image_height", height)),
                "changed": True,
                "x": int(response.get("composite_x", x)),
                "y": int(response.get("composite_y", y)),
                "region_width": int(response.get("composite_width", region_width)),
                "region_height": int(response.get("composite_height", region_height)),
                "pixels_raw": composite_raw,
                "transport": "blender-layer-write-composite-patch",
            }
            composite_image = apply_blender_image_dirty_pixels(dirty_response)
            _force_object_paint_texture_redraw(composite_image)
            tag_texture_views_for_redraw(bpy.context)
        _BLENDER_PAINT_SYNC_RUNTIME["baseline"] = current_pixels
        _BLENDER_PAINT_SYNC_RUNTIME["pending_pixels"] = None
        _BLENDER_PAINT_SYNC_RUNTIME["pending_bbox"] = None
        _BLENDER_PAINT_SYNC_RUNTIME["pending_since"] = 0.0
        scene.blendgimp_blender_paint_sync_status = "Synced"
        print(
            "BLENDGIMP: Unified Paint Sync flush "
            f"reason={reason} image ID {image_id} layer ID {layer_id} "
            f"x={x} y={y} {region_width}x{region_height}"
        )
        return True
    except Exception as exc:
        scene.blendgimp_blender_paint_sync_status = f"Sync error: {exc}"
        print(f"BLENDGIMP: Unified Paint Sync flush failed ({reason}): {exc}")
        if fail_if_unsent:
            raise RuntimeError(
                "Blender Texture Paint changes could not be committed to GIMP; "
                "the GIMP operation was blocked to protect the artwork. "
                f"{exc}"
            ) from exc
        return False


def apply_active_layer_buffer_response(scene, image_id, layer_id, response, *, clear_first=False, activate_target=False):
    image_id = int(image_id)
    layer_id = int(layer_id)
    if not bool(getattr(scene, "blendgimp_blender_paint_sync_enabled", False)):
        return None
    if int(getattr(scene, "blendgimp_blender_paint_sync_image_id", -1)) != image_id:
        return None
    if int(getattr(scene, "blendgimp_blender_paint_sync_layer_id", -1)) != layer_id:
        return None
    sync_result = get_texture_sync_result(scene, image_id) or {}
    composite = _find_blendgimp_image(image_id, sync_result.get("sync_token", ""))
    if composite is None:
        return None
    buffer_image = _get_or_create_blendgimp_active_layer_buffer(
        image_id, int(composite.size[0]), int(composite.size[1]), sync_result.get("sync_token", "")
    )
    _patch_blendgimp_layer_buffer(buffer_image, response, clear_first=clear_first)
    buffer_image["blendgimp_gimp_layer_id"] = layer_id
    width, height, baseline = _blender_image_to_top_left_rgba8(buffer_image)
    reset_blender_paint_sync_runtime(image_id=image_id, layer_id=layer_id, baseline=baseline)
    _BLENDER_PAINT_SYNC_RUNTIME["buffer_image_name"] = buffer_image.name
    scene.blendgimp_blender_paint_sync_status = "Synced"
    if activate_target:
        _ensure_active_layer_paint_node(bpy.context, composite, buffer_image, image_id)
    return buffer_image


def refresh_active_layer_buffer_region(scene, image_id, layer_id, dirty_response):
    """Patch the reusable working image from the actual GIMP layer after a GIMP edit."""
    if not bool(getattr(scene, "blendgimp_blender_paint_sync_enabled", False)):
        return None
    if int(getattr(scene, "blendgimp_blender_paint_sync_image_id", -1)) != int(image_id):
        return None
    if int(getattr(scene, "blendgimp_blender_paint_sync_layer_id", -1)) != int(layer_id):
        return None
    if not dirty_response or not bool(dirty_response.get("changed", False)):
        return None
    region = (
        int(dirty_response.get("x", 0)), int(dirty_response.get("y", 0)),
        int(dirty_response.get("region_width", 0)), int(dirty_response.get("region_height", 0)),
    )
    if region[2] <= 0 or region[3] <= 0:
        return None
    return load_active_layer_buffer_from_gimp(
        scene, image_id, layer_id, region=region, clear_first=False, activate_target=False
    )


def update_blender_paint_sync_baseline(
    image_id,
    blender_image=None
):
    """
    Accept the current Blender image as the reverse-sync baseline.

    Called after GIMP-originated updates so those pixels are never pushed back
    to GIMP as Blender-originated paint.
    """

    scene = getattr(
        bpy.context,
        "scene",
        None
    )

    if scene is None:
        return

    if not hasattr(
        scene,
        "blendgimp_blender_paint_sync_enabled"
    ):
        return

    if not scene.blendgimp_blender_paint_sync_enabled:
        return

    if int(
        scene.blendgimp_blender_paint_sync_image_id
    ) != int(
        image_id
    ):
        return

    try:

        active_layer_buffer = _active_layer_buffer_for_sync(scene, image_id)
        if active_layer_buffer is not None:
            blender_image = active_layer_buffer

        if blender_image is None:

            sync_result = (
                get_texture_sync_result(
                    scene,
                    image_id
                )
                or {}
            )

            blender_image = _active_layer_buffer_for_sync(scene, image_id)
            if blender_image is None:
                blender_image = _find_blendgimp_image(
                    image_id,
                    sync_result.get(
                        "sync_token",
                        ""
                    )
                )

        if blender_image is None:
            return

        width, height, raw_pixels = (
            _blender_image_to_top_left_rgba8(
                blender_image
            )
        )

        _BLENDER_PAINT_SYNC_RUNTIME[
            "image_id"
        ] = int(
            image_id
        )

        _BLENDER_PAINT_SYNC_RUNTIME[
            "baseline"
        ] = raw_pixels

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_pixels"
        ] = None

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_bbox"
        ] = None

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_since"
        ] = 0.0

    except Exception as exc:

        print(
            "BLENDGIMP: "
            f"Could not update Blender paint baseline: {exc}"
        )


def _find_blendgimp_image(
    image_id,
    sync_token
):
    """
    Find the persistent Blender Image associated with a GIMP runtime image.

    A non-empty synchronization token is authoritative. GIMP runtime image IDs
    are process-local and can be reused after a headless engine restart, while
    Blender Image datablocks survive that restart. Falling back to a matching
    runtime ID when the incoming token is different can therefore bind a new
    GIMP image to a stale Blender image with an incompatible pixel buffer.

    Runtime-ID fallback is retained only for legacy responses that do not carry
    a synchronization token.
    """

    image_id = int(image_id)
    sync_token = str(
        sync_token or ""
    ).strip()

    if sync_token:
        for candidate in bpy.data.images:
            candidate_token = str(
                candidate.get(
                    "blendgimp_sync_token",
                    ""
                )
            ).strip()

            if candidate_token == sync_token:
                return candidate

        # A token was supplied but no token match exists. Do not reuse a
        # datablock solely because its old process-local GIMP ID happens to
        # equal the current process-local ID. Log the collision for diagnostics.
        for candidate in bpy.data.images:
            try:
                candidate_id = int(
                    candidate.get(
                        "blendgimp_gimp_image_id",
                        -1
                    )
                )
            except Exception:
                candidate_id = -1

            if candidate_id == image_id:
                candidate_token = str(
                    candidate.get(
                        "blendgimp_sync_token",
                        ""
                    )
                ).strip()
                print(
                    "BLENDGIMP: Ignoring stale Blender Image pairing "
                    f"for reused GIMP runtime image ID {image_id}; "
                    f"incoming token={sync_token[:12]} "
                    f"stored token={candidate_token[:12] or 'legacy'}"
                )
                break

        return None

    # Legacy compatibility path: only token-less protocol responses may use
    # process-local image IDs for pairing.
    for candidate in bpy.data.images:
        try:
            candidate_id = int(
                candidate.get(
                    "blendgimp_gimp_image_id",
                    -1
                )
            )
        except Exception:
            candidate_id = -1

        if candidate_id == image_id:
            return candidate

    return None


def get_or_update_blender_image_from_pixels(
    pixel_response
):
    """
    Create/update the persistent Blender Image directly from GIMP RGBA8 bytes.

    GIMP sends rows with a top-left origin. Blender's pixel buffer is uploaded
    bottom row first, so rows are vertically flipped during conversion.
    """

    image_id = int(
        pixel_response["image_id"]
    )

    width = int(
        pixel_response["width"]
    )

    height = int(
        pixel_response["height"]
    )

    sync_token = str(
        pixel_response.get(
            "sync_token",
            ""
        )
    ).strip()

    if not sync_token:
        sync_token = f"image-{image_id:04d}"

    source_name = str(
        pixel_response.get(
            "image_name",
            ""
        )
    )

    desired_name = (
        "BlendGimp::Temp-"
        + sync_token[:12].upper()
    )

    raw_pixels = pixel_response.get(
        "pixels_raw",
        None
    )

    if raw_pixels is not None:

        if not isinstance(
            raw_pixels,
            bytes
        ):
            raw_pixels = bytes(
                raw_pixels
            )

    else:

        encoded = str(
            pixel_response.get(
                "pixels_b64",
                ""
            )
        )

        if not encoded:
            raise RuntimeError(
                "Direct RGBA response contains no pixel payload"
            )

        try:
            raw_pixels = base64.b64decode(
                encoded,
                validate=True
            )
        except Exception as exc:
            raise RuntimeError(
                f"Could not decode direct RGBA payload: {exc}"
            )

    expected_length = width * height * 4

    if len(raw_pixels) != expected_length:
        raise RuntimeError(
            "Direct RGBA byte count mismatch. "
            f"Expected {expected_length}, got {len(raw_pixels)}"
        )

    blender_image = _find_blendgimp_image(
        image_id,
        sync_token
    )

    if blender_image is not None:
        blender_owned_name = str(
            blender_image.get(
                "blendgimp_texture_name",
                ""
            )
        ).strip()

        if blender_owned_name:
            desired_name = blender_owned_name

    if blender_image is None:
        blender_image = bpy.data.images.new(
            name=desired_name,
            width=width,
            height=height,
            alpha=True,
            float_buffer=False,
        )
    else:
        current_width = int(
            blender_image.size[0]
        )
        current_height = int(
            blender_image.size[1]
        )

        if (
            current_width != width
            or current_height != height
        ):
            blender_image.scale(
                width,
                height
            )

    blender_image.name = desired_name

    try:
        blender_image.colorspace_settings.name = "sRGB"
    except Exception:
        pass

    try:
        blender_image.alpha_mode = "STRAIGHT"
    except Exception:
        pass

    expected_components = width * height * 4
    actual_components = len(
        blender_image.pixels
    )
    actual_channels = int(
        getattr(
            blender_image,
            "channels",
            0
        )
    )

    if actual_components != expected_components:
        raise RuntimeError(
            "Blender Image pixel buffer mismatch. "
            f"Image={blender_image.name!r} "
            f"size={width}x{height} channels={actual_channels}; "
            f"expected {expected_components} RGBA float components, "
            f"got {actual_components}. "
            "This usually indicates a stale runtime-image pairing."
        )

    if np is not None:
        rgba_u8 = np.frombuffer(
            raw_pixels,
            dtype=np.uint8
        ).reshape(
            (height, width, 4)
        )

        # GIMP / GEGL coordinates are top-left; Blender upload order is
        # bottom-row first.
        rgba_u8 = np.flip(
            rgba_u8,
            axis=0
        )

        rgba_float = (
            rgba_u8.astype(np.float32)
            * (1.0 / 255.0)
        )

        flat_rgba = np.ascontiguousarray(rgba_float.reshape(-1), dtype=np.float32)
        blender_image.pixels.foreach_set(flat_rgba)
        _drop_dirty_pixel_cache_for_image(image_id)
        _DIRTY_PIXEL_CACHE[_dirty_cache_key(
            blender_image, image_id, sync_token, width, height
        )] = flat_rgba.copy()

    else:
        from array import array

        row_bytes = width * 4
        float_pixels = array("f")

        for y in range(
            height - 1,
            -1,
            -1
        ):
            row_start = y * row_bytes
            row = raw_pixels[
                row_start:
                row_start + row_bytes
            ]

            float_pixels.extend(
                (
                    value / 255.0
                    for value in row
                )
            )

        blender_image.pixels.foreach_set(
            float_pixels
        )
        _drop_dirty_pixel_cache_for_image(image_id)

    blender_image[
        "blendgimp_gimp_image_id"
    ] = image_id

    blender_image[
        "blendgimp_sync_token"
    ] = sync_token

    blender_image[
        "blendgimp_source_name"
    ] = source_name

    blender_image[
        "blendgimp_transport"
    ] = str(
        pixel_response.get(
            "transport",
            "direct-rgba-json"
        )
    )

    blender_image[
        "blendgimp_pixel_sha256"
    ] = str(
        pixel_response.get(
            "sha256",
            ""
        )
    )

    blender_image[
        "blendgimp_cache_path"
    ] = ""

    blender_image.update()

    return blender_image


def apply_blender_image_dirty_pixels(
    dirty_response
):
    """Apply a GIMP RGBA8 dirty rectangle using Blender's fast bulk array API.

    Phase 6.2.10: Object Paint now uses the same strategy that made Texture
    Paint responsive in 6.2.9. A full float32 mirror of the Blender Image is
    cached, the tight GIMP dirty rectangle is patched into that CPU mirror,
    then Image.pixels.foreach_set() publishes the complete buffer in one fast
    transfer. The legacy slice writer remains only as a compatibility fallback.
    """

    image_id = int(dirty_response["image_id"])
    image_width = int(dirty_response["width"])
    image_height = int(dirty_response["height"])
    sync_token = str(dirty_response.get("sync_token", "")).strip()

    blender_image = _find_blendgimp_image(image_id, sync_token)
    if blender_image is None:
        raise RuntimeError("No existing Blender Image is available for a dirty update")

    if int(blender_image.size[0]) != image_width or int(blender_image.size[1]) != image_height:
        _drop_dirty_pixel_cache_for_image(image_id)
        raise RuntimeError("Blender Image dimensions changed; a full refresh is required")

    if not dirty_response.get("changed", False):
        return blender_image

    x = int(dirty_response["x"])
    y = int(dirty_response["y"])
    region_width = int(dirty_response["region_width"])
    region_height = int(dirty_response["region_height"])

    if (
        x < 0 or y < 0 or region_width <= 0 or region_height <= 0
        or x + region_width > image_width or y + region_height > image_height
    ):
        raise RuntimeError("Dirty rectangle falls outside the Blender Image")

    raw_pixels = dirty_response.get("pixels_raw", None)
    if raw_pixels is not None:
        if not isinstance(raw_pixels, bytes):
            raw_pixels = bytes(raw_pixels)
    else:
        encoded = str(dirty_response.get("pixels_b64", ""))
        try:
            raw_pixels = base64.b64decode(encoded, validate=True)
        except Exception as exc:
            raise RuntimeError(f"Could not decode dirty RGBA payload: {exc}")

    expected_length = region_width * region_height * 4
    if len(raw_pixels) != expected_length:
        raise RuntimeError(
            "Dirty RGBA byte count mismatch. "
            f"Expected {expected_length}, got {len(raw_pixels)}"
        )

    # Fast path used by Blender 5.2 builds with NumPy available.
    if (
        np is not None
        and hasattr(blender_image.pixels, "foreach_get")
        and hasattr(blender_image.pixels, "foreach_set")
    ):
        started = time.perf_counter()
        cache_key = _dirty_cache_key(
            blender_image, image_id, sync_token, image_width, image_height
        )
        total_values = image_width * image_height * 4
        cache = _DIRTY_PIXEL_CACHE.get(cache_key)

        read_started = time.perf_counter()
        if cache is None or int(getattr(cache, "size", 0)) != total_values:
            # Discard stale runtime/token caches for this GIMP image ID.
            _drop_dirty_pixel_cache_for_image(image_id)
            cache = np.empty(total_values, dtype=np.float32)
            blender_image.pixels.foreach_get(cache)
            _DIRTY_PIXEL_CACHE[cache_key] = cache
            cache_hit = False
        else:
            cache_hit = True
        read_ms = (time.perf_counter() - read_started) * 1000.0

        patch_started = time.perf_counter()
        full = cache.reshape((image_height, image_width, 4))
        region = np.frombuffer(raw_pixels, dtype=np.uint8).reshape(
            (region_height, region_width, 4)
        )
        # GIMP is top-left origin; Blender's image pixel buffer is bottom-up.
        blender_row_start = image_height - (y + region_height)
        blender_row_end = image_height - y
        full[
            blender_row_start:blender_row_end,
            x:x + region_width,
            :,
        ] = region[::-1].astype(np.float32) * (1.0 / 255.0)
        patch_ms = (time.perf_counter() - patch_started) * 1000.0

        write_started = time.perf_counter()
        blender_image.pixels.foreach_set(cache)
        write_ms = (time.perf_counter() - write_started) * 1000.0

        update_started = time.perf_counter()
        blender_image["blendgimp_transport"] = str(
            dirty_response.get("transport", "dirty-rgba-binary")
        )
        blender_image["blendgimp_last_dirty_x"] = x
        blender_image["blendgimp_last_dirty_y"] = y
        blender_image["blendgimp_last_dirty_width"] = region_width
        blender_image["blendgimp_last_dirty_height"] = region_height
        blender_image.update()
        update_ms = (time.perf_counter() - update_started) * 1000.0
        total_ms = (time.perf_counter() - started) * 1000.0

        print(
            "BLENDGIMP: Fast dirty RGBA publish "
            f"x={x} y={y} {region_width}x{region_height} "
            f"cache_hit={cache_hit} read_ms={read_ms:.1f} "
            f"patch_ms={patch_ms:.1f} foreach_set_ms={write_ms:.1f} "
            f"image_update_ms={update_ms:.1f} total_ms={total_ms:.1f}"
        )
        return blender_image

    # Compatibility fallback for environments without NumPy/foreach_set.
    if np is not None:
        region_u8 = np.frombuffer(raw_pixels, dtype=np.uint8).reshape(
            (region_height, region_width, 4)
        )
        region_float = region_u8.astype(np.float32) * (1.0 / 255.0)
        for source_row in range(region_height):
            blender_y = image_height - 1 - (y + source_row)
            pixel_start = ((blender_y * image_width + x) * 4)
            pixel_end = pixel_start + region_width * 4
            blender_image.pixels[pixel_start:pixel_end] = region_float[source_row].reshape(-1)
    else:
        row_bytes = region_width * 4
        for source_row in range(region_height):
            source_start = source_row * row_bytes
            source_end = source_start + row_bytes
            row_float = [value / 255.0 for value in raw_pixels[source_start:source_end]]
            blender_y = image_height - 1 - (y + source_row)
            pixel_start = ((blender_y * image_width + x) * 4)
            pixel_end = pixel_start + region_width * 4
            blender_image.pixels[pixel_start:pixel_end] = row_float

    blender_image["blendgimp_transport"] = str(
        dirty_response.get("transport", "dirty-rgba-json")
    )
    blender_image["blendgimp_last_dirty_x"] = x
    blender_image["blendgimp_last_dirty_y"] = y
    blender_image["blendgimp_last_dirty_width"] = region_width
    blender_image["blendgimp_last_dirty_height"] = region_height
    blender_image.update()
    return blender_image

def get_or_reload_blender_image(
    export_response
):
    """
    Create or reload one stable temporary Blender Image datablock for a GIMP
    image.

    The temporary texture identity is generated by BlendGimp and does not
    depend on the GIMP document name. The document name is stored only as
    source metadata.
    """

    image_id = int(
        export_response["image_id"]
    )

    sync_token = str(
        export_response.get(
            "sync_token",
            ""
        )
    ).strip()

    if not sync_token:
        # Compatibility fallback for older GIMP-side builds. This is still
        # generated from runtime identity rather than the document filename.
        sync_token = (
            f"image-{image_id:04d}"
        )

    cache_path = os.path.abspath(
        str(
            export_response["path"]
        )
    )

    if not os.path.isfile(
        cache_path
    ):
        raise FileNotFoundError(
            f"GIMP composite cache file does not exist: {cache_path}"
        )

    source_name = str(
        export_response.get(
            "image_name",
            ""
        )
    )

    desired_name = (
        "BlendGimp::Temp-"
        + sync_token[:12].upper()
    )

    blender_image = None

    # Prefer an exact sync-token match.
    for candidate in bpy.data.images:

        candidate_token = str(
            candidate.get(
                "blendgimp_sync_token",
                ""
            )
        )

        if (
            candidate_token
            and candidate_token == sync_token
        ):
            blender_image = candidate
            break

    # Migration / reconnect fallback: reuse an existing BlendGimp image that
    # was mapped to this GIMP runtime image ID, then update it to the new token.
    if blender_image is None:

        for candidate in bpy.data.images:

            try:
                candidate_id = int(
                    candidate.get(
                        "blendgimp_gimp_image_id",
                        -1
                    )
                )
            except Exception:
                candidate_id = -1

            if candidate_id == image_id:
                blender_image = candidate
                break

    if blender_image is None:

        blender_image = bpy.data.images.load(
            cache_path,
            check_existing=False
        )

    else:

        blender_image.filepath_raw = (
            cache_path
        )

        blender_image.reload()

    # Always migrate old document-name-derived image names such as
    # "BlendGimp::Demo.xcf" to BlendGimp's generated temporary name.
    blender_image.name = desired_name

    blender_image.filepath_raw = (
        cache_path
    )

    # The exported visible composite is display/color texture data for this
    # first Stage-1 path, so prefer sRGB when available.
    try:
        blender_image.colorspace_settings.name = (
            "sRGB"
        )
    except Exception:
        pass

    blender_image[
        "blendgimp_gimp_image_id"
    ] = image_id

    blender_image[
        "blendgimp_sync_token"
    ] = sync_token

    blender_image[
        "blendgimp_cache_path"
    ] = cache_path

    # Keep the real GIMP document name only as informational metadata.
    blender_image[
        "blendgimp_source_name"
    ] = source_name

    blender_image.update()

    return blender_image


def _blendgimp_material_uses_image(
    material,
    blender_image,
    image_id
):
    if material is None or not getattr(material, "use_nodes", False):
        return False

    node_tree = getattr(material, "node_tree", None)
    if node_tree is None:
        return False

    for node in node_tree.nodes:
        if node.type != "TEX_IMAGE":
            continue

        if getattr(node, "image", None) == blender_image:
            return True

        try:
            node_image_id = int(
                node.get("blendgimp_gimp_image_id", -1)
            )
        except Exception:
            node_image_id = -1

        if node_image_id == int(image_id):
            target_token = str(
                blender_image.get(
                    "blendgimp_sync_token",
                    ""
                )
                or ""
            )
            node_token = str(
                node.get(
                    "blendgimp_sync_token",
                    ""
                )
                or ""
            )

            if not target_token or node_token == target_token:
                return True

    return False


def find_blendgimp_image_owner(
    blender_image,
    image_id
):
    """Resolve the Blender object/material that owns a BlendGimp texture."""

    owner_name = str(
        blender_image.get(
            "blendgimp_owner_object",
            ""
        )
        or ""
    )

    material_name = str(
        blender_image.get(
            "blendgimp_owner_material",
            ""
        )
        or ""
    )

    if owner_name:
        obj = bpy.data.objects.get(owner_name)

        if (
            obj is not None
            and getattr(obj, "data", None) is not None
            and hasattr(obj.data, "materials")
        ):
            material = None

            if material_name:
                material = bpy.data.materials.get(material_name)

                if material not in list(obj.data.materials):
                    material = None

            if material is None:
                for candidate in obj.data.materials:
                    if _blendgimp_material_uses_image(
                        candidate,
                        blender_image,
                        image_id
                    ):
                        material = candidate
                        break

            return obj, material

    # Recover from object/material renames by scanning actual shader usage.
    for obj in bpy.data.objects:
        data = getattr(obj, "data", None)

        if data is None or not hasattr(data, "materials"):
            continue

        for material in data.materials:
            if _blendgimp_material_uses_image(
                material,
                blender_image,
                image_id
            ):
                blender_image["blendgimp_owner_object"] = obj.name
                blender_image["blendgimp_owner_material"] = material.name
                return obj, material

    return None, None


def activate_blendgimp_image_owner(
    context,
    blender_image,
    image_id,
    fallback_to_active=True
):
    """Activate a texture's owning object instead of reassigning it elsewhere."""

    obj, material = find_blendgimp_image_owner(
        blender_image,
        image_id
    )

    if obj is None and fallback_to_active:
        obj = context.active_object

    if obj is None:
        return None, material

    try:
        current = context.active_object
        if (
            current is not None
            and current != obj
            and str(getattr(current, "mode", "OBJECT")) != "OBJECT"
        ):
            try:
                bpy.ops.object.mode_set(mode="OBJECT")
            except Exception:
                pass

        view_layer = context.view_layer

        if view_layer is not None:
            for candidate in view_layer.objects:
                if candidate != obj:
                    try:
                        candidate.select_set(False)
                    except Exception:
                        pass

            try:
                obj.select_set(True)
            except Exception:
                pass

            try:
                view_layer.objects.active = obj
            except Exception:
                pass
    except Exception:
        pass

    if material is not None:
        try:
            slots = list(obj.data.materials)
            slot_index = slots.index(material)
            obj.active_material_index = slot_index
        except Exception:
            pass

        # Texture Paint uses the active Image Texture node as its paint image.
        # Keep the owner material pointed at this exact BlendGimp image when
        # the user switches between textures/models.
        try:
            if material.use_nodes and material.node_tree is not None:
                nodes = material.node_tree.nodes
                target_node = next(
                    (
                        node
                        for node in nodes
                        if node.type == "TEX_IMAGE"
                        and getattr(node, "image", None) == blender_image
                    ),
                    None
                )

                if target_node is not None:
                    for node in nodes:
                        node.select = False
                    target_node.select = True
                    nodes.active = target_node
        except Exception:
            pass

    return obj, material


def assign_blendgimp_image_to_active_material(
    context,
    blender_image,
    image_id
):
    """
    Assign a synchronized BlendGimp Image to its owning Blender object.

    On first assignment the current active object becomes the owner. On later
    refreshes the stored owner is activated and reused, preventing a texture
    from being silently applied to whichever unrelated object happens to be
    selected at the time.
    """

    obj, material = activate_blendgimp_image_owner(
        context,
        blender_image,
        image_id,
        fallback_to_active=True
    )

    if obj is None:
        return {
            "assigned": False,
            "material": "",
            "owner_object": "",
            "reason": "No owning or active Blender object",
        }

    if (
        getattr(obj, "data", None) is None
        or not hasattr(obj.data, "materials")
    ):
        return {
            "assigned": False,
            "material": "",
            "owner_object": obj.name,
            "reason": "Owning object does not support materials",
        }

    created_material = False

    if material is None:
        material_name = str(
            blender_image.get(
                "blendgimp_owner_material",
                ""
            )
            or ""
        )

        if material_name:
            candidate = bpy.data.materials.get(material_name)
            if candidate in list(obj.data.materials):
                material = candidate

    if material is None:
        material = obj.active_material

    if material is None:
        material = bpy.data.materials.new(
            name="BlendGimp Material"
        )
        material.use_nodes = True
        created_material = True

        if len(obj.data.materials) == 0:
            obj.data.materials.append(material)
        else:
            obj.active_material = material

    material.use_nodes = True

    node_tree = material.node_tree
    nodes = node_tree.nodes
    links = node_tree.links

    principled = next(
        (
            node
            for node in nodes
            if node.type == "BSDF_PRINCIPLED"
        ),
        None
    )

    if principled is None:
        if created_material:
            principled = nodes.new("ShaderNodeBsdfPrincipled")
        else:
            return {
                "assigned": False,
                "material": material.name,
                "owner_object": obj.name,
                "reason": (
                    "Owning material has no Principled BSDF; "
                    "image was refreshed but shader was not rewired"
                ),
            }

    texture_node = None

    for node in nodes:
        if node.type != "TEX_IMAGE":
            continue

        try:
            node_image_id = int(
                node.get("blendgimp_gimp_image_id", -1)
            )
        except Exception:
            node_image_id = -1

        node_matches_image = (
            getattr(node, "image", None) == blender_image
        )

        node_matches_session = False
        if node_image_id == int(image_id):
            target_token = str(
                blender_image.get(
                    "blendgimp_sync_token",
                    ""
                )
                or ""
            )
            node_token = str(
                node.get(
                    "blendgimp_sync_token",
                    ""
                )
                or ""
            )
            node_matches_session = (
                not target_token
                or node_token == target_token
            )

        if node_matches_image or node_matches_session:
            texture_node = node
            break

    if texture_node is None:
        texture_node = nodes.new("ShaderNodeTexImage")
        texture_node.label = "BlendGimp Composite"
        texture_node.name = f"BlendGimp Composite {image_id}"
        texture_node.location = (
            principled.location.x - 360.0,
            principled.location.y + 160.0,
        )

    texture_node["blendgimp_gimp_image_id"] = int(image_id)
    texture_node["blendgimp_sync_token"] = str(
        blender_image.get(
            "blendgimp_sync_token",
            ""
        )
        or ""
    )
    texture_node["blendgimp_owner_object"] = obj.name
    texture_node["blendgimp_owner_material"] = material.name
    texture_node.image = blender_image

    try:
        for node in nodes:
            node.select = False
        texture_node.select = True
        nodes.active = texture_node
    except Exception:
        pass

    base_color_input = principled.inputs.get("Base Color")

    if base_color_input is None:
        return {
            "assigned": False,
            "material": material.name,
            "owner_object": obj.name,
            "reason": "Principled BSDF has no Base Color input",
        }

    for link in list(base_color_input.links):
        links.remove(link)

    links.new(
        texture_node.outputs["Color"],
        base_color_input
    )

    material["blendgimp_gimp_image_id"] = int(image_id)
    material["blendgimp_owner_object"] = obj.name

    blender_image["blendgimp_owner_object"] = obj.name
    blender_image["blendgimp_owner_material"] = material.name
    blender_image.update()

    return {
        "assigned": True,
        "material": material.name,
        "owner_object": obj.name,
        "reason": "",
    }


def tag_texture_views_for_redraw(
    context
):

    screen = getattr(
        context,
        "screen",
        None
    )

    if screen is not None:
        for area in screen.areas:
            if area.type in {
                "VIEW_3D",
                "IMAGE_EDITOR",
                "NODE_EDITOR",
            }:
                area.tag_redraw()

    try:
        context.view_layer.update()
    except Exception:
        pass


def synchronize_gimp_composite(
    context,
    image_id,
    assign_material=True,
    dirty_only=False
):
    """
    Synchronize GIMP's visible composite into one persistent Blender Image.

    Preferred automatic transport:
        dirty rectangle + raw binary RGBA

    Fallback chain:
        dirty binary
        -> dirty base64 JSON
        -> full binary
        -> full base64 JSON
        -> PNG export
    """

    scene = context.scene
    image_id = int(
        image_id
    )

    print(
        "BLENDGIMP: "
        f"Refreshing GIMP image ID {image_id} into Blender"
    )

    transport_response = None
    transport = ""
    direct_errors = []
    blender_image = None

    # --------------------------------------------------------
    # Automatic dirty-region path
    # --------------------------------------------------------

    if dirty_only:

        dirty_response = None

        try:

            dirty_response = (
                connection_manager.get_image_dirty_pixels_binary(
                    image_id
                )
            )

        except Exception as exc:

            direct_errors.append(
                "Dirty binary: "
                + str(
                    exc
                )
            )

            print(
                "BLENDGIMP: "
                f"Dirty binary unavailable: {exc}; "
                "trying dirty base64"
            )

            if connection_manager.is_connected():

                try:

                    dirty_response = (
                        connection_manager.get_image_dirty_pixels(
                            image_id
                        )
                    )

                except Exception as fallback_exc:

                    direct_errors.append(
                        "Dirty base64: "
                        + str(
                            fallback_exc
                        )
                    )

                    print(
                        "BLENDGIMP: "
                        f"Dirty base64 unavailable: {fallback_exc}; "
                        "trying full direct transfer"
                    )

        if dirty_response is not None:

            if dirty_response.get(
                "changed",
                False
            ):

                blender_image = (
                    apply_blender_image_dirty_pixels(
                        dirty_response
                    )
                )

                transport = str(
                    dirty_response.get(
                        "transport",
                        "dirty-rgba-json"
                    )
                )

                print(
                    "BLENDGIMP: "
                    "Dirty RGBA received: "
                    f"x={dirty_response.get('x')} "
                    f"y={dirty_response.get('y')} "
                    f"{dirty_response.get('region_width')}x"
                    f"{dirty_response.get('region_height')} "
                    f"{dirty_response.get('byte_length', 0)} bytes "
                    f"via {transport}"
                )

            else:

                blender_image = _find_blendgimp_image(
                    image_id,
                    dirty_response.get(
                        "sync_token",
                        ""
                    )
                )

                if blender_image is None:
                    direct_errors.append(
                        "Dirty response had no changes but no existing "
                        "Blender Image was available"
                    )
                else:
                    transport = str(
                        dirty_response.get(
                            "transport",
                            "dirty-rgba-json"
                        )
                    )

                    print(
                        "BLENDGIMP: "
                        "Dirty RGBA check returned no pixel delta "
                        f"via {transport}"
                    )

            transport_response = (
                dirty_response
            )

    # --------------------------------------------------------
    # Full direct path
    # --------------------------------------------------------

    if blender_image is None:

        pixel_response = None

        try:

            pixel_response = (
                connection_manager.get_image_pixels_binary(
                    image_id
                )
            )

        except Exception as exc:

            direct_errors.append(
                "Full binary: "
                + str(
                    exc
                )
            )

            print(
                "BLENDGIMP: "
                f"Full binary unavailable: {exc}; "
                "trying full base64"
            )

            if connection_manager.is_connected():

                try:

                    pixel_response = (
                        connection_manager.get_image_pixels(
                            image_id
                        )
                    )

                except Exception as fallback_exc:

                    direct_errors.append(
                        "Full base64: "
                        + str(
                            fallback_exc
                        )
                    )

                    print(
                        "BLENDGIMP: "
                        f"Full base64 unavailable: {fallback_exc}; "
                        "using PNG fallback"
                    )

        if pixel_response is not None:

            blender_image = (
                get_or_update_blender_image_from_pixels(
                    pixel_response
                )
            )

            transport_response = (
                pixel_response
            )

            transport = str(
                pixel_response.get(
                    "transport",
                    "direct-rgba-json"
                )
            )

            print(
                "BLENDGIMP: "
                f"Direct RGBA received: "
                f"{pixel_response.get('byte_length', 0)} bytes "
                f"for {pixel_response.get('width')}x"
                f"{pixel_response.get('height')} "
                f"via {transport}"
            )

    # --------------------------------------------------------
    # Last-resort proven PNG path
    # --------------------------------------------------------

    if blender_image is None:

        if not connection_manager.is_connected():
            raise RuntimeError(
                "BlendGimp disconnected before PNG fallback. "
                + " | ".join(
                    direct_errors
                )
            )

        export_response = (
            connection_manager.export_composite(
                image_id
            )
        )

        print(
            "BLENDGIMP: "
            f"Composite exported to {export_response.get('path')}"
        )

        blender_image = (
            get_or_reload_blender_image(
                export_response
            )
        )

        transport_response = (
            export_response
        )

        transport = (
            "png-fallback"
        )

    # --------------------------------------------------------
    # Material mapping
    # --------------------------------------------------------

    if assign_material:

        assignment = (
            assign_blendgimp_image_to_active_material(
                context,
                blender_image,
                image_id
            )
        )

    else:

        previous = (
            get_texture_sync_result(
                scene,
                image_id
            )
            or {}
        )

        assignment = {
            "material": str(
                previous.get(
                    "material",
                    ""
                )
            ),
            "owner_object": str(
                previous.get(
                    "owner_object",
                    blender_image.get(
                        "blendgimp_owner_object",
                        ""
                    )
                )
                or ""
            ),
            "assigned": bool(
                previous.get(
                    "assigned",
                    False
                )
            ),
            "reason": str(
                previous.get(
                    "reason",
                    ""
                )
            ),
        }

    sync_result = {
        "blender_image": blender_image.name,
        "sync_token": str(
            transport_response.get(
                "sync_token",
                ""
            )
        ),
        "source_name": str(
            transport_response.get(
                "image_name",
                ""
            )
        ),
        "transport": transport,
        "direct_error": " | ".join(
            direct_errors
        ),
        "cache_path": str(
            transport_response.get(
                "path",
                ""
            )
        ),
        "width": int(
            transport_response.get(
                "width",
                blender_image.size[0]
            )
        ),
        "height": int(
            transport_response.get(
                "height",
                blender_image.size[1]
            )
        ),
        "byte_length": int(
            transport_response.get(
                "byte_length",
                0
            )
        ),
        "full_byte_length": int(
            transport_response.get(
                "full_byte_length",
                0
            )
        ),
        "saved_bytes": int(
            transport_response.get(
                "saved_bytes",
                0
            )
        ),
        "dirty_x": int(
            transport_response.get(
                "x",
                0
            )
        ),
        "dirty_y": int(
            transport_response.get(
                "y",
                0
            )
        ),
        "dirty_width": int(
            transport_response.get(
                "region_width",
                0
            )
        ),
        "dirty_height": int(
            transport_response.get(
                "region_height",
                0
            )
        ),
        "pixel_sha256": str(
            transport_response.get(
                "sha256",
                ""
            )
        ),
        "material": assignment.get(
            "material",
            ""
        ),
        "owner_object": assignment.get(
            "owner_object",
            str(
                blender_image.get(
                    "blendgimp_owner_object",
                    ""
                )
                or ""
            )
        ),
        "assigned": bool(
            assignment.get(
                "assigned",
                False
            )
        ),
        "reason": str(
            assignment.get(
                "reason",
                ""
            )
        ),
        "mtime_ns": int(
            transport_response.get(
                "mtime_ns",
                0
            )
        ),
    }

    store_texture_sync_result(
        scene,
        image_id,
        sync_result
    )

    tag_texture_views_for_redraw(
        context
    )

    scene.blendgimp_connected = True

    print(
        "BLENDGIMP: "
        f"Blender image refreshed = {blender_image.name} "
        f"via {transport}"
    )

    if (
        assign_material
        and assignment.get(
            "assigned",
            False
        )
    ):
        print(
            "BLENDGIMP: "
            f"Assigned to material = {assignment.get('material')}"
        )

    # First full/material synchronization also prepares the reusable raw-layer
    # Blender paint target. Dirty-only refreshes keep using rectangle patches.
    if assign_material and (
        not bool(getattr(scene, "blendgimp_blender_paint_sync_enabled", False))
        or int(getattr(scene, "blendgimp_blender_paint_sync_image_id", -1)) != int(image_id)
        or _find_blendgimp_active_layer_buffer(image_id) is None
    ):
        try:
            target = resolve_gimp_paint_target(scene, image_id, create_if_missing=True)
            load_active_layer_buffer_from_gimp(
                scene, image_id, int(target["layer_id"]),
                clear_first=True, activate_target=True
            )
            print(
                "BLENDGIMP: Unified Paint Sync initialized automatically "
                f"for image ID {image_id} layer ID {int(target['layer_id'])}"
            )
        except Exception as sync_exc:
            print(f"BLENDGIMP: Unified Paint Sync initialization warning: {sync_exc}")

    update_blender_paint_sync_baseline(
        image_id,
        blender_image
    )

    return {
        "export_response": transport_response,
        "transport_response": transport_response,
        "transport": transport,
        "blender_image": blender_image,
        "assignment": assignment,
        "sync_result": sync_result,
    }


def blendgimp_blender_paint_sync_timer():
    """
    Blender main-thread timer for Blender -> GIMP Texture Paint.

    While the active object is in Texture Paint mode, compare the synchronized
    Blender Image against the last accepted baseline. After a short debounce,
    send only the changed bounding rectangle to the dedicated BlendGimp Paint
    layer using raw binary RGBA.
    """

    if not hasattr(
        bpy.types.Scene,
        "blendgimp_blender_paint_sync_enabled"
    ):
        return None

    scene = getattr(
        bpy.context,
        "scene",
        None
    )

    if scene is None:
        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    # Cache the active Texture Paint color while Blender still exposes the
    # ImagePaint brush.  Blender 5.2 can drop the active paint brush when the
    # user returns to Object/Layout mode, so Direct GIMP Paint must not depend
    # on reading the brush only after the mode switch.
    try:
        cache_blender_texture_paint_color(bpy.context)
    except Exception:
        pass

    if not scene.blendgimp_blender_paint_sync_enabled:
        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    image_id = int(
        scene.blendgimp_blender_paint_sync_image_id
    )

    if image_id < 0:
        scene.blendgimp_blender_paint_sync_status = (
            "No GIMP image selected"
        )
        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    if not connection_manager.is_connected():
        scene.blendgimp_connected = False
        scene.blendgimp_blender_paint_sync_status = (
            "Waiting for GIMP connection"
        )
        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    active_object = getattr(bpy.context, "active_object", None)
    in_texture_paint = (
        active_object is not None and str(active_object.mode) == "TEXTURE_PAINT"
    )

    sync_result = (
        get_texture_sync_result(
            scene,
            image_id
        )
        or {}
    )

    blender_image = _active_layer_buffer_for_sync(scene, image_id)

    if blender_image is None:
        scene.blendgimp_blender_paint_sync_status = "Loading active GIMP layer"
        try:
            target = resolve_gimp_paint_target(scene, image_id, create_if_missing=True)
            blender_image = load_active_layer_buffer_from_gimp(
                scene, image_id, int(target["layer_id"]), clear_first=True
            )
        except Exception as exc:
            scene.blendgimp_blender_paint_sync_status = f"Active layer load failed: {exc}"
            return 1.0

    if in_texture_paint:
        try:
            composite_image = _find_blendgimp_image(
                image_id, sync_result.get("sync_token", "")
            )
            if composite_image is not None:
                _ensure_active_layer_paint_node(
                    bpy.context, composite_image, blender_image, image_id
                )
        except Exception as exc:
            print(f"BLENDGIMP: Active Layer paint target selection warning: {exc}")

    try:

        width, height, current_pixels = (
            _blender_image_to_top_left_rgba8(
                blender_image
            )
        )

    except Exception as exc:

        scene.blendgimp_blender_paint_sync_status = (
            f"Pixel read failed: {exc}"
        )

        return 1.0

    if (
        _BLENDER_PAINT_SYNC_RUNTIME.get(
            "image_id"
        )
        != image_id
        or _BLENDER_PAINT_SYNC_RUNTIME.get(
            "baseline"
        )
        is None
    ):

        reset_blender_paint_sync_runtime(
            image_id=image_id,
            layer_id=int(
                scene.blendgimp_blender_paint_sync_layer_id
            ),
            baseline=current_pixels
        )

        scene.blendgimp_blender_paint_sync_status = (
            "Watching Blender texture"
        )

        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    baseline = _BLENDER_PAINT_SYNC_RUNTIME.get(
        "baseline"
    )

    bbox = _blendgimp_rgba_dirty_bbox(
        baseline,
        current_pixels,
        width,
        height
    )

    now = time.monotonic()

    pending_pixels = _BLENDER_PAINT_SYNC_RUNTIME.get(
        "pending_pixels"
    )

    pending_bbox = _BLENDER_PAINT_SYNC_RUNTIME.get(
        "pending_bbox"
    )

    # If the image has returned to the accepted baseline, any pending paint
    # change was undone/cancelled before it was transmitted.
    if bbox is None:

        if (
            pending_pixels is not None
            or pending_bbox is not None
        ):
            _BLENDER_PAINT_SYNC_RUNTIME[
                "pending_pixels"
            ] = None

            _BLENDER_PAINT_SYNC_RUNTIME[
                "pending_bbox"
            ] = None

            _BLENDER_PAINT_SYNC_RUNTIME[
                "pending_since"
            ] = 0.0

        scene.blendgimp_blender_paint_sync_status = (
            "Watching Blender texture"
        )

        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    # Start the debounce window on the first observed Blender-side change.
    if (
        pending_pixels is None
        or pending_bbox is None
    ):

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_pixels"
        ] = current_pixels

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_bbox"
        ] = bbox

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_since"
        ] = now

        scene.blendgimp_blender_paint_sync_status = (
            "Blender paint change detected"
        )

        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    # Only restart the debounce timer if Blender's pixels actually changed
    # again. The previous implementation reset this timestamp every poll,
    # which meant the debounce could never expire.
    if pending_pixels != current_pixels:

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_pixels"
        ] = current_pixels

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_bbox"
        ] = bbox

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_since"
        ] = now

        scene.blendgimp_blender_paint_sync_status = (
            "Blender paint changing"
        )

        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    # Pixel content is stable. Let the debounce window expire and then push
    # the already-captured dirty rectangle.
    pending_pixels = _BLENDER_PAINT_SYNC_RUNTIME[
        "pending_pixels"
    ]

    pending_bbox = _BLENDER_PAINT_SYNC_RUNTIME[
        "pending_bbox"
    ]

    debounce = (
        max(0.1, float(scene.blendgimp_blender_paint_sync_debounce))
        if in_texture_paint else 0.0
    )

    elapsed = (
        now
        - float(
            _BLENDER_PAINT_SYNC_RUNTIME.get(
                "pending_since",
                now
            )
        )
    )

    if elapsed < debounce:

        scene.blendgimp_blender_paint_sync_status = (
            "Debouncing Blender paint"
        )

        return BLENDER_PAINT_SYNC_POLL_INTERVAL

    (
        x,
        y,
        region_width,
        region_height,
    ) = pending_bbox

    region_pixels = (
        _blendgimp_extract_top_left_rgba_region(
            pending_pixels,
            width,
            x,
            y,
            region_width,
            region_height
        )
    )

    try:

        layer_id = int(scene.blendgimp_blender_paint_sync_layer_id)
        if layer_id < 0:
            raise RuntimeError("No active GIMP raster layer is bound to the Blender paint buffer")

        try:

            response = (
                connection_manager.set_layer_pixels_binary(
                    image_id,
                    layer_id,
                    x,
                    y,
                    region_width,
                    region_height,
                    region_pixels
                )
            )

        except Exception as first_exc:

            error_text = str(
                first_exc
            )

            # GIMP runtime object IDs are session-local. If GIMP restarted or
            # the dedicated layer was deleted, resolve/create BlendGimp Paint
            # and retry this exact dirty rectangle immediately.
            if (
                "not a valid GIMP layer" not in error_text
                and "does not overlap" not in error_text
            ):
                raise

            print(
                "BLENDGIMP: "
                f"3D Paint Sync target layer became stale: {error_text}. "
                "Resolving BlendGimp Paint and retrying."
            )

            layer_response = resolve_gimp_paint_target(
                scene,
                image_id,
                create_if_missing=True
            )

            layer_id = int(
                layer_response["layer_id"]
            )

            scene.blendgimp_blender_paint_sync_layer_id = (
                layer_id
            )

            _BLENDER_PAINT_SYNC_RUNTIME[
                "layer_id"
            ] = layer_id

            response = (
                connection_manager.set_layer_pixels_binary(
                    image_id,
                    layer_id,
                    x,
                    y,
                    region_width,
                    region_height,
                    region_pixels
                )
            )

        _BLENDER_PAINT_SYNC_RUNTIME[
            "baseline"
        ] = pending_pixels

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_pixels"
        ] = None

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_bbox"
        ] = None

        _BLENDER_PAINT_SYNC_RUNTIME[
            "pending_since"
        ] = 0.0

        scene.blendgimp_blender_paint_sync_status = (
            f"Sent {region_width}x{region_height} region"
        )

        print(
            "BLENDGIMP: "
            "Unified Paint Sync pushed "
            f"x={x} y={y} "
            f"{region_width}x{region_height} "
            f"{len(region_pixels)} raw RGBA bytes "
            f"to GIMP layer ID {layer_id}"
        )

    except Exception as exc:

        # If the paint layer was deleted/replaced in GIMP, resolve/create it
        # again on the next pass.
        scene.blendgimp_blender_paint_sync_layer_id = (
            -1
        )

        scene.blendgimp_blender_paint_sync_status = (
            f"Push failed: {exc}"
        )

        print(
            "BLENDGIMP: "
            f"Unified Paint Sync failed: {exc}"
        )

        return 1.0

    return BLENDER_PAINT_SYNC_POLL_INTERVAL


def blendgimp_auto_sync_timer():
    """
    Blender main-thread timer.

    Poll only the lightweight GIMP visual revision. Once a revision remains
    stable for the configured debounce interval, export/reload the composite
    exactly once.
    """

    if not hasattr(
        bpy.types.Scene,
        "blendgimp_auto_sync_enabled"
    ):
        return None

    scene = getattr(
        bpy.context,
        "scene",
        None
    )

    if scene is None:
        return AUTO_SYNC_POLL_INTERVAL

    if not scene.blendgimp_auto_sync_enabled:
        return AUTO_SYNC_POLL_INTERVAL

    # Direct GIMP Brush 3D Paint owns GIMP->Blender refreshes while its
    # modal tool is active. Use shared module runtime rather than bpy.context
    # Scene state because Blender app timers may execute under another UI
    # context/window.
    if direct_paint_owns_refresh():
        return AUTO_SYNC_POLL_INTERVAL

    image_id = int(
        scene.blendgimp_auto_sync_image_id
    )

    if image_id < 0:
        scene.blendgimp_auto_sync_status = (
            "No GIMP image selected"
        )
        return AUTO_SYNC_POLL_INTERVAL

    if not connection_manager.is_connected():
        scene.blendgimp_connected = False
        scene.blendgimp_auto_sync_status = (
            "Waiting for GIMP connection"
        )
        return AUTO_SYNC_POLL_INTERVAL

    try:
        state = (
            connection_manager.get_image_state(
                image_id
            )
        )

    except GimpImageNotFoundError:
        scene.blendgimp_connected = (
            connection_manager.is_connected()
        )
        clear_gimp_session_bindings(
            scene,
            status=(
                "Previous GIMP image closed; "
                "waiting for a Blender-owned texture"
            )
        )
        print(
            "BLENDGIMP: "
            "Auto Sync released a stale GIMP image ID"
        )
        return AUTO_SYNC_POLL_INTERVAL

    except Exception as exc:
        scene.blendgimp_connected = (
            connection_manager.is_connected()
        )
        scene.blendgimp_auto_sync_status = (
            f"State check failed: {exc}"
        )
        return 1.0

    revision = int(
        state.get(
            "revision",
            0
        )
    )

    scene.blendgimp_auto_sync_revision = (
        revision
    )

    detector = str(
        state.get(
            "detector",
            ""
        )
    )

    if detector:
        if hasattr(
            scene,
            "blendgimp_auto_sync_detector"
        ):
            scene.blendgimp_auto_sync_detector = (
                detector
            )

    if (
        _AUTO_SYNC_RUNTIME.get(
            "image_id"
        )
        != image_id
    ):
        reset_auto_sync_runtime(
            image_id,
            revision
        )

        scene.blendgimp_auto_sync_status = (
            f"Watching revision {revision}"
        )

        return AUTO_SYNC_POLL_INTERVAL

    last_seen = (
        _AUTO_SYNC_RUNTIME.get(
            "last_seen_revision"
        )
    )

    now = time.monotonic()

    if last_seen is None:

        _AUTO_SYNC_RUNTIME[
            "last_seen_revision"
        ] = revision

        _AUTO_SYNC_RUNTIME[
            "last_synced_revision"
        ] = revision

        scene.blendgimp_auto_sync_status = (
            f"Watching revision {revision}"
        )

        return AUTO_SYNC_POLL_INTERVAL

    if revision != int(
        last_seen
    ):

        _AUTO_SYNC_RUNTIME[
            "last_seen_revision"
        ] = revision

        _AUTO_SYNC_RUNTIME[
            "pending_revision"
        ] = revision

        _AUTO_SYNC_RUNTIME[
            "pending_since"
        ] = now

        scene.blendgimp_auto_sync_status = (
            f"Change detected - revision {revision}"
        )

        return AUTO_SYNC_POLL_INTERVAL

    pending_revision = (
        _AUTO_SYNC_RUNTIME.get(
            "pending_revision"
        )
    )

    if pending_revision is None:
        scene.blendgimp_auto_sync_status = (
            f"Watching revision {revision}"
        )
        return AUTO_SYNC_POLL_INTERVAL

    debounce = max(
        0.1,
        float(
            scene.blendgimp_auto_sync_debounce
        )
    )

    elapsed = (
        now
        - float(
            _AUTO_SYNC_RUNTIME.get(
                "pending_since",
                now
            )
        )
    )

    if elapsed < debounce:
        scene.blendgimp_auto_sync_status = (
            f"Debouncing revision {pending_revision}"
        )
        return AUTO_SYNC_POLL_INTERVAL

    try:

        synchronize_gimp_composite(
            bpy.context,
            image_id,
            assign_material=False,
            dirty_only=True
        )

        _AUTO_SYNC_RUNTIME[
            "last_synced_revision"
        ] = int(
            pending_revision
        )

        _AUTO_SYNC_RUNTIME[
            "pending_revision"
        ] = None

        _AUTO_SYNC_RUNTIME[
            "pending_since"
        ] = 0.0

        scene.blendgimp_auto_sync_status = (
            f"Synced revision {pending_revision}"
        )

        print(
            "BLENDGIMP: "
            f"Auto Sync completed for image ID {image_id} "
            f"revision {pending_revision}"
        )

    except Exception as exc:

        scene.blendgimp_connected = (
            connection_manager.is_connected()
        )

        scene.blendgimp_auto_sync_status = (
            f"Auto Sync failed: {exc}"
        )

        # Keep the revision pending, but delay the next retry so a transient
        # failure does not hammer GIMP.
        _AUTO_SYNC_RUNTIME[
            "pending_since"
        ] = time.monotonic()

        return 1.0

    return AUTO_SYNC_POLL_INTERVAL


def _find_current_blendgimp_preview_image(
    context,
    image_id
):
    """Prefer the image currently bound to the active owner's shader."""

    image_id = int(image_id)

    obj = getattr(context, "active_object", None)
    material = getattr(obj, "active_material", None) if obj is not None else None

    if material is not None and getattr(material, "use_nodes", False):
        node_tree = getattr(material, "node_tree", None)
        if node_tree is not None:
            for node in node_tree.nodes:
                if getattr(node, "type", "") != "TEX_IMAGE":
                    continue
                try:
                    node_image_id = int(
                        node.get("blendgimp_gimp_image_id", -1)
                    )
                except Exception:
                    node_image_id = -1
                image = getattr(node, "image", None)
                if node_image_id == image_id and image is not None:
                    return image

    candidates = []
    for image in bpy.data.images:
        try:
            candidate_id = int(
                image.get("blendgimp_gimp_image_id", -1)
            )
        except Exception:
            candidate_id = -1
        if candidate_id == image_id:
            candidates.append(image)

    # New session images are created after stale datablocks, so prefer the
    # newest matching image if shader ownership could not resolve it.
    return candidates[-1] if candidates else None


def _clear_blender_preview_for_empty_gimp_image(
    context,
    image_id
):
    """Clear a zero-layer GIMP preview without uploading a 4K float array.

    Scaling to 1x1, clearing four components, then scaling back delegates the
    large allocation/fill to Blender's C image code instead of constructing or
    converting 67 million Python-side pixel components.
    """

    blender_image = _find_current_blendgimp_preview_image(
        context,
        image_id
    )

    if blender_image is None:
        return False

    width = int(blender_image.size[0])
    height = int(blender_image.size[1])

    if width <= 0 or height <= 0:
        return False

    try:
        blender_image.scale(1, 1)
        blender_image.pixels.foreach_set(
            (0.0, 0.0, 0.0, 0.0)
        )
        blender_image.scale(width, height)
        blender_image.update()

        scene = getattr(context, "scene", None)
        if (
            scene is not None
            and hasattr(scene, "blendgimp_blender_paint_sync_image_id")
            and int(scene.blendgimp_blender_paint_sync_image_id) == int(image_id)
        ):
            # The local preview clear is structural bookkeeping, not a Blender
            # Texture Paint edit. Rebase the Blender->GIMP paint watcher to the
            # same transparent image so it does not try to push a full 4K zero
            # frame back into a newly-created fallback layer.
            blank_baseline = bytes(width * height * 4)
            reset_blender_paint_sync_runtime(
                image_id=image_id,
                layer_id=-1,
                baseline=blank_baseline
            )
            scene.blendgimp_blender_paint_sync_layer_id = -1

        print(
            "BLENDGIMP: Cleared Blender preview locally after final "
            f"GIMP layer deletion for image ID {image_id} "
            f"({width}x{height}); no full-frame download required"
        )
        return True
    except Exception as exc:
        print(
            "BLENDGIMP: Could not clear zero-layer Blender preview "
            f"for image ID {image_id}: {exc}"
        )
        try:
            if int(blender_image.size[0]) != width or int(blender_image.size[1]) != height:
                blender_image.scale(width, height)
        except Exception:
            pass
        return False


def refresh_layer_result(
    scene,
    image_id
):
    """
    Re-read GIMP's real layer state after a write command.
    """

    response = (
        connection_manager.get_image_layers(
            image_id
        )
    )

    store_layer_result(
        scene,
        image_id,
        response
    )

    return response


# Blender keeps dynamic EnumProperty strings by reference. Retain the
# generated tuples at module scope so the Move Layer dialog remains stable.
_MOVE_TARGET_ITEMS_CACHE = []


def _find_layer_in_tree(
    layers,
    layer_id
):

    for layer in layers:

        try:
            current_id = int(
                layer.get(
                    "id",
                    -1
                )
            )
        except Exception:
            current_id = -1

        if current_id == int(layer_id):
            return layer

        found = _find_layer_in_tree(
            layer.get(
                "children",
                []
            ),
            layer_id
        )

        if found is not None:
            return found

    return None


def _collect_descendant_ids(
    layer
):

    result = set()

    if layer is None:
        return result

    for child in layer.get(
        "children",
        []
    ):

        try:
            child_id = int(
                child.get(
                    "id",
                    -1
                )
            )
        except Exception:
            child_id = -1

        if child_id >= 0:
            result.add(
                child_id
            )

        result.update(
            _collect_descendant_ids(
                child
            )
        )

    return result


def _collect_group_targets(
    layers,
    excluded_ids,
    depth=0
):

    targets = []

    for layer in layers:

        try:
            layer_id = int(
                layer.get(
                    "id",
                    -1
                )
            )
        except Exception:
            layer_id = -1

        if layer_id < 0:
            continue

        is_group = bool(
            layer.get(
                "is_group",
                False
            )
        )

        if (
            is_group
            and layer_id not in excluded_ids
        ):

            targets.append(
                (
                    str(layer_id),
                    (
                        "    " * depth
                        + str(
                            layer.get(
                                "name",
                                "Layer Group"
                            )
                        )
                    ),
                    (
                        "Move the layer into "
                        + str(
                            layer.get(
                                "name",
                                "this group"
                            )
                        )
                    ),
                )
            )

        targets.extend(
            _collect_group_targets(
                layer.get(
                    "children",
                    []
                ),
                excluded_ids,
                depth + 1
            )
        )

    return targets


def blendgimp_move_target_items(
    self,
    context
):

    global _MOVE_TARGET_ITEMS_CACHE

    items = [
        (
            "-1",
            "Top Level",
            "Move the layer out of groups to the image's top-level layer stack",
        )
    ]

    scene = context.scene

    layer_result = (
        get_stored_layer_result(
            scene,
            self.image_id
        )
    )

    if layer_result is not None:

        layers = layer_result.get(
            "layers",
            []
        )

        moving_layer = (
            _find_layer_in_tree(
                layers,
                self.layer_id
            )
        )

        excluded_ids = {
            int(self.layer_id)
        }

        excluded_ids.update(
            _collect_descendant_ids(
                moving_layer
            )
        )

        items.extend(
            _collect_group_targets(
                layers,
                excluded_ids
            )
        )

    _MOVE_TARGET_ITEMS_CACHE = items

    return _MOVE_TARGET_ITEMS_CACHE


def draw_layer_tree(
    layout,
    layers,
    image_id,
    depth=0
):
    """
    Draw the GIMP layer tree with selection, visibility, opacity,
    rename, duplicate, delete, reorder, and group-move controls.
    """

    sibling_count = len(
        layers
    )

    for sibling_index, layer in enumerate(
        layers
    ):

        try:
            layer_id = int(
                layer.get(
                    "id",
                    -1
                )
            )
        except (
            TypeError,
            ValueError
        ):
            layer_id = -1

        if layer_id < 0:
            continue

        selected = bool(
            layer.get(
                "selected",
                False
            )
        )

        visible = bool(
            layer.get(
                "visible",
                False
            )
        )

        is_group = bool(
            layer.get(
                "is_group",
                False
            )
        )

        try:
            opacity = float(
                layer.get(
                    "opacity",
                    100.0
                )
            )
        except (
            TypeError,
            ValueError
        ):
            opacity = 100.0

        opacity = max(
            0.0,
            min(
                100.0,
                opacity
            )
        )

        mode_name = str(
            layer.get(
                "mode",
                "NORMAL"
            )
        )

        layer_box = layout.box()

        # ----------------------------------------------------
        # Main row: active / visible / opacity
        # ----------------------------------------------------

        row = layer_box.row(
            align=True
        )

        if depth > 0:
            row.label(
                text=(
                    "  " * depth
                )
            )

        active_operator = (
            row.operator(
                "blendgimp.set_active_layer",
                text=str(
                    layer.get(
                        "name",
                        "[Unnamed]"
                    )
                ),
                icon=(
                    "RADIOBUT_ON"
                    if selected
                    else
                    "RADIOBUT_OFF"
                )
            )
        )

        active_operator.image_id = (
            int(image_id)
        )

        active_operator.layer_id = (
            layer_id
        )

        visibility_operator = (
            row.operator(
                "blendgimp.set_layer_visibility",
                text="",
                icon=(
                    "HIDE_OFF"
                    if visible
                    else
                    "HIDE_ON"
                )
            )
        )

        visibility_operator.image_id = (
            int(image_id)
        )

        visibility_operator.layer_id = (
            layer_id
        )

        visibility_operator.visible = (
            not visible
        )

        opacity_operator = (
            row.operator(
                "blendgimp.set_layer_opacity",
                text=f"{opacity:.1f}%"
            )
        )

        opacity_operator.image_id = (
            int(image_id)
        )

        opacity_operator.layer_id = (
            layer_id
        )

        opacity_operator.opacity = (
            opacity
        )

        # ----------------------------------------------------
        # Blend mode
        # ----------------------------------------------------

        mode_row = layer_box.row(
            align=True
        )

        mode_row.label(
            text="Blend:"
        )

        mode_operator = (
            mode_row.operator(
                "blendgimp.set_layer_mode",
                text=blendgimp_layer_mode_label(
                    mode_name
                )
            )
        )

        mode_operator.image_id = (
            int(image_id)
        )

        mode_operator.layer_id = (
            layer_id
        )

        mode_operator.mode = (
            mode_name
            if any(
                item[0] == mode_name
                for item in BLENDGIMP_LAYER_MODE_ITEMS
            )
            else "NORMAL"
        )

        # ----------------------------------------------------
        # Editing controls
        # ----------------------------------------------------

        edit_row = layer_box.row(
            align=True
        )

        rename_operator = (
            edit_row.operator(
                "blendgimp.rename_layer",
                text="Rename"
            )
        )

        rename_operator.image_id = (
            int(image_id)
        )

        rename_operator.layer_id = (
            layer_id
        )

        rename_operator.layer_name = str(
            layer.get(
                "name",
                ""
            )
        )

        duplicate_operator = (
            edit_row.operator(
                "blendgimp.duplicate_layer",
                text="Duplicate"
            )
        )

        duplicate_operator.image_id = (
            int(image_id)
        )

        duplicate_operator.layer_id = (
            layer_id
        )

        delete_operator = (
            edit_row.operator(
                "blendgimp.delete_layer",
                text="Delete"
            )
        )

        delete_operator.image_id = (
            int(image_id)
        )

        delete_operator.layer_id = (
            layer_id
        )

        delete_operator.layer_name = str(
            layer.get(
                "name",
                ""
            )
        )

        if sibling_index < (
            sibling_count - 1
        ):

            merge_operator = (
                edit_row.operator(
                    "blendgimp.merge_layer_down",
                    text="Merge Down"
                )
            )

            merge_operator.image_id = (
                int(image_id)
            )

            merge_operator.layer_id = (
                layer_id
            )

            merge_operator.layer_name = str(
                layer.get(
                    "name",
                    ""
                )
            )

        # ----------------------------------------------------
        # Layer locks
        # ----------------------------------------------------

        lock_row = layer_box.row(
            align=True
        )

        lock_row.label(
            text="Locks:"
        )

        for (
            lock_type,
            label,
            field_name
        ) in (
            (
                "CONTENT",
                "Content",
                "lock_content"
            ),
            (
                "POSITION",
                "Position",
                "lock_position"
            ),
            (
                "ALPHA",
                "Alpha",
                "lock_alpha"
            ),
        ):

            current_locked = bool(
                layer.get(
                    field_name,
                    False
                )
            )

            lock_operator = (
                lock_row.operator(
                    "blendgimp.set_layer_lock",
                    text=(
                        f"{label} ON"
                        if current_locked
                        else label
                    ),
                    depress=current_locked
                )
            )

            lock_operator.image_id = (
                int(image_id)
            )

            lock_operator.layer_id = (
                layer_id
            )

            lock_operator.lock_type = (
                lock_type
            )

            lock_operator.locked = (
                not current_locked
            )

        # ----------------------------------------------------
        # Hierarchy / ordering controls
        # ----------------------------------------------------

        move_row = layer_box.row(
            align=True
        )

        if sibling_index > 0:

            up_operator = (
                move_row.operator(
                    "blendgimp.reorder_layer",
                    text="Up"
                )
            )

            up_operator.image_id = (
                int(image_id)
            )

            up_operator.layer_id = (
                layer_id
            )

            up_operator.direction = (
                "UP"
            )

        if sibling_index < (
            sibling_count - 1
        ):

            down_operator = (
                move_row.operator(
                    "blendgimp.reorder_layer",
                    text="Down"
                )
            )

            down_operator.image_id = (
                int(image_id)
            )

            down_operator.layer_id = (
                layer_id
            )

            down_operator.direction = (
                "DOWN"
            )

        move_operator = (
            move_row.operator(
                "blendgimp.move_layer",
                text="Move..."
            )
        )

        move_operator.image_id = (
            int(image_id)
        )

        move_operator.layer_id = (
            layer_id
        )

        # ----------------------------------------------------
        # Metadata
        # ----------------------------------------------------

        info_row = layer_box.row()

        kind = (
            "Group"
            if is_group
            else
            "Layer"
        )

        parent_id = layer.get(
            "parent_id",
            None
        )

        if parent_id is None:
            parent_text = "Top Level"
        else:
            parent_text = (
                f"Parent {parent_id}"
            )

        info_row.label(
            text=(
                f"{kind} ID {layer_id} | "
                f"{parent_text}"
            )
        )

        children = layer.get(
            "children",
            []
        )

        if children:

            draw_layer_tree(
                layer_box,
                children,
                image_id,
                depth + 1
            )


# ============================================================
# PHASE 6.5.2 — COMPACT / NATIVE-FEELING LAYER STACK
# ============================================================

def _iter_layer_stack_rows(layers, depth=0):
    """Yield layer rows in display order while preserving GIMP hierarchy."""
    for sibling_index, layer in enumerate(layers or []):
        yield layer, depth, sibling_index, len(layers or [])
        children = layer.get("children", []) if isinstance(layer, dict) else []
        if children:
            yield from _iter_layer_stack_rows(children, depth + 1)


def _find_selected_layer_any(layers):
    """Return the selected GIMP layer/group, including hierarchy location."""
    for layer, depth, sibling_index, sibling_count in _iter_layer_stack_rows(layers):
        if bool(layer.get("selected", False)):
            return layer, depth, sibling_index, sibling_count
    return None, 0, -1, 0


def draw_layer_stack_compact(layout, layers, image_id):
    """Draw a compact layer stack plus controls for the active GIMP layer.

    Phase 6.5.2 keeps the existing GIMP layer protocol/operators authoritative;
    only the Blender presentation changes.  One compact row represents each
    layer/group, while detailed controls are shown once for the selected layer.
    """
    layers = list(layers or [])
    stack = layout.column(align=True)

    if not layers:
        stack.label(text="No layers returned by GIMP", icon="INFO")
        return

    for layer, depth, _sibling_index, _sibling_count in _iter_layer_stack_rows(layers):
        try:
            layer_id = int(layer.get("id", -1))
        except (TypeError, ValueError):
            continue
        if layer_id < 0:
            continue

        selected = bool(layer.get("selected", False))
        visible = bool(layer.get("visible", False))
        is_group = bool(layer.get("is_group", False))
        name = str(layer.get("name", "[Unnamed]"))
        prefix = "    " * max(0, int(depth))

        row = stack.row(align=True)
        active = row.operator(
            "blendgimp.set_active_layer",
            text=prefix + name,
            icon="FILE_FOLDER" if is_group else "IMAGE_DATA",
            depress=selected,
        )
        active.image_id = int(image_id)
        active.layer_id = layer_id

        visibility = row.operator(
            "blendgimp.set_layer_visibility",
            text="",
            icon="HIDE_OFF" if visible else "HIDE_ON",
            depress=visible,
        )
        visibility.image_id = int(image_id)
        visibility.layer_id = layer_id
        visibility.visible = not visible

    selected_layer, _depth, sibling_index, sibling_count = _find_selected_layer_any(layers)
    if selected_layer is None:
        layout.label(text="Select a layer to edit its properties", icon="INFO")
        return

    try:
        layer_id = int(selected_layer.get("id", -1))
    except (TypeError, ValueError):
        return
    if layer_id < 0:
        return

    name = str(selected_layer.get("name", "[Unnamed]"))
    is_group = bool(selected_layer.get("is_group", False))
    try:
        opacity = max(0.0, min(100.0, float(selected_layer.get("opacity", 100.0))))
    except (TypeError, ValueError):
        opacity = 100.0
    mode_name = str(selected_layer.get("mode", "NORMAL"))

    details = layout.box()
    header = details.row(align=True)
    header.label(
        text=f"Active {'Group' if is_group else 'Layer'}: {name}",
        icon="FILE_FOLDER" if is_group else "IMAGE_DATA",
    )

    props = details.row(align=True)
    opacity_operator = props.operator(
        "blendgimp.set_layer_opacity",
        text=f"Opacity {opacity:.0f}%",
    )
    opacity_operator.image_id = int(image_id)
    opacity_operator.layer_id = layer_id
    opacity_operator.opacity = opacity

    mode_operator = props.operator(
        "blendgimp.set_layer_mode",
        text=blendgimp_layer_mode_label(mode_name),
    )
    mode_operator.image_id = int(image_id)
    mode_operator.layer_id = layer_id
    mode_operator.mode = (
        mode_name
        if any(item[0] == mode_name for item in BLENDGIMP_LAYER_MODE_ITEMS)
        else "NORMAL"
    )

    lock_row = details.row(align=True)
    lock_row.label(text="Locks")
    for lock_type, label, field_name in (
        ("CONTENT", "Pixels", "lock_content"),
        ("POSITION", "Position", "lock_position"),
        ("ALPHA", "Alpha", "lock_alpha"),
    ):
        current_locked = bool(selected_layer.get(field_name, False))
        op = lock_row.operator(
            "blendgimp.set_layer_lock",
            text=label,
            depress=current_locked,
        )
        op.image_id = int(image_id)
        op.layer_id = layer_id
        op.lock_type = lock_type
        op.locked = not current_locked

    actions = details.row(align=True)
    rename = actions.operator("blendgimp.rename_layer", text="Rename")
    rename.image_id = int(image_id)
    rename.layer_id = layer_id
    rename.layer_name = name

    duplicate = actions.operator("blendgimp.duplicate_layer", text="Duplicate")
    duplicate.image_id = int(image_id)
    duplicate.layer_id = layer_id

    delete = actions.operator("blendgimp.delete_layer", text="Delete")
    delete.image_id = int(image_id)
    delete.layer_id = layer_id
    delete.layer_name = name

    order = details.row(align=True)
    if sibling_index > 0:
        up = order.operator("blendgimp.reorder_layer", text="Up")
        up.image_id = int(image_id)
        up.layer_id = layer_id
        up.direction = "UP"
    if 0 <= sibling_index < max(0, sibling_count - 1):
        down = order.operator("blendgimp.reorder_layer", text="Down")
        down.image_id = int(image_id)
        down.layer_id = layer_id
        down.direction = "DOWN"

    move = order.operator("blendgimp.move_layer", text="Move…")
    move.image_id = int(image_id)
    move.layer_id = layer_id

    if 0 <= sibling_index < max(0, sibling_count - 1):
        merge = order.operator("blendgimp.merge_layer_down", text="Merge Down")
        merge.image_id = int(image_id)
        merge.layer_id = layer_id
        merge.layer_name = name


# ============================================================
# DETECT GIMP
# ============================================================

class BLENDGIMP_OT_detect_gimp(
    bpy.types.Operator
):

    bl_idname = "blendgimp.detect_gimp"
    bl_label = "Detect GIMP"

    bl_description = (
        "Search for a supported GIMP installation"
    )

    def execute(
        self,
        context
    ):

        scene = _scene_from_context(context)
        if scene is None:
            self.report({"ERROR"}, "No active Blender scene is available")
            return {"CANCELLED"}

        detected, gimp_path, version = detect_gimp_for_scene(scene)

        if detected:
            print("BLENDGIMP: Manual GIMP detection completed")
            self.report(
                {"INFO"},
                f"GIMP {version or 'Unknown Version'} detected successfully"
            )
        else:
            clear_image_results(scene)
            self.report(
                {"WARNING"},
                "GIMP installation not found"
            )

        return {"FINISHED"}


# ============================================================
# LAUNCH GIMP
# ============================================================

class BLENDGIMP_OT_launch_gimp(
    bpy.types.Operator
):

    bl_idname = "blendgimp.launch_gimp"
    bl_label = "Start GIMP Engine"

    bl_description = (
        "Start the selected persistent GIMP engine mode and connect to it"
    )

    def execute(
        self,
        context
    ):

        scene = _scene_from_context(context)
        if scene is None:
            self.report({"ERROR"}, "No active Blender scene is available")
            return {"CANCELLED"}

        success, pid = start_scene_engine(
            scene
        )

        if success:
            self.report(
                {"INFO"},
                (
                    "GIMP engine starting "
                    f"PID {pid} "
                    f"({blendgimp_preferences.engine_mode(context=context, scene=scene)})"
                )
            )

            return {"FINISHED"}

        self.report(
            {"ERROR"},
            (
                scene.blendgimp_engine_last_error
                or "Could not launch GIMP engine"
            )
        )

        return {"CANCELLED"}


# ============================================================
# STOP GIMP ENGINE
# ============================================================

class BLENDGIMP_OT_stop_gimp(
    bpy.types.Operator
):

    bl_idname = "blendgimp.stop_gimp"
    bl_label = "Stop GIMP Engine"

    bl_description = (
        "Disconnect and stop the GIMP process started by BlendGimp"
    )

    def execute(
        self,
        context
    ):
        scene = _scene_from_context(context)
        if scene is None:
            self.report({"ERROR"}, "No active Blender scene is available")
            return {"CANCELLED"}

        success, _exit_code, forced = (
            stop_scene_engine(
                scene
            )
        )

        if not success:
            self.report(
                {"ERROR"},
                (
                    scene.blendgimp_engine_last_error
                    or "Could not stop GIMP engine"
                )
            )
            return {"CANCELLED"}

        self.report(
            {"WARNING" if forced else "INFO"},
            (
                "GIMP engine stopped"
                + (
                    " after forced timeout"
                    if forced
                    else ""
                )
            )
        )
        return {"FINISHED"}


# ============================================================
# FORCE STOP GIMP ENGINE
# ============================================================

class BLENDGIMP_OT_force_stop_gimp(
    bpy.types.Operator
):

    bl_idname = "blendgimp.force_stop_gimp"
    bl_label = "Force Stop GIMP Engine"

    bl_description = (
        "Force GIMP to close even when headless documents have unsaved "
        "changes. Unsaved GIMP image changes will be discarded."
    )

    def invoke(
        self,
        context,
        event
    ):
        return context.window_manager.invoke_confirm(
            self,
            event
        )

    def execute(
        self,
        context
    ):
        dirty_count = 0
        try:
            if connection_manager.is_connected():
                images = connection_manager.get_images().get("images", [])
                dirty_count = sum(
                    1 for image in images
                    if bool(image.get("dirty", False))
                )
        except Exception:
            dirty_count = 0

        scene = _scene_from_context(context)
        if scene is None:
            self.report({"ERROR"}, "No active Blender scene is available")
            return {"CANCELLED"}

        success, _exit_code, process_forced = stop_scene_engine(
            scene,
            force=True
        )

        if not success:
            self.report(
                {"ERROR"},
                (
                    scene.blendgimp_engine_last_error
                    or "Could not force-stop GIMP engine"
                )
            )
            return {"CANCELLED"}

        if dirty_count > 0:
            self.report(
                {"WARNING"},
                (
                    f"GIMP engine stopped with discard permission; "
                    f"{dirty_count} unsaved image(s) discarded"
                )
            )
        elif process_forced:
            self.report(
                {"WARNING"},
                "GIMP process required forced termination after timeout"
            )
        else:
            self.report(
                {"INFO"},
                "GIMP engine stopped cleanly; no unsaved image changes"
            )
        return {"FINISHED"}


# ============================================================
# RESTART GIMP ENGINE
# ============================================================

class BLENDGIMP_OT_restart_gimp(
    bpy.types.Operator
):

    bl_idname = "blendgimp.restart_gimp"
    bl_label = "Restart GIMP Engine"

    bl_description = (
        "Restart GIMP in the selected engine mode and reconnect"
    )

    def execute(
        self,
        context
    ):
        scene = _scene_from_context(context)
        if scene is None:
            self.report({"ERROR"}, "No active Blender scene is available")
            return {"CANCELLED"}

        success, _exit_code, _forced = (
            stop_scene_engine(
                scene
            )
        )

        if not success:
            self.report(
                {"ERROR"},
                (
                    scene.blendgimp_engine_last_error
                    or "Could not stop GIMP engine"
                )
            )
            return {"CANCELLED"}

        success, pid = start_scene_engine(
            scene
        )

        if not success:
            self.report(
                {"ERROR"},
                (
                    scene.blendgimp_engine_last_error
                    or "Could not restart GIMP engine"
                )
            )
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            (
                "GIMP engine restarting "
                f"PID {pid} "
                f"({blendgimp_preferences.engine_mode(context=context, scene=scene)})"
            )
        )
        return {"FINISHED"}


# ============================================================
# CHECK PROCESS
# ============================================================

class BLENDGIMP_OT_check_gimp(
    bpy.types.Operator
):

    bl_idname = "blendgimp.check_gimp"
    bl_label = "Check GIMP Status"

    def execute(
        self,
        context
    ):

        scene = _scene_from_context(context)
        if scene is None:
            self.report({"ERROR"}, "No active Blender scene is available")
            return {"CANCELLED"}

        snapshot = (
            gimp_manager.get_engine_snapshot()
        )
        running = bool(
            snapshot.get(
                "running",
                False
            )
        )

        scene.blendgimp_gimp_running = (
            running
        )

        if running:

            scene.blendgimp_engine_state = str(
                snapshot.get(
                    "state",
                    gimp_manager.ENGINE_STATE_STARTING
                )
            )

            self.report(
                {"INFO"},
                (
                    "GIMP engine is running "
                    f"PID {snapshot.get('pid')}"
                )
            )

        else:

            scene.blendgimp_engine_state = str(
                snapshot.get(
                    "state",
                    gimp_manager.ENGINE_STATE_STOPPED
                )
            )
            scene.blendgimp_engine_last_error = str(
                snapshot.get(
                    "last_error",
                    ""
                )
            )

            self.report(
                {"INFO"},
                "GIMP engine is not running"
            )

        return {"FINISHED"}


# ============================================================
# CONNECT TO GIMP
# ============================================================

class BLENDGIMP_OT_connect(
    bpy.types.Operator
):

    bl_idname = "blendgimp.connect"
    bl_label = "Connect to GIMP"

    bl_description = (
        "Connect Blender to the BlendGimp GIMP component"
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = connect_scene_engine(
                scene
            )

            scene.blendgimp_engine_should_run = True

            self.report(
                {"INFO"},
                "BlendGimp connected to GIMP"
            )

            return {"FINISHED"}

        except Exception as exc:

            clear_engine_connection(
                scene
            )

            print(
                "BLENDGIMP: "
                f"Connection failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"Connection failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# PING GIMP
# ============================================================

class BLENDGIMP_OT_ping(
    bpy.types.Operator
):

    bl_idname = "blendgimp.ping"
    bl_label = "Ping GIMP"

    bl_description = (
        "Test the active BlendGimp connection"
    )

    def execute(
        self,
        context
    ):

        scene = _scene_from_context(context)
        if scene is None:
            self.report({"ERROR"}, "No active Blender scene is available")
            return {"CANCELLED"}

        try:

            response = (
                connection_manager.ping()
            )

            scene.blendgimp_connected = True

            print(
                "BLENDGIMP: "
                f"PING response = {response}"
            )

            self.report(
                {"INFO"},
                "PONG received from GIMP"
            )

            return {"FINISHED"}

        except Exception as exc:

            scene.blendgimp_connected = False

            print(
                "BLENDGIMP: "
                f"PING failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"PING failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# ACTIVE IMAGE / MATERIAL UI HELPERS
# ============================================================

def _image_gimp_id(image):
    if image is None:
        return -1
    try:
        return int(image.get("blendgimp_gimp_image_id", -1))
    except Exception:
        return -1


def _resolve_active_gimp_image_id(context):
    """Resolve the production-facing BlendGimp image without exposing IDs."""
    scene = getattr(context, "scene", None)
    if scene is None:
        return -1

    # The BlendGimp Image Editor is the strongest artist-facing signal.
    space = getattr(context, "space_data", None)
    if getattr(space, "type", "") == "IMAGE_EDITOR":
        image_id = _image_gimp_id(getattr(space, "image", None))
        if image_id >= 0:
            return image_id

    # Next prefer the active material's selected Image Texture node. This keeps
    # the compact Image & Material card aligned with the selected object.
    obj = getattr(context, "active_object", None)
    material = getattr(obj, "active_material", None) if obj is not None else None
    try:
        if material is not None and material.use_nodes and material.node_tree is not None:
            nodes = material.node_tree.nodes
            candidates = []
            active_node = getattr(nodes, "active", None)
            if active_node is not None:
                candidates.append(active_node)
            candidates.extend(node for node in nodes if node is not active_node)
            for node in candidates:
                if getattr(node, "type", "") != "TEX_IMAGE":
                    continue
                image_id = _image_gimp_id(getattr(node, "image", None))
                if image_id >= 0:
                    return image_id
                try:
                    image_id = int(node.get("blendgimp_gimp_image_id", -1))
                except Exception:
                    image_id = -1
                if image_id >= 0:
                    return image_id
    except Exception:
        pass

    # BlendGimp's editor/session ownership is the next fallback.
    for attr in (
        "blendgimp_texture_editor_image_id",
        "blendgimp_auto_sync_image_id",
        "blendgimp_created_image_id",
    ):
        try:
            image_id = int(getattr(scene, attr, -1))
        except Exception:
            image_id = -1
        if image_id >= 0:
            return image_id

    # If there is exactly one open GIMP image, it is unambiguous.
    try:
        images = get_stored_images(scene)
        if len(images) == 1:
            return int(images[0].get("id", -1))
    except Exception:
        pass

    return -1


def _resolve_active_blender_image(context, image_id=None):
    if image_id is None:
        image_id = _resolve_active_gimp_image_id(context)
    try:
        image_id = int(image_id)
    except Exception:
        image_id = -1
    if image_id < 0:
        return None

    scene = getattr(context, "scene", None)
    sync_result = get_texture_sync_result(scene, image_id) or {} if scene is not None else {}
    image = _find_blendgimp_image(image_id, sync_result.get("sync_token", ""))
    if image is not None:
        return image

    # Final direct lookup by persistent image metadata.
    try:
        for candidate in bpy.data.images:
            if _image_gimp_id(candidate) == image_id:
                return candidate
    except Exception:
        pass
    return None


def _stored_gimp_image_name(scene, image_id):
    try:
        image_id = int(image_id)
        for item in get_stored_images(scene):
            if int(item.get("id", -1)) == image_id:
                return str(item.get("name", "") or "")
    except Exception:
        pass
    return ""


# ============================================================
# CREATE BLENDER-OWNED GIMP IMAGE
# ============================================================

class BLENDGIMP_OT_create_image(
    bpy.types.Operator
):

    bl_idname = "blendgimp.create_image"
    bl_label = "Create BlendGimp Texture"

    bl_description = (
        "Create a new GIMP image and initial layer, create its paired Blender "
        "Image, assign it to the active material, and start Auto Sync"
    )

    texture_name: bpy.props.StringProperty(
        name="Name",
        default="BaseColor"
    )
    texture_width: bpy.props.IntProperty(
        name="Width",
        default=2048,
        min=1,
        max=32768
    )
    texture_height: bpy.props.IntProperty(
        name="Height",
        default=2048,
        min=1,
        max=32768
    )
    texture_format: bpy.props.EnumProperty(
        name="Format",
        items=(
            ("RGBA", "RGBA", "RGB color with an alpha channel"),
            ("RGB", "RGB", "Opaque RGB color without an alpha channel"),
        ),
        default="RGBA"
    )
    texture_background: bpy.props.EnumProperty(
        name="Background",
        items=(
            ("TRANSPARENT", "Transparent", "Transparent initial layer"),
            ("SOLID", "Solid", "Solid initial layer"),
        ),
        default="TRANSPARENT"
    )
    texture_background_color: bpy.props.FloatVectorProperty(
        name="Background Color",
        subtype="COLOR",
        size=4,
        min=0.0,
        max=1.0,
        default=(0.0, 0.0, 0.0, 1.0)
    )
    initial_layer_name: bpy.props.StringProperty(
        name="Initial Layer",
        default="BaseColor"
    )

    def invoke(self, context, event):
        if not connection_manager.is_connected():
            self.report({"ERROR"}, "BlendGimp is not connected to GIMP")
            return {"CANCELLED"}

        scene = context.scene
        self.texture_name = str(scene.blendgimp_create_name or "BaseColor")
        self.texture_width = int(scene.blendgimp_create_width)
        self.texture_height = int(scene.blendgimp_create_height)
        self.texture_format = str(scene.blendgimp_create_format)
        self.texture_background = str(scene.blendgimp_create_background)
        self.texture_background_color = tuple(scene.blendgimp_create_background_color)
        self.initial_layer_name = str(scene.blendgimp_create_layer_name or self.texture_name)
        return context.window_manager.invoke_props_dialog(
            self,
            width=420,
            title="Create BlendGimp Image",
            confirm_text="Create",
        )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "texture_name")
        size = layout.row(align=True)
        size.prop(self, "texture_width")
        size.prop(self, "texture_height")
        layout.prop(self, "texture_format")
        layout.prop(self, "texture_background")
        if self.texture_background == "SOLID":
            layout.prop(self, "texture_background_color", text="Color")
        if self.texture_format == "RGB" and self.texture_background == "TRANSPARENT":
            warning = layout.box()
            warning.alert = True
            warning.label(text="RGB requires a solid background", icon="ERROR")
        layout.prop(self, "initial_layer_name")

    def execute(
        self,
        context
    ):

        scene = context.scene

        # The create form now lives in an operator dialog instead of occupying
        # permanent sidebar space. Mirror the accepted values back to the
        # existing Scene properties so the protected creation pipeline and the
        # next dialog invocation keep the same defaults.
        scene.blendgimp_create_name = str(self.texture_name or "BaseColor")
        scene.blendgimp_create_width = int(self.texture_width)
        scene.blendgimp_create_height = int(self.texture_height)
        scene.blendgimp_create_format = str(self.texture_format)
        scene.blendgimp_create_background = str(self.texture_background)
        scene.blendgimp_create_background_color = tuple(self.texture_background_color)
        scene.blendgimp_create_layer_name = str(self.initial_layer_name or self.texture_name or "BaseColor")

        if not connection_manager.is_connected():
            scene.blendgimp_connected = False
            scene.blendgimp_create_status = "Create failed: not connected"
            self.report(
                {"ERROR"},
                "BlendGimp is not connected to GIMP"
            )
            return {"CANCELLED"}

        if (
            scene.blendgimp_create_format == "RGB"
            and scene.blendgimp_create_background == "TRANSPARENT"
        ):
            scene.blendgimp_create_status = (
                "Create failed: RGB requires a solid background"
            )
            self.report(
                {"ERROR"},
                "RGB textures require a solid background"
            )
            return {"CANCELLED"}

        scene.blendgimp_create_status = "Creating texture in GIMP..."

        try:
            response = connection_manager.create_image(
                name=scene.blendgimp_create_name,
                width=scene.blendgimp_create_width,
                height=scene.blendgimp_create_height,
                image_format=scene.blendgimp_create_format,
                background=scene.blendgimp_create_background,
                background_color=scene.blendgimp_create_background_color,
                layer_name=scene.blendgimp_create_layer_name,
            )

            image_id = int(response["image_id"])
            layer_id = int(response["layer_id"])

            scene.blendgimp_created_image_id = image_id
            scene.blendgimp_created_layer_id = layer_id

            # Populate the normal image cards immediately. The created image
            # uses the same painting and synchronization paths as any other
            # open GIMP image.
            images_response = connection_manager.get_images()
            images = images_response.get("images", [])
            scene.blendgimp_images_queried = True
            scene.blendgimp_image_count = len(images)
            scene.blendgimp_images_json = json.dumps(
                images,
                ensure_ascii=False
            )

            sync_result = synchronize_gimp_composite(
                context,
                image_id,
                assign_material=True
            )

            blender_image = sync_result["blender_image"]
            texture_name = str(
                scene.blendgimp_create_name
                or "BlendGimp Texture"
            ).strip()

            blender_image["blendgimp_created_by_blender"] = True
            blender_image["blendgimp_texture_name"] = texture_name
            blender_image["blendgimp_gimp_image_id"] = image_id
            blender_image["blendgimp_gimp_layer_id"] = layer_id
            blender_image["blendgimp_texture_format"] = str(
                scene.blendgimp_create_format
            )
            blender_image.name = texture_name
            blender_image.update()

            created_sync_result = (
                get_texture_sync_result(
                    scene,
                    image_id
                )
                or {}
            )
            created_sync_result["blender_image"] = blender_image.name
            created_sync_result["owner_object"] = str(
                blender_image.get(
                    "blendgimp_owner_object",
                    ""
                )
                or ""
            )
            created_sync_result["material"] = str(
                blender_image.get(
                    "blendgimp_owner_material",
                    created_sync_result.get("material", "")
                )
                or ""
            )
            store_texture_sync_result(
                scene,
                image_id,
                created_sync_result
            )

            state = connection_manager.get_image_state(image_id)
            revision = int(state.get("revision", 0))

            scene.blendgimp_auto_sync_enabled = True
            scene.blendgimp_auto_sync_image_id = image_id
            scene.blendgimp_auto_sync_revision = revision
            scene.blendgimp_auto_sync_status = (
                f"Watching revision {revision}"
            )
            scene.blendgimp_auto_sync_detector = str(
                state.get("detector", "")
            )

            reset_auto_sync_runtime(
                image_id,
                revision
            )

            scene.blendgimp_create_status = (
                f"Created {texture_name} — image {image_id}, layer {layer_id}"
            )

            print(
                "BLENDGIMP: "
                f"Blender-owned texture created: {texture_name} "
                f"image ID={image_id} layer ID={layer_id}; Auto Sync started"
            )

            self.report(
                {"INFO"},
                f"Created {texture_name} and started Auto Sync"
            )
            return {"FINISHED"}

        except Exception as exc:
            scene.blendgimp_connected = connection_manager.is_connected()
            scene.blendgimp_create_status = f"Create failed: {exc}"

            print(
                "BLENDGIMP: "
                f"CREATE_IMAGE workflow failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"Create BlendGimp Texture failed: {exc}"
            )
            return {"CANCELLED"}


# ============================================================
# GET GIMP IMAGES
# ============================================================

class BLENDGIMP_OT_get_images(
    bpy.types.Operator
):

    bl_idname = "blendgimp.get_images"
    bl_label = "Get GIMP Images"

    bl_description = (
        "Read the list of images currently open in GIMP"
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            print(
                "BLENDGIMP: "
                "Requesting open GIMP images"
            )

            response = (
                connection_manager.get_images()
            )

            images = response.get(
                "images",
                []
            )

            scene.blendgimp_connected = True
            scene.blendgimp_images_queried = True
            scene.blendgimp_image_count = (
                len(images)
            )
            scene.blendgimp_images_json = (
                json.dumps(
                    images,
                    ensure_ascii=False
                )
            )

            print(
                "BLENDGIMP: "
                f"GIMP Images = {len(images)}"
            )

            for image in images:

                print(
                    "BLENDGIMP: "
                    f"Image ID={image.get('id')} "
                    f"Name={image.get('name')} "
                    f"Size={image.get('width')}x"
                    f"{image.get('height')}"
                )

            if images:

                self.report(
                    {"INFO"},
                    (
                        f"GIMP returned "
                        f"{len(images)} open image(s)"
                    )
                )

            else:

                self.report(
                    {"INFO"},
                    "GIMP has no images open"
                )

            return {"FINISHED"}

        except Exception as exc:

            scene.blendgimp_connected = False

            print(
                "BLENDGIMP: "
                f"GET_IMAGES failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"GET_IMAGES failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# OPEN / SAVE GIMP IMAGE(S) AS NATIVE XCF
# ============================================================

class BLENDGIMP_OT_open_xcf(
    bpy.types.Operator
):

    bl_idname = "blendgimp.open_xcf"
    bl_label = "Open BlendGimp XCF"
    bl_description = (
        "Open a layered XCF in the headless GIMP engine, synchronize its "
        "composite into Blender, assign it to the active material, and "
        "restart Auto Sync"
    )

    filepath: bpy.props.StringProperty(
        name="XCF File",
        subtype="FILE_PATH",
        default=""
    )

    filter_glob: bpy.props.StringProperty(
        default="*.xcf",
        options={"HIDDEN"}
    )

    def invoke(self, context, event):
        if not connection_manager.is_connected():
            self.report({"ERROR"}, "BlendGimp is not connected to GIMP")
            return {"CANCELLED"}

        save_dir = _default_blendgimp_save_directory()
        if os.path.isdir(save_dir):
            self.filepath = os.path.join(save_dir, "")
        else:
            documents = os.path.join(os.path.expanduser("~"), "Documents")
            self.filepath = os.path.join(
                documents if os.path.isdir(documents) else os.path.expanduser("~"),
                ""
            )

        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        scene = context.scene
        path = os.path.abspath(
            os.path.expanduser(str(self.filepath or "").strip())
        )

        if not path:
            self.report({"ERROR"}, "Choose an XCF file to open")
            return {"CANCELLED"}
        if not path.lower().endswith(".xcf"):
            self.report({"ERROR"}, "Open XCF requires a .xcf file")
            return {"CANCELLED"}
        if not os.path.isfile(path):
            self.report({"ERROR"}, f"XCF file not found: {path}")
            return {"CANCELLED"}
        if not connection_manager.is_connected():
            self.report({"ERROR"}, "BlendGimp is not connected to GIMP")
            return {"CANCELLED"}

        try:
            response = connection_manager.open_xcf(path)
            image_id = int(response["image_id"])

            # A GIMP engine restart may reuse process-local image IDs. Retire
            # old active-layer sync ownership before adopting the newly loaded
            # document so a stale Blender working buffer cannot be reused.
            scene.blendgimp_blender_paint_sync_enabled = False
            scene.blendgimp_blender_paint_sync_image_id = -1
            scene.blendgimp_blender_paint_sync_layer_id = -1
            scene.blendgimp_blender_paint_sync_status = "Opening XCF"
            reset_blender_paint_sync_runtime()
            _drop_dirty_pixel_cache_for_image(image_id)

            images = _refresh_gimp_images_snapshot(scene)

            sync_result = synchronize_gimp_composite(
                context,
                image_id,
                assign_material=True
            )
            blender_image = sync_result["blender_image"]

            _store_saved_xcf_path(scene, image_id, response)
            reopened_path = str(response.get("path", path) or path)
            texture_name = os.path.splitext(os.path.basename(reopened_path))[0]
            blender_image["blendgimp_xcf_path"] = reopened_path
            blender_image["blendgimp_gimp_image_id"] = image_id
            blender_image["blendgimp_reopened_xcf"] = True
            blender_image["blendgimp_texture_name"] = texture_name
            blender_image.name = texture_name
            blender_image.update()

            reopened_sync_result = dict(
                get_texture_sync_result(scene, image_id) or {}
            )
            reopened_sync_result["blender_image"] = blender_image.name
            reopened_sync_result["xcf_path"] = reopened_path
            store_texture_sync_result(scene, image_id, reopened_sync_result)

            # Populate the layer panel immediately, preserving GIMP's saved
            # selected raster/group item. Group selection intentionally leaves
            # the raster paint buffer suspended until a raster layer is chosen.
            layer_response = connection_manager.get_image_layers(image_id)
            store_layer_result(scene, image_id, layer_response)

            state = connection_manager.get_image_state(image_id)
            revision = int(state.get("revision", 0))
            scene.blendgimp_auto_sync_enabled = True
            scene.blendgimp_auto_sync_image_id = image_id
            scene.blendgimp_auto_sync_revision = revision
            scene.blendgimp_auto_sync_status = f"Watching revision {revision}"
            scene.blendgimp_auto_sync_detector = str(state.get("detector", ""))
            reset_auto_sync_runtime(image_id, revision)

            # Follow the reopened document in the BlendGimp texture editor.
            if hasattr(scene, "blendgimp_texture_editor_image_id"):
                scene.blendgimp_texture_editor_image_id = image_id

            image_name = str(response.get("image_name", "") or os.path.basename(path))
            layer_count = int(layer_response.get("layer_count", 0))
            already_open = bool(response.get("already_open", False))
            print(
                "BLENDGIMP: Opened XCF and adopted document "
                f"image ID {image_id} name={image_name!r} "
                f"layers={layer_count} revision={revision} "
                f"already_open={already_open} path={response.get('path', path)}"
            )
            self.report(
                {"INFO"},
                f"Opened XCF: {os.path.basename(path)} ({layer_count} layers)"
            )
            return {"FINISHED"}

        except Exception as exc:
            scene.blendgimp_connected = connection_manager.is_connected()
            print(f"BLENDGIMP: OPEN_XCF workflow failed: {exc}")
            self.report({"ERROR"}, f"Open XCF failed: {exc}")
            return {"CANCELLED"}


class BLENDGIMP_OT_save_image_as(
    bpy.types.Operator
):

    bl_idname = "blendgimp.save_image_as"
    bl_label = "Save BlendGimp Image As XCF"
    bl_description = "Save this GIMP image as native XCF, preserving layers"

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    filepath: bpy.props.StringProperty(
        name="XCF File",
        subtype="FILE_PATH",
        default=""
    )

    filter_glob: bpy.props.StringProperty(
        default="*.xcf",
        options={"HIDDEN"}
    )

    def invoke(self, context, event):
        scene = context.scene
        if int(self.image_id) < 0:
            self.image_id = _resolve_active_gimp_image_id(context)
        if int(self.image_id) < 0:
            self.report({"ERROR"}, "No active BlendGimp image")
            return {"CANCELLED"}
        images = get_stored_images(scene)
        image = next(
            (item for item in images if int(item.get("id", -1)) == int(self.image_id)),
            {"id": int(self.image_id), "name": f"Image-{self.image_id}"}
        )

        current_path = str(image.get("xcf_path", "") or "")
        if current_path:
            self.filepath = current_path
        else:
            save_dir = _default_blendgimp_save_directory()
            os.makedirs(save_dir, exist_ok=True)
            self.filepath = os.path.join(
                save_dir,
                _default_xcf_filename(scene, image)
            )

        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        if int(self.image_id) < 0:
            self.report({"ERROR"}, "Invalid GIMP image ID")
            return {"CANCELLED"}

        path = str(self.filepath or "").strip()
        if not path:
            self.report({"ERROR"}, "Choose an XCF save path")
            return {"CANCELLED"}

        if not path.lower().endswith(".xcf"):
            path += ".xcf"

        try:
            response = save_gimp_image_xcf(
                context.scene,
                self.image_id,
                path
            )
            saved_path = str(response.get("path", path))
            print(
                "BLENDGIMP: Saved GIMP image ID "
                f"{self.image_id} -> {saved_path}"
            )
            self.report({"INFO"}, f"Saved XCF: {os.path.basename(saved_path)}")
            return {"FINISHED"}
        except Exception as exc:
            self.report({"ERROR"}, f"Save As failed: {exc}")
            return {"CANCELLED"}


class BLENDGIMP_OT_save_image(
    bpy.types.Operator
):

    bl_idname = "blendgimp.save_image"
    bl_label = "Save BlendGimp Image"
    bl_description = "Save this GIMP image to its existing XCF path"

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(self, context):
        scene = context.scene
        if int(self.image_id) < 0:
            self.image_id = _resolve_active_gimp_image_id(context)
        if int(self.image_id) < 0:
            self.report({"ERROR"}, "No active BlendGimp image")
            return {"CANCELLED"}
        image = next(
            (item for item in get_stored_images(scene)
             if int(item.get("id", -1)) == int(self.image_id)),
            None
        )

        if image is None:
            try:
                images = _refresh_gimp_images_snapshot(scene)
                image = next(
                    (item for item in images
                     if int(item.get("id", -1)) == int(self.image_id)),
                    None
                )
            except Exception:
                image = None

        if not image or not str(image.get("xcf_path", "") or ""):
            return bpy.ops.blendgimp.save_image_as(
                "INVOKE_DEFAULT",
                image_id=int(self.image_id)
            )

        try:
            response = save_gimp_image_xcf(scene, self.image_id, "")
            saved_path = str(response.get("path", image.get("xcf_path", "")))
            self.report({"INFO"}, f"Saved XCF: {os.path.basename(saved_path)}")
            return {"FINISHED"}
        except Exception as exc:
            self.report({"ERROR"}, f"Save failed: {exc}")
            return {"CANCELLED"}


class BLENDGIMP_OT_save_all_images(
    bpy.types.Operator
):

    bl_idname = "blendgimp.save_all_images"
    bl_label = "Save All BlendGimp Images"
    bl_description = (
        "Save all open GIMP documents as native XCF. Existing XCF files save "
        "in place; newly created images are saved into the chosen folder."
    )

    directory: bpy.props.StringProperty(
        name="Folder for Unsaved XCF Images",
        subtype="DIR_PATH",
        default=""
    )

    def invoke(self, context, event):
        try:
            images = _refresh_gimp_images_snapshot(context.scene)
        except Exception as exc:
            self.report({"ERROR"}, f"Could not query GIMP images: {exc}")
            return {"CANCELLED"}

        unsaved = [item for item in images if not str(item.get("xcf_path", "") or "")]
        if not unsaved:
            return self.execute(context)

        self.directory = _default_blendgimp_save_directory()
        os.makedirs(self.directory, exist_ok=True)
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        scene = context.scene
        try:
            images = _refresh_gimp_images_snapshot(scene)
        except Exception as exc:
            self.report({"ERROR"}, f"Could not query GIMP images: {exc}")
            return {"CANCELLED"}

        if not images:
            self.report({"INFO"}, "GIMP has no images open")
            return {"FINISHED"}

        unsaved = [item for item in images if not str(item.get("xcf_path", "") or "")]
        save_dir = str(self.directory or "").strip()
        if unsaved and not save_dir:
            self.report({"ERROR"}, "Choose a folder for newly created XCF images")
            return {"CANCELLED"}

        if save_dir:
            save_dir = os.path.abspath(os.path.expanduser(save_dir))
            os.makedirs(save_dir, exist_ok=True)

        saved = 0
        failures = []
        used_paths = set()

        for image in images:
            image_id = int(image.get("id", -1))
            current_path = str(image.get("xcf_path", "") or "")
            try:
                if current_path:
                    save_gimp_image_xcf(scene, image_id, "")
                else:
                    filename = _default_xcf_filename(scene, image)
                    candidate = os.path.join(save_dir, filename)
                    stem, ext = os.path.splitext(candidate)
                    suffix = 2
                    while candidate.lower() in used_paths or os.path.exists(candidate):
                        candidate = f"{stem}-{suffix}{ext}"
                        suffix += 1
                    used_paths.add(candidate.lower())
                    save_gimp_image_xcf(scene, image_id, candidate)
                saved += 1
            except Exception as exc:
                failures.append(f"ID {image_id}: {exc}")

        try:
            _refresh_gimp_images_snapshot(scene)
        except Exception:
            pass

        if failures:
            self.report(
                {"WARNING"},
                f"Saved {saved} image(s); {len(failures)} failed. See console."
            )
            for failure in failures:
                print("BLENDGIMP: Save All failure: " + failure)
            return {"CANCELLED"}

        self.report({"INFO"}, f"Saved {saved} BlendGimp image(s) as XCF")
        return {"FINISHED"}


class BLENDGIMP_MT_image_xcf(bpy.types.Menu):
    """BlendGimp XCF file operations under the Image Editor's Image menu."""

    bl_idname = "BLENDGIMP_MT_image_xcf"
    bl_label = "BlendGimp XCF"

    def draw(self, context):
        layout = self.layout
        # Dynamic menus default to EXEC context. XCF Open/Save As need their
        # invoke() methods so Blender can show file selectors.
        layout.operator_context = "INVOKE_DEFAULT"
        connected = connection_manager.is_connected()
        image_id = _resolve_active_gimp_image_id(context)

        open_row = layout.row()
        open_row.enabled = connected
        open_row.operator(
            "blendgimp.open_xcf",
            text="Open XCF...",
            icon="FILE_FOLDER",
        )

        layout.separator()

        save_col = layout.column(align=True)
        save_col.enabled = bool(connected and image_id >= 0)
        save_op = save_col.operator(
            "blendgimp.save_image",
            text="Save XCF",
            icon="FILE_TICK",
        )
        save_op.image_id = image_id
        save_as_op = save_col.operator(
            "blendgimp.save_image_as",
            text="Save XCF As...",
            icon="FILE",
        )
        save_as_op.image_id = image_id

        layout.separator()

        all_row = layout.row()
        all_row.enabled = connected
        all_row.operator(
            "blendgimp.save_all_images",
            text="Save All XCF",
            icon="FILE_TICK",
        )

        refresh_row = layout.row()
        refresh_row.enabled = connected
        refresh_row.operator(
            "blendgimp.get_images",
            text="Refresh GIMP Image List",
            icon="FILE_REFRESH",
        )


def draw_blendgimp_image_menu(self, context):
    """Add BlendGimp XCF actions to Image Editor > Image."""
    self.layout.separator()
    self.layout.menu(
        "BLENDGIMP_MT_image_xcf",
        text="BlendGimp XCF",
        icon="IMAGE_DATA",
    )


class BLENDGIMP_OT_assign_active_image_to_material(
    bpy.types.Operator
):

    bl_idname = "blendgimp.assign_active_image_to_material"
    bl_label = "Assign to Material"
    bl_description = (
        "Assign the active BlendGimp texture to its protected owning material; "
        "if it has no owner yet, use the active object/material"
    )

    def execute(self, context):
        scene = context.scene
        image_id = _resolve_active_gimp_image_id(context)
        if image_id < 0:
            self.report({"ERROR"}, "No active BlendGimp image")
            return {"CANCELLED"}

        blender_image = _resolve_active_blender_image(context, image_id)
        if blender_image is None:
            if not connection_manager.is_connected():
                self.report({"ERROR"}, "BlendGimp is not connected to GIMP")
                return {"CANCELLED"}
            try:
                result = synchronize_gimp_composite(
                    context,
                    image_id,
                    assign_material=True,
                )
                assignment = result.get("assignment", {})
            except Exception as exc:
                self.report({"ERROR"}, f"Assign to Material failed: {exc}")
                return {"CANCELLED"}
        else:
            assignment = assign_blendgimp_image_to_active_material(
                context,
                blender_image,
                image_id,
            )

        if not assignment.get("assigned", False):
            self.report(
                {"WARNING"},
                str(assignment.get("reason", "Material assignment skipped")),
            )
            return {"CANCELLED"}

        sync_result = dict(get_texture_sync_result(scene, image_id) or {})
        sync_result.update(assignment)
        if blender_image is not None:
            sync_result["blender_image"] = blender_image.name
        store_texture_sync_result(scene, image_id, sync_result)
        tag_texture_views_for_redraw(context)
        self.report(
            {"INFO"},
            f"Assigned BlendGimp texture to {assignment.get('material', 'material')}",
        )
        return {"FINISHED"}


# ============================================================
# REFRESH GIMP COMPOSITE INTO BLENDER
# ============================================================

class BLENDGIMP_OT_activate_texture_owner(
    bpy.types.Operator
):

    bl_idname = "blendgimp.activate_texture_owner"
    bl_label = "Activate Texture Owner"

    bl_description = (
        "Select the Blender object and material that own this BlendGimp texture"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(
        self,
        context
    ):
        scene = context.scene
        image_id = int(self.image_id)
        sync_result = get_texture_sync_result(
            scene,
            image_id
        ) or {}
        blender_image = _find_blendgimp_image(
            image_id,
            sync_result.get("sync_token", "")
        )

        if blender_image is None:
            self.report(
                {"ERROR"},
                "Refresh this texture from GIMP before activating its owner"
            )
            return {"CANCELLED"}

        obj, material = activate_blendgimp_image_owner(
            context,
            blender_image,
            image_id,
            fallback_to_active=False
        )

        if obj is None:
            self.report(
                {"ERROR"},
                "This BlendGimp texture does not have a Blender object owner"
            )
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            (
                f"Activated {obj.name}"
                + (f" / {material.name}" if material is not None else "")
            )
        )
        return {"FINISHED"}


class BLENDGIMP_OT_refresh_from_gimp(
    bpy.types.Operator
):

    bl_idname = "blendgimp.refresh_from_gimp"
    bl_label = "Refresh From GIMP"

    bl_description = (
        "Export GIMP's visible composite, reload it into Blender, "
        "and assign it to the active material"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        if int(self.image_id) < 0:
            self.image_id = _resolve_active_gimp_image_id(context)
        if int(self.image_id) < 0:
            self.report({"ERROR"}, "No active BlendGimp image")
            return {"CANCELLED"}

        if not connection_manager.is_connected():

            scene.blendgimp_connected = False

            self.report(
                {"ERROR"},
                "BlendGimp is not connected to GIMP"
            )

            return {"CANCELLED"}

        try:

            result = (
                synchronize_gimp_composite(
                    context,
                    self.image_id,
                    assign_material=True
                )
            )

            blender_image = result[
                "blender_image"
            ]

            assignment = result[
                "assignment"
            ]

            if (
                scene.blendgimp_auto_sync_enabled
                and int(
                    scene.blendgimp_auto_sync_image_id
                ) == int(
                    self.image_id
                )
                and connection_manager.is_connected()
            ):
                try:
                    state = (
                        connection_manager.get_image_state(
                            self.image_id
                        )
                    )

                    revision = int(
                        state.get(
                            "revision",
                            0
                        )
                    )

                    reset_auto_sync_runtime(
                        self.image_id,
                        revision
                    )

                    scene.blendgimp_auto_sync_revision = revision
                    scene.blendgimp_auto_sync_status = (
                        f"Synced revision {revision}"
                    )
                except Exception:
                    pass

            if assignment.get(
                "assigned",
                False
            ):

                self.report(
                    {"INFO"},
                    (
                        f"Refreshed {blender_image.name} "
                        f"on {assignment.get('material')}"
                    )
                )

            else:

                reason = assignment.get(
                    "reason",
                    "Material assignment skipped"
                )

                print(
                    "BLENDGIMP: "
                    f"Material assignment skipped: {reason}"
                )

                self.report(
                    {"WARNING"},
                    (
                        f"Image refreshed; material assignment skipped: {reason}"
                    )
                )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"REFRESH_FROM_GIMP failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"Refresh From GIMP failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# DIRECT GIMP PAINT LIVE VIEWPORT FEEDBACK
# ============================================================

_DIRECT_OBJECT_REDRAW_PENDING = False


def _tag_object_paint_viewports_for_redraw():
    """Tag every visible VIEW_3D window region, not only operator context."""
    redraw_count = 0
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return redraw_count

    for window in list(getattr(window_manager, "windows", ())):
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            try:
                area.tag_redraw()
                redraw_count += 1
            except Exception:
                pass
            for region in area.regions:
                if region.type != "WINDOW":
                    continue
                try:
                    region.tag_redraw()
                except Exception:
                    pass

    return redraw_count


def _deferred_object_paint_redraw():
    """One-shot redraw after the modal/operator event returns to Blender."""
    global _DIRECT_OBJECT_REDRAW_PENDING
    _DIRECT_OBJECT_REDRAW_PENDING = False
    _tag_object_paint_viewports_for_redraw()
    return None


def _force_object_paint_texture_redraw(blender_image):
    """Invalidate the material's GPU image cache and schedule a real redraw.

    Image.update() refreshes Blender's display buffer, but Material Preview can
    continue sampling an already-cached GPU texture.  Freeing that GPU copy
    forces the next VIEW_3D draw to rebuild it from the updated image buffer.
    The zero-delay app timer guarantees another redraw after the current modal
    event/operator has returned, which avoids relying on mouse orbit/pan events.
    """
    global _DIRECT_OBJECT_REDRAW_PENDING

    gpu_invalidated = False
    if blender_image is not None:
        try:
            blender_image.gl_free()
            gpu_invalidated = True
        except Exception as exc:
            print(
                "BLENDGIMP: Object Paint GPU texture invalidation failed: "
                f"{exc}"
            )
        try:
            blender_image.update_tag()
        except Exception:
            pass

    redraw_count = _tag_object_paint_viewports_for_redraw()

    if not _DIRECT_OBJECT_REDRAW_PENDING:
        _DIRECT_OBJECT_REDRAW_PENDING = True
        try:
            bpy.app.timers.register(
                _deferred_object_paint_redraw,
                first_interval=0.0,
            )
        except Exception as exc:
            _DIRECT_OBJECT_REDRAW_PENDING = False
            print(
                "BLENDGIMP: Object Paint deferred redraw scheduling failed: "
                f"{exc}"
            )

    return gpu_invalidated, redraw_count

class BLENDGIMP_OT_direct_live_refresh(
    bpy.types.Operator
):

    bl_idname = "blendgimp.direct_live_refresh"
    bl_label = "BlendGimp Direct Live Refresh"

    bl_options = {
        "INTERNAL"
    }

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        if not connection_manager.is_connected():
            return {"CANCELLED"}

        try:
            started = time.perf_counter()
            result = synchronize_gimp_composite(
                context,
                int(self.image_id),
                assign_material=False,
                dirty_only=True
            )

            transport_response = result.get(
                "transport_response",
                {}
            )

            if transport_response.get("changed", False):
                # Keep Blender's reusable raw-layer paint target coherent with
                # the GIMP edit, using only the same dirty rectangle.
                try:
                    sync_layer_id = int(getattr(
                        context.scene, "blendgimp_blender_paint_sync_layer_id", -1
                    ))
                    if sync_layer_id >= 0:
                        x = int(transport_response.get("x", 0))
                        y = int(transport_response.get("y", 0))
                        rw = int(transport_response.get("region_width", 0))
                        rh = int(transport_response.get("region_height", 0))
                        if rw > 0 and rh > 0:
                            layer_pixels = connection_manager.get_layer_pixels_binary(
                                int(self.image_id), sync_layer_id, x, y, rw, rh
                            )
                            apply_active_layer_buffer_response(
                                context.scene, int(self.image_id), sync_layer_id,
                                layer_pixels, clear_first=False, activate_target=False
                            )
                except Exception as layer_exc:
                    print(
                        "BLENDGIMP: Active Layer Buffer live patch warning: "
                        f"{layer_exc}"
                    )
                blender_image = result.get("blender_image")
                gpu_invalidated, redraw_views = (
                    _force_object_paint_texture_redraw(blender_image)
                )
                print(
                    "BLENDGIMP: "
                    "Direct live viewport feedback applied "
                    f"x={transport_response.get('x', 0)} "
                    f"y={transport_response.get('y', 0)} "
                    f"{transport_response.get('region_width', 0)}x"
                    f"{transport_response.get('region_height', 0)} "
                    f"gpu_invalidated={gpu_invalidated} "
                    f"redraw_views={redraw_views} "
                    f"total_ms={(time.perf_counter() - started) * 1000.0:.1f}"
                )

            # Phase 6.2.10: Do not issue GET_IMAGE_STATE after every live
            # chunk. Direct Paint already owns Auto Sync refreshes for the
            # duration of the modal tool, so that second synchronous socket
            # round trip was pure interaction latency. Auto Sync catches up
            # once ownership is released.
            context.scene.blendgimp_connected = True

            if context.area is not None:
                context.area.tag_redraw()

            return {"FINISHED"}

        except Exception as exc:
            print(
                "BLENDGIMP: "
                f"Direct live viewport feedback failed: {exc}"
            )
            return {"CANCELLED"}


class BLENDGIMP_OT_direct_paint_resume_auto_sync(
    bpy.types.Operator
):

    bl_idname = "blendgimp.direct_paint_resume_auto_sync"
    bl_label = "BlendGimp Resume Auto Sync"

    bl_options = {
        "INTERNAL"
    }

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            set_direct_paint_refresh_owner(
                False
            )

            if (
                scene.blendgimp_auto_sync_enabled
                and int(
                    scene.blendgimp_auto_sync_image_id
                ) == int(
                    self.image_id
                )
            ):

                print(
                    "BLENDGIMP: "
                    "Normal GIMP Auto Sync resumed after direct paint"
                )

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"Could not resume Auto Sync cleanly: {exc}"
            )

        return {"FINISHED"}


# ============================================================
# AUTO SYNC TOGGLE
# ============================================================

class BLENDGIMP_OT_toggle_auto_sync(
    bpy.types.Operator
):

    bl_idname = "blendgimp.toggle_auto_sync"
    bl_label = "Toggle GIMP Auto Sync"

    bl_description = (
        "Automatically refresh this GIMP image in Blender when its visible "
        "composite changes"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        scene = context.scene
        image_id = int(
            self.image_id
        )

        already_enabled = (
            scene.blendgimp_auto_sync_enabled
            and int(
                scene.blendgimp_auto_sync_image_id
            ) == image_id
        )

        if already_enabled:

            scene.blendgimp_auto_sync_enabled = False
            scene.blendgimp_auto_sync_image_id = -1
            scene.blendgimp_auto_sync_revision = 0
            scene.blendgimp_auto_sync_status = "Off"
            if hasattr(
                scene,
                "blendgimp_auto_sync_detector"
            ):
                scene.blendgimp_auto_sync_detector = ""

            reset_auto_sync_runtime()

            print(
                "BLENDGIMP: Auto Sync disabled"
            )

            self.report(
                {"INFO"},
                "GIMP Auto Sync disabled"
            )

            return {"FINISHED"}

        if not connection_manager.is_connected():

            scene.blendgimp_connected = False

            self.report(
                {"ERROR"},
                "BlendGimp is not connected to GIMP"
            )

            return {"CANCELLED"}

        try:

            # Establish a visual revision baseline first.
            state = (
                connection_manager.get_image_state(
                    image_id
                )
            )

            revision = int(
                state.get(
                    "revision",
                    0
                )
            )

            if hasattr(
                scene,
                "blendgimp_auto_sync_detector"
            ):
                scene.blendgimp_auto_sync_detector = str(
                    state.get(
                        "detector",
                        ""
                    )
                )

            # Initial enable also performs normal material assignment to the
            # currently active object/material. Future auto refreshes only
            # reload this existing Blender Image.
            synchronize_gimp_composite(
                context,
                image_id,
                assign_material=True
            )

            scene.blendgimp_auto_sync_enabled = True
            scene.blendgimp_auto_sync_image_id = image_id
            scene.blendgimp_auto_sync_revision = revision
            scene.blendgimp_auto_sync_status = (
                f"Watching revision {revision}"
            )

            reset_auto_sync_runtime(
                image_id,
                revision
            )

            print(
                "BLENDGIMP: "
                f"Auto Sync enabled for GIMP image ID {image_id} "
                f"at revision {revision}"
            )

            self.report(
                {"INFO"},
                f"Auto Sync enabled for GIMP image ID {image_id}"
            )

            return {"FINISHED"}

        except Exception as exc:

            scene.blendgimp_auto_sync_enabled = False
            scene.blendgimp_auto_sync_image_id = -1
            scene.blendgimp_auto_sync_status = (
                f"Enable failed: {exc}"
            )

            print(
                "BLENDGIMP: "
                f"ENABLE_AUTO_SYNC failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"Enable Auto Sync failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# PUSH BLENDER TEXTURE TO GIMP
# ============================================================

class BLENDGIMP_OT_toggle_blender_paint_sync(
    bpy.types.Operator
):

    bl_idname = "blendgimp.toggle_blender_paint_sync"
    bl_label = "Toggle Unified Paint Sync"

    bl_description = (
        "Automatically push Blender Texture Paint changes into the selected "
        "paintable GIMP raster layer"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        scene = context.scene
        image_id = int(
            self.image_id
        )

        active = (
            scene.blendgimp_blender_paint_sync_enabled
            and int(
                scene.blendgimp_blender_paint_sync_image_id
            ) == image_id
        )

        if active:

            scene.blendgimp_blender_paint_sync_enabled = (
                False
            )

            scene.blendgimp_blender_paint_sync_image_id = (
                -1
            )

            scene.blendgimp_blender_paint_sync_layer_id = (
                -1
            )

            scene.blendgimp_blender_paint_sync_status = (
                "Off"
            )

            reset_blender_paint_sync_runtime()

            print(
                "BLENDGIMP: "
                "Unified Paint Sync disabled"
            )

            self.report(
                {"INFO"},
                "Unified Paint Sync disabled"
            )

            return {"FINISHED"}

        if not connection_manager.is_connected():

            self.report(
                {"ERROR"},
                "BlendGimp is not connected to GIMP"
            )

            return {"CANCELLED"}

        try:

            sync_result = (
                get_texture_sync_result(
                    scene,
                    image_id
                )
                or {}
            )

            blender_image = _find_blendgimp_image(
                image_id,
                sync_result.get(
                    "sync_token",
                    ""
                )
            )

            if blender_image is None:

                raise RuntimeError(
                    "Refresh From GIMP before enabling 3D Paint Sync"
                )

            activate_blendgimp_image_owner(
                context,
                blender_image,
                image_id,
                fallback_to_active=True
            )

            layer_response = resolve_gimp_paint_target(
                scene,
                image_id,
                create_if_missing=True
            )

            layer_id = int(
                layer_response[
                    "layer_id"
                ]
            )

            buffer_image = load_active_layer_buffer_from_gimp(
                scene, image_id, layer_id, clear_first=True, activate_target=True
            )
            width, height, baseline = _blender_image_to_top_left_rgba8(buffer_image)

            scene.blendgimp_blender_paint_sync_enabled = True

            scene.blendgimp_blender_paint_sync_image_id = (
                image_id
            )

            scene.blendgimp_blender_paint_sync_layer_id = (
                layer_id
            )

            scene.blendgimp_blender_paint_sync_status = (
                "Waiting for Texture Paint mode"
            )

            reset_blender_paint_sync_runtime(
                image_id=image_id,
                layer_id=layer_id,
                baseline=baseline
            )

            print(
                "BLENDGIMP: "
                f"3D Paint Sync enabled for image ID {image_id} "
                f"using GIMP layer ID {layer_id}"
            )

            self.report(
                {"INFO"},
                (
                    "Unified Paint Sync enabled - "
                    f"GIMP layer {layer_response.get('name')}"
                )
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"ENABLE_3D_PAINT_SYNC failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"Unified Paint Sync failed: {exc}"
            )

            return {"CANCELLED"}


class BLENDGIMP_OT_push_to_gimp(
    bpy.types.Operator
):

    bl_idname = "blendgimp.push_to_gimp"
    bl_label = "Push Blender Texture to GIMP"

    bl_description = (
        "Write the reusable Blender Active Layer Buffer into its bound GIMP raster layer"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        scene = context.scene
        image_id = int(
            self.image_id
        )

        if not connection_manager.is_connected():

            scene.blendgimp_connected = False

            self.report(
                {"ERROR"},
                "BlendGimp is not connected to GIMP"
            )

            return {"CANCELLED"}

        try:

            sync_result = (
                get_texture_sync_result(
                    scene,
                    image_id
                )
                or {}
            )

            blender_image = _active_layer_buffer_for_sync(scene, image_id)
            if blender_image is None:
                raise RuntimeError(
                    "Unified Paint Sync active-layer buffer is not loaded"
                )

            if blender_image is None:

                raise RuntimeError(
                    "No synchronized Blender Image exists yet. "
                    "Refresh From GIMP first."
                )

            activate_blendgimp_image_owner(
                context,
                blender_image,
                image_id,
                fallback_to_active=True
            )

            layer_response = resolve_gimp_paint_target(
                scene,
                image_id,
                create_if_missing=True
            )

            layer_id = int(
                layer_response[
                    "layer_id"
                ]
            )

            width, height, raw_pixels = (
                _blender_image_to_top_left_rgba8(
                    blender_image
                )
            )

            response = (
                connection_manager.set_layer_pixels_binary(
                    image_id,
                    layer_id,
                    0,
                    0,
                    width,
                    height,
                    raw_pixels
                )
            )

            refresh_layer_result(
                scene,
                image_id
            )

            scene.blendgimp_connected = True

            update_blender_paint_sync_baseline(
                image_id,
                blender_image
            )

            print(
                "BLENDGIMP: "
                f"Pushed Blender image {blender_image.name} "
                f"to GIMP layer ID {layer_id} "
                f"({response.get('width')}x{response.get('height')}, "
                f"{response.get('byte_length')} bytes)"
            )

            self.report(
                {"INFO"},
                (
                    f"Pushed {blender_image.name} to "
                    f"GIMP layer {layer_response.get('name', layer_id)}"
                )
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"PUSH_TO_GIMP failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"Push to GIMP failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# GET IMAGE LAYERS
# ============================================================

class BLENDGIMP_OT_get_image_layers(
    bpy.types.Operator
):

    bl_idname = "blendgimp.get_image_layers"
    bl_label = "Get Image Layers"

    bl_description = (
        "Read the complete layer tree for this GIMP image"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        if self.image_id < 0:

            self.report(
                {"ERROR"},
                "Invalid GIMP image ID"
            )

            return {"CANCELLED"}

        try:

            print(
                "BLENDGIMP: "
                "Requesting layers for "
                f"GIMP image ID {self.image_id}"
            )

            response = (
                connection_manager.
                get_image_layers(
                    self.image_id
                )
            )

            store_layer_result(
                scene,
                self.image_id,
                response
            )

            scene.blendgimp_connected = True

            layer_count = int(
                response.get(
                    "layer_count",
                    0
                )
            )

            print(
                "BLENDGIMP: "
                f"Image ID {self.image_id} "
                f"has {layer_count} layer(s)"
            )

            def print_layers(
                layers,
                depth=0
            ):

                for layer in layers:

                    indent = (
                        "  " * depth
                    )

                    print(
                        "BLENDGIMP: "
                        f"{indent}"
                        f"Layer ID={layer.get('id')} "
                        f"Name={layer.get('name')} "
                        f"Visible={layer.get('visible')} "
                        f"Opacity={layer.get('opacity')} "
                        f"Group={layer.get('is_group')} "
                        f"Selected={layer.get('selected')}"
                    )

                    print_layers(
                        layer.get(
                            "children",
                            []
                        ),
                        depth + 1
                    )

            print_layers(
                response.get(
                    "layers",
                    []
                )
            )

            self.report(
                {"INFO"},
                (
                    f"GIMP returned "
                    f"{layer_count} layer(s)"
                )
            )

            return {"FINISHED"}

        except Exception as exc:

            scene.blendgimp_connected = False

            print(
                "BLENDGIMP: "
                f"GET_IMAGE_LAYERS failed: {exc}"
            )

            self.report(
                {"ERROR"},
                (
                    "GET_IMAGE_LAYERS failed: "
                    f"{exc}"
                )
            )

            return {"CANCELLED"}



# ============================================================
# SET ACTIVE LAYER
# ============================================================

class BLENDGIMP_OT_set_active_layer(
    bpy.types.Operator
):

    bl_idname = "blendgimp.set_active_layer"
    bl_label = "Set Active GIMP Layer"

    bl_description = (
        "Make this the active selected layer in GIMP"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            flush_blender_paint_changes(
                scene, reason="before GIMP layer switch", fail_if_unsent=True
            )
            connection_manager.set_active_layer(
                self.image_id,
                self.layer_id
            )

            layer_response = refresh_layer_result(
                scene,
                self.image_id
            )

            selected_item = _find_layer_in_tree(
                layer_response.get("layers", []),
                self.layer_id
            )
            selected_is_group = bool(
                selected_item and selected_item.get("is_group", False)
            )

            if selected_is_group:
                # Phase 6.5.4 RC Fix2: a GIMP group can be selected and
                # manipulated, but it is not a raster drawable.  Do not try
                # to mirror group pixels into Blender's active-layer buffer.
                # The next real paint operation will resolve the selected
                # item and report that a raster layer must be chosen.
                if int(getattr(scene, "blendgimp_blender_paint_sync_image_id", -1)) == int(self.image_id):
                    scene.blendgimp_blender_paint_sync_enabled = False
                    scene.blendgimp_blender_paint_sync_layer_id = -1
                    scene.blendgimp_blender_paint_sync_status = (
                        "Group selected — choose a raster layer to paint"
                    )
                    reset_blender_paint_sync_runtime(
                        image_id=self.image_id,
                        layer_id=-1,
                        baseline=None
                    )
                print(
                    "BLENDGIMP: Active GIMP group selected "
                    f"ID {self.layer_id}; raster paint buffer suspended"
                )
            elif int(getattr(scene, "blendgimp_blender_paint_sync_image_id", -1)) == int(self.image_id):
                load_active_layer_buffer_from_gimp(
                    scene, self.image_id, self.layer_id, clear_first=True, activate_target=True
                )

            scene.blendgimp_connected = True

            print(
                "BLENDGIMP: "
                f"Active GIMP layer set to ID {self.layer_id}"
            )

            self.report(
                {"INFO"},
                f"Active GIMP layer set to ID {self.layer_id}"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"SET_ACTIVE_LAYER failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"SET_ACTIVE_LAYER failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# SET LAYER VISIBILITY
# ============================================================

class BLENDGIMP_OT_set_layer_visibility(
    bpy.types.Operator
):

    bl_idname = "blendgimp.set_layer_visibility"
    bl_label = "Set GIMP Layer Visibility"

    bl_description = (
        "Show or hide this layer in GIMP"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    visible: bpy.props.BoolProperty(
        name="Visible",
        default=True
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = (
                connection_manager.
                set_layer_visibility(
                    self.image_id,
                    self.layer_id,
                    bool(self.visible)
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            scene.blendgimp_connected = True

            visible = bool(
                response.get(
                    "visible",
                    self.visible
                )
            )

            print(
                "BLENDGIMP: "
                f"Layer ID {self.layer_id} "
                f"visibility={visible}"
            )

            self.report(
                {"INFO"},
                (
                    f"Layer ID {self.layer_id} "
                    f"{'shown' if visible else 'hidden'}"
                )
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"SET_LAYER_VISIBILITY failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"SET_LAYER_VISIBILITY failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# SET LAYER OPACITY
# ============================================================

class BLENDGIMP_OT_set_layer_opacity(
    bpy.types.Operator
):

    bl_idname = "blendgimp.set_layer_opacity"
    bl_label = "Set GIMP Layer Opacity"

    bl_description = (
        "Change this layer's opacity in GIMP"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    opacity: bpy.props.FloatProperty(
        name="Opacity",
        description="GIMP layer opacity from 0 to 100 percent",
        default=100.0,
        min=0.0,
        max=100.0,
        precision=1
    )

    def invoke(
        self,
        context,
        event
    ):

        return (
            context.window_manager.
            invoke_props_dialog(
                self,
                width=320
            )
        )

    def draw(
        self,
        context
    ):

        self.layout.prop(
            self,
            "opacity",
            slider=True
        )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = (
                connection_manager.
                set_layer_opacity(
                    self.image_id,
                    self.layer_id,
                    self.opacity
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            scene.blendgimp_connected = True

            actual_opacity = float(
                response.get(
                    "opacity",
                    self.opacity
                )
            )

            print(
                "BLENDGIMP: "
                f"Layer ID {self.layer_id} "
                f"opacity={actual_opacity:.1f}"
            )

            self.report(
                {"INFO"},
                (
                    f"Layer ID {self.layer_id} "
                    f"opacity {actual_opacity:.1f}%"
                )
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"SET_LAYER_OPACITY failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"SET_LAYER_OPACITY failed: {exc}"
            )

            return {"CANCELLED"}



# ============================================================
# ADD LAYER
# ============================================================

class BLENDGIMP_OT_add_layer(
    bpy.types.Operator
):

    bl_idname = "blendgimp.add_layer"
    bl_label = "Add GIMP Layer"

    bl_description = (
        "Create a new full-size transparent GIMP layer above the active layer"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_name: bpy.props.StringProperty(
        name="Layer Name",
        default="New Layer"
    )

    def invoke(
        self,
        context,
        event
    ):

        return (
            context.window_manager.
            invoke_props_dialog(
                self,
                width=320
            )
        )

    def draw(
        self,
        context
    ):

        self.layout.prop(
            self,
            "layer_name"
        )

    def execute(
        self,
        context
    ):

        scene = context.scene

        name = (
            self.layer_name
            or
            "New Layer"
        ).strip()

        try:

            response = (
                connection_manager.add_layer(
                    self.image_id,
                    name
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            # A new empty transparent layer is structurally dirty in GIMP but
            # does not change the visible composite. Consume that no-op state
            # immediately so the first paint stroke cannot inherit a full-image
            # dirty rectangle (especially expensive at 4K).
            try:
                synchronize_gimp_composite(
                    context,
                    self.image_id,
                    assign_material=False,
                    dirty_only=True
                )
            except Exception as baseline_exc:
                print(
                    "BLENDGIMP: "
                    f"ADD_LAYER structural baseline warning: {baseline_exc}"
                )

            new_layer_id = int(
                response.get(
                    "layer_id",
                    -1
                )
            )

            print(
                "BLENDGIMP: "
                f"Added GIMP layer ID {new_layer_id} "
                f"Name={response.get('name')}"
            )

            self.report(
                {"INFO"},
                f"Added layer {response.get('name', '')}"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"ADD_LAYER failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"ADD_LAYER failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# DELETE LAYER
# ============================================================

class BLENDGIMP_OT_delete_layer(
    bpy.types.Operator
):

    bl_idname = "blendgimp.delete_layer"
    bl_label = "Delete GIMP Layer"

    bl_description = (
        "Delete this GIMP layer or group"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    layer_name: bpy.props.StringProperty(
        name="Layer Name",
        default=""
    )

    def invoke(
        self,
        context,
        event
    ):

        return (
            context.window_manager.
            invoke_confirm(
                self,
                event
            )
        )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            connection_manager.delete_layer(
                self.image_id,
                self.layer_id
            )

            layer_response = refresh_layer_result(
                scene,
                self.image_id
            )

            remaining_layers = layer_response.get(
                "layers",
                []
            )

            if isinstance(remaining_layers, list) and len(remaining_layers) == 0:
                baseline_response = (
                    connection_manager.rebase_image_dirty_baseline(
                        self.image_id
                    )
                )

                preview_cleared = (
                    _clear_blender_preview_for_empty_gimp_image(
                        context,
                        self.image_id
                    )
                )

                print(
                    "BLENDGIMP: Last GIMP layer removed; dirty baseline "
                    f"rebased without pixel transfer for image ID {self.image_id}; "
                    f"source={baseline_response.get('source', 'unknown')} "
                    f"preview_cleared={preview_cleared}"
                )

            print(
                "BLENDGIMP: "
                f"Deleted GIMP layer ID {self.layer_id} "
                f"Name={self.layer_name}"
            )

            self.report(
                {"INFO"},
                f"Deleted layer {self.layer_name}"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"DELETE_LAYER failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"DELETE_LAYER failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# RENAME LAYER
# ============================================================

class BLENDGIMP_OT_rename_layer(
    bpy.types.Operator
):

    bl_idname = "blendgimp.rename_layer"
    bl_label = "Rename GIMP Layer"

    bl_description = (
        "Rename this GIMP layer or group"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    layer_name: bpy.props.StringProperty(
        name="Layer Name",
        default=""
    )

    def invoke(
        self,
        context,
        event
    ):

        return (
            context.window_manager.
            invoke_props_dialog(
                self,
                width=320
            )
        )

    def draw(
        self,
        context
    ):

        self.layout.prop(
            self,
            "layer_name"
        )

    def execute(
        self,
        context
    ):

        scene = context.scene

        new_name = (
            self.layer_name
            or
            ""
        ).strip()

        if not new_name:

            self.report(
                {"ERROR"},
                "Layer name cannot be empty"
            )

            return {"CANCELLED"}

        try:

            response = (
                connection_manager.rename_layer(
                    self.image_id,
                    self.layer_id,
                    new_name
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            print(
                "BLENDGIMP: "
                f"Renamed GIMP layer ID {self.layer_id} "
                f"to {response.get('name')}"
            )

            self.report(
                {"INFO"},
                f"Renamed layer to {response.get('name', new_name)}"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"RENAME_LAYER failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"RENAME_LAYER failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# DUPLICATE LAYER
# ============================================================

class BLENDGIMP_OT_duplicate_layer(
    bpy.types.Operator
):

    bl_idname = "blendgimp.duplicate_layer"
    bl_label = "Duplicate GIMP Layer"

    bl_description = (
        "Duplicate this GIMP layer or group"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = (
                connection_manager.duplicate_layer(
                    self.image_id,
                    self.layer_id
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            print(
                "BLENDGIMP: "
                f"Duplicated GIMP layer ID {self.layer_id} "
                f"as ID {response.get('layer_id')}"
            )

            self.report(
                {"INFO"},
                f"Duplicated layer as {response.get('name', '')}"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"DUPLICATE_LAYER failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"DUPLICATE_LAYER failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# REORDER LAYER
# ============================================================

class BLENDGIMP_OT_reorder_layer(
    bpy.types.Operator
):

    bl_idname = "blendgimp.reorder_layer"
    bl_label = "Reorder GIMP Layer"

    bl_description = (
        "Move this GIMP layer one step up or down"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    direction: bpy.props.StringProperty(
        name="Direction",
        default="UP"
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = (
                connection_manager.reorder_layer(
                    self.image_id,
                    self.layer_id,
                    self.direction
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            print(
                "BLENDGIMP: "
                f"Reordered layer ID {self.layer_id} "
                f"{self.direction} "
                f"to position {response.get('position')}"
            )

            self.report(
                {"INFO"},
                f"Layer moved {self.direction.lower()}"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"REORDER_LAYER failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"REORDER_LAYER failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# MOVE LAYER INTO / OUT OF GROUP
# ============================================================

class BLENDGIMP_OT_move_layer(
    bpy.types.Operator
):

    bl_idname = "blendgimp.move_layer"
    bl_label = "Move GIMP Layer"

    bl_description = (
        "Move this layer into a group or back to the top-level layer stack"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    target_parent: bpy.props.EnumProperty(
        name="Move To",
        description="Choose the destination group or Top Level",
        items=blendgimp_move_target_items
    )

    def invoke(
        self,
        context,
        event
    ):

        # Default to top-level so the dialog always has a valid selection.
        self.target_parent = "-1"

        return (
            context.window_manager.
            invoke_props_dialog(
                self,
                width=360
            )
        )

    def draw(
        self,
        context
    ):

        self.layout.prop(
            self,
            "target_parent"
        )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            parent_id = int(
                self.target_parent
            )

            response = (
                connection_manager.move_layer(
                    self.image_id,
                    self.layer_id,
                    parent_id
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            actual_parent_id = (
                response.get(
                    "parent_id",
                    None
                )
            )

            destination = (
                "Top Level"
                if actual_parent_id is None
                else f"Group ID {actual_parent_id}"
            )

            print(
                "BLENDGIMP: "
                f"Moved GIMP layer ID {self.layer_id} "
                f"to {destination}"
            )

            self.report(
                {"INFO"},
                f"Layer moved to {destination}"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"MOVE_LAYER failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"MOVE_LAYER failed: {exc}"
            )

            return {"CANCELLED"}



# ============================================================
# CREATE GROUP
# ============================================================

class BLENDGIMP_OT_create_group(
    bpy.types.Operator
):

    bl_idname = "blendgimp.create_group"
    bl_label = "Create GIMP Group"

    bl_description = (
        "Create a new GIMP layer group above the active layer"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    group_name: bpy.props.StringProperty(
        name="Group Name",
        default="Layer Group"
    )

    def invoke(
        self,
        context,
        event
    ):

        return (
            context.window_manager.
            invoke_props_dialog(
                self,
                width=320
            )
        )

    def draw(
        self,
        context
    ):

        self.layout.prop(
            self,
            "group_name"
        )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = (
                connection_manager.create_group(
                    self.image_id,
                    self.group_name
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            print(
                "BLENDGIMP: "
                f"Created GIMP group ID {response.get('layer_id')} "
                f"Name={response.get('name')}"
            )

            self.report(
                {"INFO"},
                f"Created group {response.get('name', '')}"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"CREATE_GROUP failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"CREATE_GROUP failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# MERGE LAYER DOWN
# ============================================================

class BLENDGIMP_OT_merge_layer_down(
    bpy.types.Operator
):

    bl_idname = "blendgimp.merge_layer_down"
    bl_label = "Merge GIMP Layer Down"

    bl_description = (
        "Merge this layer with the first visible GIMP layer below it"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    layer_name: bpy.props.StringProperty(
        name="Layer Name",
        default=""
    )

    def invoke(
        self,
        context,
        event
    ):

        return (
            context.window_manager.
            invoke_confirm(
                self,
                event
            )
        )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = (
                connection_manager.merge_layer_down(
                    self.image_id,
                    self.layer_id
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            print(
                "BLENDGIMP: "
                f"Merged layer ID {self.layer_id} down "
                f"into resulting layer ID {response.get('layer_id')}"
            )

            self.report(
                {"INFO"},
                f"Merged {self.layer_name} down"
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"MERGE_LAYER_DOWN failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"MERGE_LAYER_DOWN failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# SET LAYER LOCK
# ============================================================

class BLENDGIMP_OT_set_layer_lock(
    bpy.types.Operator
):

    bl_idname = "blendgimp.set_layer_lock"
    bl_label = "Set GIMP Layer Lock"

    bl_description = (
        "Toggle a GIMP layer lock"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    lock_type: bpy.props.StringProperty(
        name="Lock Type",
        default="CONTENT"
    )

    locked: bpy.props.BoolProperty(
        name="Locked",
        default=True
    )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = (
                connection_manager.set_layer_lock(
                    self.image_id,
                    self.layer_id,
                    self.lock_type,
                    bool(self.locked)
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            actual_locked = bool(
                response.get(
                    "locked",
                    self.locked
                )
            )

            print(
                "BLENDGIMP: "
                f"Layer ID {self.layer_id} "
                f"{self.lock_type} lock={actual_locked}"
            )

            self.report(
                {"INFO"},
                (
                    f"{self.lock_type.title()} lock "
                    f"{'enabled' if actual_locked else 'disabled'}"
                )
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"SET_LAYER_LOCK failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"SET_LAYER_LOCK failed: {exc}"
            )

            return {"CANCELLED"}


# ============================================================
# SET LAYER BLEND MODE
# ============================================================

class BLENDGIMP_OT_set_layer_mode(
    bpy.types.Operator
):

    bl_idname = "blendgimp.set_layer_mode"
    bl_label = "Set GIMP Blend Mode"

    bl_description = (
        "Change this layer's GIMP blend mode"
    )

    image_id: bpy.props.IntProperty(
        name="Image ID",
        default=-1
    )

    layer_id: bpy.props.IntProperty(
        name="Layer ID",
        default=-1
    )

    mode: bpy.props.EnumProperty(
        name="Blend Mode",
        description="GIMP layer blend mode",
        items=BLENDGIMP_LAYER_MODE_ITEMS,
        default="NORMAL"
    )

    def invoke(
        self,
        context,
        event
    ):

        return (
            context.window_manager.
            invoke_props_dialog(
                self,
                width=420
            )
        )

    def draw(
        self,
        context
    ):

        self.layout.prop(
            self,
            "mode"
        )

    def execute(
        self,
        context
    ):

        scene = context.scene

        try:

            response = (
                connection_manager.set_layer_mode(
                    self.image_id,
                    self.layer_id,
                    self.mode
                )
            )

            refresh_layer_result(
                scene,
                self.image_id
            )

            actual_mode = str(
                response.get(
                    "mode",
                    self.mode
                )
            )

            print(
                "BLENDGIMP: "
                f"Layer ID {self.layer_id} "
                f"blend mode={actual_mode}"
            )

            self.report(
                {"INFO"},
                (
                    "Blend mode set to "
                    + blendgimp_layer_mode_label(
                        actual_mode
                    )
                )
            )

            return {"FINISHED"}

        except Exception as exc:

            print(
                "BLENDGIMP: "
                f"SET_LAYER_MODE failed: {exc}"
            )

            self.report(
                {"ERROR"},
                f"SET_LAYER_MODE failed: {exc}"
            )

            return {"CANCELLED"}



# ============================================================
# DISCONNECT
# ============================================================

class BLENDGIMP_OT_disconnect(
    bpy.types.Operator
):

    bl_idname = "blendgimp.disconnect"
    bl_label = "Disconnect"

    bl_description = (
        "Disconnect Blender from GIMP"
    )

    def execute(
        self,
        context
    ):

        context.scene.blendgimp_engine_should_run = False

        connection_manager.disconnect()

        clear_engine_connection(
            context.scene
        )

        if gimp_manager.is_gimp_running():
            gimp_manager.mark_engine_disconnected(
                "Disconnected manually"
            )
            context.scene.blendgimp_engine_state = (
                gimp_manager.ENGINE_STATE_DISCONNECTED
            )
        else:
            context.scene.blendgimp_engine_state = (
                gimp_manager.ENGINE_STATE_STOPPED
            )

        print(
            "BLENDGIMP: "
            "Disconnected from GIMP"
        )

        self.report(
            {"INFO"},
            "BlendGimp disconnected"
        )

        return {"FINISHED"}


# ============================================================
# MAIN PANEL
# ============================================================

class BLENDGIMP_PT_main_panel(
    bpy.types.Panel
):

    bl_label = "BlendGimp"

    bl_idname = (
        "BLENDGIMP_PT_main_panel"
    )

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BlendGimp"

    def draw(
        self,
        context
    ):

        layout = self.layout
        scene = context.scene

        # ====================================================
        # HEADER
        # ====================================================

        layout.label(
            text="BlendGimp 0.5.3 — Production UI"
        )

        layout.separator()

        # ====================================================
        # ENGINE STATUS — production-facing status only
        # Setup, mode selection, process checks, and diagnostics live in
        # Blender Preferences -> Add-ons/Extensions -> BlendGimp.
        # ====================================================

        gimp_box = layout.box()
        header = gimp_box.row(align=True)
        header.label(text="Engine", icon="PREFERENCES")
        header.operator(
            "blendgimp.open_preferences",
            text="",
            icon="PREFERENCES",
        )

        engine_snapshot = gimp_manager.get_engine_snapshot()
        engine_state = str(
            scene.blendgimp_engine_state
            or engine_snapshot.get("state", gimp_manager.ENGINE_STATE_STOPPED)
        )
        connected = bool(
            scene.blendgimp_connected
            and connection_manager.is_connected()
        )

        status = gimp_box.row(align=True)
        status.label(
            text="Connected" if connected else engine_state.replace("_", " ").title(),
            icon="CHECKMARK" if connected else ("ERROR" if engine_state == gimp_manager.ENGINE_STATE_FAILED else "INFO"),
        )

        version_text = str(
            scene.blendgimp_runtime_gimp_version
            or scene.blendgimp_gimp_version
            or ""
        )
        if version_text:
            status.label(text=f"GIMP {version_text}")

        mode_value = blendgimp_preferences.engine_mode(context=context, scene=scene)
        status.label(
            text="Headless" if mode_value == gimp_manager.ENGINE_MODE_HEADLESS else "Visible / Debug",
        )

        if scene.blendgimp_engine_last_error:
            error_box = gimp_box.box()
            error_box.alert = True
            error_box.label(text=scene.blendgimp_engine_last_error, icon="ERROR")

        # Keep engine actions visually consistent and immediately usable.
        # Start uses Blender's active/depressed accent treatment (blue in the
        # default dark theme); Stop uses the alert treatment (red). Detection
        # is automatic inside Start, so first-run users never visit Preferences
        # just to enable this button.
        controls = gimp_box.row(align=True)

        start_cell = controls.row(align=True)
        start_cell.enabled = not bool(scene.blendgimp_gimp_running or connected)
        start_cell.operator(
            "blendgimp.launch_gimp",
            text="Start GIMP",
            icon="PLAY",
            depress=True,
        )

        reconnect_cell = controls.row(align=True)
        reconnect_cell.enabled = bool(scene.blendgimp_gimp_running and not connected)
        reconnect_cell.operator(
            "blendgimp.connect",
            text="Reconnect",
            icon="FILE_REFRESH",
        )

        stop_cell = controls.row(align=True)
        stop_cell.alert = True
        stop_cell.enabled = bool(scene.blendgimp_gimp_running or connected)
        stop_cell.operator(
            "blendgimp.stop_gimp",
            text="Stop",
            icon="CANCEL",
        )

        layout.separator()

        # ====================================================
        # IMAGE & MATERIAL — compact production workflow
        # ====================================================

        connection_box = layout.box()
        connection_box.label(
            text="Image & Material",
            icon="IMAGE_DATA"
        )

        connected = bool(
            scene.blendgimp_connected
            and connection_manager.is_connected()
        )

        if connected:
            obj = getattr(context, "active_object", None)
            material = getattr(obj, "active_material", None) if obj is not None else None

            material_row = connection_box.row(align=True)
            material_row.label(text="Active Material", icon="MATERIAL")
            if obj is not None and hasattr(obj, "active_material"):
                try:
                    material_row.template_ID(obj, "active_material", text="")
                except Exception:
                    material_row.label(
                        text=(material.name if material is not None else "None")
                    )
            else:
                material_row.label(text="No active object")

            image_id = _resolve_active_gimp_image_id(context)
            blender_image = _resolve_active_blender_image(context, image_id)
            image_name = (
                blender_image.name
                if blender_image is not None
                else _stored_gimp_image_name(scene, image_id)
            )

            image_row = connection_box.row(align=True)
            image_row.label(text="Active Image", icon="IMAGE_DATA")
            image_row.label(
                text=(image_name or "No BlendGimp image")
            )

            actions = connection_box.row(align=True)
            actions.operator(
                "blendgimp.create_image",
                text="Create Image",
                icon="ADD"
            )

            refresh_cell = actions.row(align=True)
            refresh_cell.enabled = image_id >= 0
            refresh_op = refresh_cell.operator(
                "blendgimp.refresh_from_gimp",
                text="Refresh From GIMP",
                icon="FILE_REFRESH"
            )
            refresh_op.image_id = image_id

            assign_row = connection_box.row()
            assign_row.enabled = image_id >= 0
            assign_row.operator(
                "blendgimp.assign_active_image_to_material",
                text="Assign to Material",
                icon="MATERIAL"
            )

            # XCF open/save commands deliberately live under Image Editor >
            # Image > BlendGimp XCF so file management does not consume the
            # day-to-day production panel.
        else:
            connection_box.label(
                text="Start or reconnect GIMP using Engine above",
                icon="INFO"
            )


# ============================================================
# CLASSES
# ============================================================

classes = (

    BLENDGIMP_OT_detect_gimp,

    BLENDGIMP_OT_launch_gimp,

    BLENDGIMP_OT_stop_gimp,

    BLENDGIMP_OT_force_stop_gimp,

    BLENDGIMP_OT_restart_gimp,

    BLENDGIMP_OT_check_gimp,

    BLENDGIMP_OT_connect,

    BLENDGIMP_OT_ping,

    BLENDGIMP_OT_create_image,

    BLENDGIMP_OT_get_images,

    BLENDGIMP_OT_open_xcf,

    BLENDGIMP_OT_save_image,

    BLENDGIMP_OT_save_image_as,

    BLENDGIMP_OT_save_all_images,

    BLENDGIMP_MT_image_xcf,

    BLENDGIMP_OT_assign_active_image_to_material,

    BLENDGIMP_OT_activate_texture_owner,

    BLENDGIMP_OT_refresh_from_gimp,

    BLENDGIMP_OT_direct_live_refresh,

    BLENDGIMP_OT_direct_paint_resume_auto_sync,

    BLENDGIMP_OT_direct_gimp_brush_paint,

    BLENDGIMP_OT_toggle_blender_paint_sync,

    BLENDGIMP_OT_push_to_gimp,

    BLENDGIMP_OT_toggle_auto_sync,

    BLENDGIMP_OT_get_image_layers,

    BLENDGIMP_OT_set_active_layer,

    BLENDGIMP_OT_set_layer_visibility,

    BLENDGIMP_OT_set_layer_opacity,

    BLENDGIMP_OT_add_layer,

    BLENDGIMP_OT_delete_layer,

    BLENDGIMP_OT_rename_layer,

    BLENDGIMP_OT_duplicate_layer,

    BLENDGIMP_OT_reorder_layer,

    BLENDGIMP_OT_move_layer,

    BLENDGIMP_OT_create_group,

    BLENDGIMP_OT_merge_layer_down,

    BLENDGIMP_OT_set_layer_lock,

    BLENDGIMP_OT_set_layer_mode,

    BLENDGIMP_OT_disconnect,

    BLENDGIMP_PT_main_panel,

)


# ============================================================
# REGISTER
# ============================================================

@persistent
def blendgimp_exit_pre(_is_user_exit):
    """Protect dirty headless GIMP documents while Blender exits.

    Blender 5.2 calls exit_pre while application data is still valid. Save
    existing XCF documents in place and write never-saved documents to a
    recovery folder before requesting a clean GIMP shutdown.
    """

    global _EXIT_PRE_HANDLED
    _EXIT_PRE_HANDLED = True
    print(
        "BLENDGIMP: exit_pre lifecycle handler entered; "
        f"user_exit={bool(_is_user_exit)}",
        flush=True,
    )

    snapshot = gimp_manager.get_engine_snapshot()
    if not (
        snapshot.get("running", False)
        and snapshot.get("mode") == gimp_manager.ENGINE_MODE_HEADLESS
    ):
        return

    scene = getattr(bpy.context, "scene", None)
    if scene is None and bpy.data.scenes:
        scene = bpy.data.scenes[0]

    if scene is None:
        print(
            "BLENDGIMP: Blender exit could not resolve a Scene; "
            "leaving headless GIMP running to avoid data loss"
        )
        connection_manager.disconnect()
        gimp_manager.clear_process_reference()
        return

    save_result = {"saved": 0, "recovery": 0, "failed": []}

    if connection_manager.is_connected():
        try:
            save_result = _save_dirty_images_for_exit(scene)
        except Exception as exc:
            save_result = {
                "saved": 0,
                "recovery": 0,
                "failed": [(-1, str(exc))],
            }

    failures = list(save_result.get("failed", []))
    if failures:
        print(
            "BLENDGIMP: Blender exit recovery could not save all dirty "
            "documents; leaving headless GIMP running to protect them"
        )
        for image_id, error in failures:
            print(
                "BLENDGIMP: Exit recovery failure "
                f"image ID {image_id}: {error}"
            )
        connection_manager.disconnect()
        gimp_manager.clear_process_reference()
        return

    if int(save_result.get("recovery", 0)) > 0:
        print(
            "BLENDGIMP: Blender exit recovery saved "
            f"{save_result.get('recovery', 0)} new XCF document(s) to "
            f"{_recovery_save_directory()}"
        )

    graceful_requested = False
    if connection_manager.is_connected():
        try:
            connection_manager.shutdown_engine(force=False)
            graceful_requested = True
        except Exception as exc:
            print(
                "BLENDGIMP: Exit clean shutdown request failed; "
                f"using process fallback: {exc}"
            )

    connection_manager.disconnect()
    gimp_manager.stop_gimp(
        graceful_requested=graceful_requested
    )


@persistent
def blendgimp_undo_redo_post(_scene_arg=None):
    """Repair transient BlendGimp paint ownership after Blender Undo/Redo.

    GIMP raster operations are external to Blender's undo stack, while the
    reusable active-layer buffer and material paint-slot selection are Blender
    data. Undo/Redo must therefore never leave stale modal flags or a missing
    paint target behind. The existing runtime baseline is intentionally kept:
    if Blender actually undid pixels in the working buffer, the normal Unified
    Paint Sync timer will detect that delta and send the undone pixels to GIMP.
    """
    try:
        scene = getattr(bpy.context, "scene", None)
        if scene is None:
            return

        try:
            scene["blendgimp_paint_cancel_serial"] = int(
                scene.get("blendgimp_paint_cancel_serial", 0)
            ) + 1
        except Exception:
            pass

        if hasattr(scene, "blendgimp_2d_paint_active"):
            scene.blendgimp_2d_paint_active = False
        if hasattr(scene, "blendgimp_2d_paint_layer_id"):
            scene.blendgimp_2d_paint_layer_id = -1
        if hasattr(scene, "blendgimp_direct_paint_active"):
            scene.blendgimp_direct_paint_active = False
        if hasattr(scene, "blendgimp_direct_paint_image_id"):
            scene.blendgimp_direct_paint_image_id = -1
        set_direct_paint_refresh_owner(False)

        runtime_image = int(_BLENDER_PAINT_SYNC_RUNTIME.get("image_id", -1))
        runtime_layer = int(_BLENDER_PAINT_SYNC_RUNTIME.get("layer_id", -1))
        if runtime_image < 0 or runtime_layer < 0:
            return

        if hasattr(scene, "blendgimp_blender_paint_sync_enabled"):
            scene.blendgimp_blender_paint_sync_enabled = True
        if hasattr(scene, "blendgimp_blender_paint_sync_image_id"):
            scene.blendgimp_blender_paint_sync_image_id = runtime_image
        if hasattr(scene, "blendgimp_blender_paint_sync_layer_id"):
            scene.blendgimp_blender_paint_sync_layer_id = runtime_layer

        buffer_image = _active_layer_buffer_for_sync(scene, runtime_image)
        sync_result = get_texture_sync_result(scene, runtime_image) or {}
        composite = _find_blendgimp_image(runtime_image, sync_result.get("sync_token", ""))
        if buffer_image is not None and composite is not None:
            _ensure_active_layer_paint_node(
                bpy.context, composite, buffer_image, runtime_image
            )
            _BLENDER_PAINT_SYNC_RUNTIME["buffer_image_name"] = buffer_image.name
            scene.blendgimp_blender_paint_sync_status = (
                "Undo/Redo recovered — checking Blender layer changes"
            )
            print(
                "BLENDGIMP: Undo/Redo recovery restored active-layer paint target "
                f"image ID {runtime_image} layer ID {runtime_layer}"
            )
    except Exception as exc:
        print(f"BLENDGIMP: Undo/Redo recovery warning: {exc}")


def register():

    global _EXIT_PRE_HANDLED
    _EXIT_PRE_HANDLED = False

    for cls in classes:

        bpy.utils.register_class(
            cls
        )

        if cls is BLENDGIMP_OT_direct_gimp_brush_paint:

            print(
                "BLENDGIMP: "
                "Direct GIMP Brush 3D Paint operator registered"
            )

    # File operations belong with Blender's Image menu, not the production
    # sidebar. Remove first to avoid duplicate entries during extension reload.
    try:
        bpy.types.IMAGE_MT_image.remove(draw_blendgimp_image_menu)
    except Exception:
        pass
    try:
        bpy.types.IMAGE_MT_image.append(draw_blendgimp_image_menu)
    except Exception as exc:
        print(f"BLENDGIMP: Could not register Image menu entries: {exc}")

    if blendgimp_exit_pre not in bpy.app.handlers.exit_pre:
        bpy.app.handlers.exit_pre.append(blendgimp_exit_pre)
    if blendgimp_undo_redo_post not in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.append(blendgimp_undo_redo_post)
    if blendgimp_undo_redo_post not in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.append(blendgimp_undo_redo_post)

    bpy.types.Scene.blendgimp_engine_mode = (
        bpy.props.EnumProperty(
            name="GIMP Engine Mode",
            description=(
                "Run GIMP invisibly for normal BlendGimp work or visibly "
                "for debugging and regression testing"
            ),
            items=(
                (
                    gimp_manager.ENGINE_MODE_HEADLESS,
                    "Headless",
                    "Run a dedicated persistent GIMP engine without its "
                    "traditional interface"
                ),
                (
                    gimp_manager.ENGINE_MODE_VISIBLE_DEBUG,
                    "Visible / Debug",
                    "Use the original visible GIMP launch path for "
                    "troubleshooting and regression testing"
                ),
            ),
            default=gimp_manager.ENGINE_MODE_HEADLESS
        )
    )

    bpy.types.Scene.blendgimp_engine_auto_reconnect = (
        bpy.props.BoolProperty(
            name="Automatic Engine Recovery",
            description=(
                "Reconnect when the socket drops and restart the managed "
                "GIMP engine when its process exits unexpectedly"
            ),
            default=True
        )
    )

    bpy.types.Scene.blendgimp_engine_should_run = (
        bpy.props.BoolProperty(
            name="GIMP Engine Requested",
            default=False,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_engine_state = (
        bpy.props.StringProperty(
            name="GIMP Engine State",
            default=gimp_manager.ENGINE_STATE_STOPPED,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_engine_last_error = (
        bpy.props.StringProperty(
            name="GIMP Engine Last Error",
            default="",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_engine_restart_count = (
        bpy.props.IntProperty(
            name="GIMP Engine Automatic Restarts",
            default=0,
            min=0,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_gimp_detected = (
        bpy.props.BoolProperty(
            name="GIMP Detected",
            default=False
        )
    )

    bpy.types.Scene.blendgimp_gimp_path = (
        bpy.props.StringProperty(
            name="GIMP Path",
            default=""
        )
    )

    bpy.types.Scene.blendgimp_gimp_version = (
        bpy.props.StringProperty(
            name="GIMP Version",
            default=""
        )
    )

    bpy.types.Scene.blendgimp_gimp_running = (
        bpy.props.BoolProperty(
            name="GIMP Running",
            default=False
        )
    )

    bpy.types.Scene.blendgimp_connected = (
        bpy.props.BoolProperty(
            name="BlendGimp Connected",
            default=False
        )
    )

    bpy.types.Scene.blendgimp_protocol_version = (
        bpy.props.IntProperty(
            name="Protocol Version",
            default=0
        )
    )

    bpy.types.Scene.blendgimp_remote_version = (
        bpy.props.StringProperty(
            name="GIMP Component Version",
            default=""
        )
    )

    bpy.types.Scene.blendgimp_runtime_gimp_version = (
        bpy.props.StringProperty(
            name="Runtime GIMP Version",
            default=""
        )
    )

    bpy.types.Scene.blendgimp_create_name = (
        bpy.props.StringProperty(
            name="Texture Name",
            description="Name shared by the Blender-owned texture pair",
            default="BaseColor"
        )
    )

    bpy.types.Scene.blendgimp_create_width = (
        bpy.props.IntProperty(
            name="Texture Width",
            default=2048,
            min=1,
            max=32768
        )
    )

    bpy.types.Scene.blendgimp_create_height = (
        bpy.props.IntProperty(
            name="Texture Height",
            default=2048,
            min=1,
            max=32768
        )
    )

    bpy.types.Scene.blendgimp_create_format = (
        bpy.props.EnumProperty(
            name="Texture Format",
            items=(
                (
                    "RGBA",
                    "RGBA",
                    "RGB color with an alpha channel"
                ),
                (
                    "RGB",
                    "RGB",
                    "Opaque RGB color without an alpha channel"
                ),
            ),
            default="RGBA"
        )
    )

    bpy.types.Scene.blendgimp_create_background = (
        bpy.props.EnumProperty(
            name="Texture Background",
            items=(
                (
                    "TRANSPARENT",
                    "Transparent",
                    "Initialize the RGBA layer with transparent pixels"
                ),
                (
                    "SOLID",
                    "Solid",
                    "Initialize the layer with the selected opaque color"
                ),
            ),
            default="TRANSPARENT"
        )
    )

    bpy.types.Scene.blendgimp_create_background_color = (
        bpy.props.FloatVectorProperty(
            name="Background Color",
            subtype="COLOR",
            size=4,
            min=0.0,
            max=1.0,
            default=(0.0, 0.0, 0.0, 1.0)
        )
    )

    bpy.types.Scene.blendgimp_create_layer_name = (
        bpy.props.StringProperty(
            name="Initial Layer Name",
            default="BaseColor"
        )
    )

    bpy.types.Scene.blendgimp_created_image_id = (
        bpy.props.IntProperty(
            name="Last Created GIMP Image ID",
            default=-1,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_created_layer_id = (
        bpy.props.IntProperty(
            name="Last Created GIMP Layer ID",
            default=-1,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_create_status = (
        bpy.props.StringProperty(
            name="Create Texture Status",
            default="",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_images_queried = (
        bpy.props.BoolProperty(
            name="GIMP Images Queried",
            default=False,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_image_count = (
        bpy.props.IntProperty(
            name="Open GIMP Image Count",
            default=0,
            min=0,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_images_json = (
        bpy.props.StringProperty(
            name="Open GIMP Images JSON",
            default="[]",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_layers_json = (
        bpy.props.StringProperty(
            name="GIMP Layer Results JSON",
            default="{}",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_texture_sync_json = (
        bpy.props.StringProperty(
            name="BlendGimp Texture Sync JSON",
            default="{}",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_active = (
        bpy.props.BoolProperty(
            name="Direct GIMP 3D Paint Active",
            default=False,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_image_id = (
        bpy.props.IntProperty(
            name="Direct GIMP 3D Paint Image ID",
            default=-1,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_status = (
        bpy.props.StringProperty(
            name="Direct GIMP 3D Paint Status",
            default="",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_brush = (
        bpy.props.StringProperty(
            name="Direct GIMP Brush",
            default="",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_front_faces_only = (
        bpy.props.BoolProperty(
            name="Front Faces Only",
            description=(
                "Reject direct-paint ray hits whose surface normal faces "
                "away from the viewport"
            ),
            default=True
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_occlusion_mode = (
        bpy.props.EnumProperty(
            name="Direct Paint Surface Mode",
            description=(
                "Choose nearest-visible-surface painting or raycast through "
                "all mesh surfaces"
            ),
            items=(
                (
                    "VISIBLE",
                    "Visible Surface",
                    "Paint only the nearest visible surface"
                ),
                (
                    "THROUGH",
                    "Paint Through",
                    "Paint every allowed mesh surface along the viewport ray"
                ),
            ),
            default="VISIBLE"
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_projection_mesh = (
        bpy.props.EnumProperty(
            name="Direct Paint Projection Mesh",
            description=(
                "Choose whether direct paint projects onto the viewport's "
                "evaluated modifier result or the original mesh"
            ),
            items=(
                (
                    "AUTO",
                    "Evaluated (Auto Fallback)",
                    "Use evaluated geometry and automatically fall back to "
                    "the original mesh if the active UV map is unavailable"
                ),
                (
                    "EVALUATED",
                    "Require Evaluated",
                    "Require modifier-evaluated geometry and cancel startup "
                    "instead of falling back when its UV map is unavailable"
                ),
                (
                    "ORIGINAL",
                    "Original Mesh",
                    "Project onto the original unmodified mesh"
                ),
            ),
            default="AUTO"
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_footprint_protection = (
        bpy.props.BoolProperty(
            name="Protect Brush Footprint",
            description=(
                "Raycast around the projected GIMP brush radius and reject "
                "stamps that cross a silhouette, UV boundary, or thin "
                "occluding surface"
            ),
            default=True
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_footprint_samples = (
        bpy.props.IntProperty(
            name="Footprint Rays",
            description=(
                "Number of protective raycasts around the brush perimeter"
            ),
            default=8,
            min=4,
            max=16
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_footprint_safe_ratio = (
        bpy.props.FloatProperty(
            name="Footprint Surface Coverage",
            description=(
                "Minimum compatible perimeter-ray coverage for surface "
                "boundaries; true silhouette misses are always rejected"
            ),
            default=0.75,
            min=0.5,
            max=1.0,
            subtype="FACTOR",
            precision=2
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_normal_angle_enabled = (
        bpy.props.BoolProperty(
            name="Limit View Angle",
            description=(
                "Reject surfaces viewed beyond the configured normal angle"
            ),
            default=False
        )
    )

    bpy.types.Scene.blendgimp_direct_paint_normal_angle_limit = (
        bpy.props.FloatProperty(
            name="Maximum View Angle",
            description=(
                "Largest allowed angle between the surface normal and view"
            ),
            default=75.0,
            min=0.0,
            max=180.0,
            precision=1
        )
    )

    bpy.types.Scene.blendgimp_blender_paint_sync_enabled = (
        bpy.props.BoolProperty(
            name="Unified Paint Sync",
            default=False,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_blender_paint_sync_image_id = (
        bpy.props.IntProperty(
            name="3D Paint Sync GIMP Image ID",
            default=-1,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_blender_paint_sync_layer_id = (
        bpy.props.IntProperty(
            name="3D Paint Sync GIMP Layer ID",
            default=-1,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_blender_paint_sync_status = (
        bpy.props.StringProperty(
            name="3D Paint Sync Status",
            default="Off",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_blender_paint_sync_debounce = (
        bpy.props.FloatProperty(
            name="Unified Paint Sync Delay",
            description=(
                "Wait this long after the most recent Blender Texture Paint "
                "change before pushing its dirty region to GIMP"
            ),
            default=0.12,
            min=0.05,
            max=5.0,
            precision=2,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_auto_sync_enabled = (
        bpy.props.BoolProperty(
            name="GIMP Auto Sync",
            default=False,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_auto_sync_image_id = (
        bpy.props.IntProperty(
            name="Auto Sync GIMP Image ID",
            default=-1,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_auto_sync_revision = (
        bpy.props.IntProperty(
            name="Auto Sync Revision",
            default=0,
            min=0,
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_auto_sync_status = (
        bpy.props.StringProperty(
            name="Auto Sync Status",
            default="Off",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_auto_sync_detector = (
        bpy.props.StringProperty(
            name="Auto Sync Detector",
            default="",
            options={"SKIP_SAVE"}
        )
    )

    bpy.types.Scene.blendgimp_auto_sync_debounce = (
        bpy.props.FloatProperty(
            name="Auto Sync Delay",
            description=(
                "Wait this long after the most recent detected GIMP change "
                "before exporting the composite"
            ),
            default=0.6,
            min=0.1,
            max=5.0,
            precision=2,
            options={"SKIP_SAVE"}
        )
    )

    reset_engine_lifecycle_runtime()
    reset_auto_sync_runtime()
    reset_blender_paint_sync_runtime()

    if not bpy.app.timers.is_registered(
        blendgimp_engine_lifecycle_timer
    ):
        bpy.app.timers.register(
            blendgimp_engine_lifecycle_timer,
            first_interval=ENGINE_LIFECYCLE_POLL_INTERVAL,
            persistent=True
        )

    if not bpy.app.timers.is_registered(
        blendgimp_blender_paint_sync_timer
    ):
        bpy.app.timers.register(
            blendgimp_blender_paint_sync_timer,
            first_interval=BLENDER_PAINT_SYNC_POLL_INTERVAL,
            persistent=True
        )

    if not bpy.app.timers.is_registered(
        blendgimp_auto_sync_timer
    ):
        bpy.app.timers.register(
            blendgimp_auto_sync_timer,
            first_interval=AUTO_SYNC_POLL_INTERVAL,
            persistent=True
        )

    print(
        "BLENDGIMP: Main panel registered"
    )


# ============================================================
# UNREGISTER
# ============================================================

def unregister():

    try:
        bpy.types.IMAGE_MT_image.remove(draw_blendgimp_image_menu)
    except Exception:
        pass

    # --------------------------------------------------------
    # Stop lifecycle recovery before closing the connection.
    # --------------------------------------------------------

    try:
        if bpy.app.timers.is_registered(
            blendgimp_engine_lifecycle_timer
        ):
            bpy.app.timers.unregister(
                blendgimp_engine_lifecycle_timer
            )
    except Exception:
        pass

    global _EXIT_PRE_HANDLED

    try:
        if blendgimp_exit_pre in bpy.app.handlers.exit_pre:
            bpy.app.handlers.exit_pre.remove(blendgimp_exit_pre)
    except Exception:
        pass
    try:
        if blendgimp_undo_redo_post in bpy.app.handlers.undo_post:
            bpy.app.handlers.undo_post.remove(blendgimp_undo_redo_post)
        if blendgimp_undo_redo_post in bpy.app.handlers.redo_post:
            bpy.app.handlers.redo_post.remove(blendgimp_undo_redo_post)
    except Exception:
        pass

    if _EXIT_PRE_HANDLED:
        # exit_pre already protected/saved documents and handled the engine.
        connection_manager.disconnect()
        gimp_manager.clear_process_reference()
    else:
        engine_snapshot = (
            gimp_manager.get_engine_snapshot()
        )

        # A normal headless session belongs to BlendGimp and should not be left
        # orphaned after the extension is disabled. A visible debug session may
        # contain manual work, so preserve the original behavior and leave it open.
        if (
            engine_snapshot.get(
                "running",
                False
            )
            and engine_snapshot.get(
                "mode"
            ) == gimp_manager.ENGINE_MODE_HEADLESS
        ):
            # Blender may tear down an extension before exit_pre is delivered.
            # Treat unregister itself as a second recovery boundary so dirty
            # headless documents are never dependent on handler ordering.
            print(
                "BLENDGIMP: unregister lifecycle fallback entered for "
                "headless engine",
                flush=True,
            )

            scene = getattr(bpy.context, "scene", None)
            if scene is None and bpy.data.scenes:
                scene = bpy.data.scenes[0]

            recovery_failed = False
            if connection_manager.is_connected() and scene is not None:
                try:
                    save_result = _save_dirty_images_for_exit(scene)
                except Exception as exc:
                    save_result = {
                        "saved": 0,
                        "recovery": 0,
                        "failed": [(-1, str(exc))],
                    }

                failures = list(save_result.get("failed", []))
                if failures:
                    recovery_failed = True
                    print(
                        "BLENDGIMP: unregister recovery could not save all "
                        "dirty documents; leaving headless GIMP running",
                        flush=True,
                    )
                    for image_id, error in failures:
                        print(
                            "BLENDGIMP: unregister recovery failure "
                            f"image ID {image_id}: {error}",
                            flush=True,
                        )
                else:
                    recovery_count = int(save_result.get("recovery", 0))
                    if recovery_count > 0:
                        print(
                            "BLENDGIMP: unregister recovery saved "
                            f"{recovery_count} new XCF document(s) to "
                            f"{_recovery_save_directory()}",
                            flush=True,
                        )
                    elif int(save_result.get("saved", 0)) > 0:
                        print(
                            "BLENDGIMP: unregister recovery saved dirty "
                            "XCF document(s) in place",
                            flush=True,
                        )
            elif connection_manager.is_connected() and scene is None:
                recovery_failed = True
                print(
                    "BLENDGIMP: unregister recovery could not resolve a "
                    "Scene; leaving headless GIMP running to avoid data loss",
                    flush=True,
                )

            graceful_requested = False
            shutdown_refused = False

            if recovery_failed:
                shutdown_refused = True
            elif connection_manager.is_connected():
                try:
                    connection_manager.shutdown_engine(
                        force=False
                    )
                    graceful_requested = True
                except GimpEngineShutdownRefusedError as exc:
                    shutdown_refused = True
                    print(
                        "BLENDGIMP: "
                        "Headless engine kept alive to protect unsaved "
                        f"image changes: {exc}"
                    )
                except Exception as exc:
                    print(
                        "BLENDGIMP: "
                        "Extension shutdown request failed; "
                        f"using process fallback: {exc}"
                    )

            connection_manager.disconnect()

            if shutdown_refused:
                gimp_manager.clear_process_reference()
            else:
                gimp_manager.stop_gimp(
                    graceful_requested=graceful_requested
                )
        else:
            connection_manager.disconnect()
            gimp_manager.clear_process_reference()

    try:
        if bpy.app.timers.is_registered(
            blendgimp_blender_paint_sync_timer
        ):
            bpy.app.timers.unregister(
                blendgimp_blender_paint_sync_timer
            )
    except Exception:
        pass

    try:
        if bpy.app.timers.is_registered(
            blendgimp_auto_sync_timer
        ):
            bpy.app.timers.unregister(
                blendgimp_auto_sync_timer
            )
    except Exception:
        pass

    reset_engine_lifecycle_runtime()
    reset_auto_sync_runtime()
    reset_blender_paint_sync_runtime()

    del (
        bpy.types.Scene.
        blendgimp_engine_restart_count
    )

    del (
        bpy.types.Scene.
        blendgimp_engine_last_error
    )

    del (
        bpy.types.Scene.
        blendgimp_engine_state
    )

    del (
        bpy.types.Scene.
        blendgimp_engine_should_run
    )

    del (
        bpy.types.Scene.
        blendgimp_engine_auto_reconnect
    )

    del (
        bpy.types.Scene.
        blendgimp_engine_mode
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_normal_angle_limit
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_normal_angle_enabled
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_footprint_safe_ratio
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_footprint_samples
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_footprint_protection
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_occlusion_mode
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_projection_mesh
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_front_faces_only
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_brush
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_status
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_image_id
    )

    del (
        bpy.types.Scene.
        blendgimp_direct_paint_active
    )

    del (
        bpy.types.Scene.
        blendgimp_blender_paint_sync_debounce
    )

    del (
        bpy.types.Scene.
        blendgimp_blender_paint_sync_status
    )

    del (
        bpy.types.Scene.
        blendgimp_blender_paint_sync_layer_id
    )

    del (
        bpy.types.Scene.
        blendgimp_blender_paint_sync_image_id
    )

    del (
        bpy.types.Scene.
        blendgimp_blender_paint_sync_enabled
    )

    del (
        bpy.types.Scene.
        blendgimp_auto_sync_debounce
    )

    del (
        bpy.types.Scene.
        blendgimp_auto_sync_detector
    )

    del (
        bpy.types.Scene.
        blendgimp_auto_sync_status
    )

    del (
        bpy.types.Scene.
        blendgimp_auto_sync_revision
    )

    del (
        bpy.types.Scene.
        blendgimp_auto_sync_image_id
    )

    del (
        bpy.types.Scene.
        blendgimp_auto_sync_enabled
    )

    del (
        bpy.types.Scene.
        blendgimp_texture_sync_json
    )

    del (
        bpy.types.Scene.
        blendgimp_layers_json
    )

    del (
        bpy.types.Scene.
        blendgimp_images_json
    )

    del (
        bpy.types.Scene.
        blendgimp_image_count
    )

    del (
        bpy.types.Scene.
        blendgimp_images_queried
    )

    del (
        bpy.types.Scene.
        blendgimp_create_status
    )

    del (
        bpy.types.Scene.
        blendgimp_created_layer_id
    )

    del (
        bpy.types.Scene.
        blendgimp_created_image_id
    )

    del (
        bpy.types.Scene.
        blendgimp_create_layer_name
    )

    del (
        bpy.types.Scene.
        blendgimp_create_background_color
    )

    del (
        bpy.types.Scene.
        blendgimp_create_background
    )

    del (
        bpy.types.Scene.
        blendgimp_create_format
    )

    del (
        bpy.types.Scene.
        blendgimp_create_height
    )

    del (
        bpy.types.Scene.
        blendgimp_create_width
    )

    del (
        bpy.types.Scene.
        blendgimp_create_name
    )

    del (
        bpy.types.Scene.
        blendgimp_runtime_gimp_version
    )

    del (
        bpy.types.Scene.
        blendgimp_remote_version
    )

    del (
        bpy.types.Scene.
        blendgimp_protocol_version
    )

    del (
        bpy.types.Scene.
        blendgimp_connected
    )

    del (
        bpy.types.Scene.
        blendgimp_gimp_running
    )

    del (
        bpy.types.Scene.
        blendgimp_gimp_version
    )

    del (
        bpy.types.Scene.
        blendgimp_gimp_path
    )

    del (
        bpy.types.Scene.
        blendgimp_gimp_detected
    )

    for cls in reversed(
        classes
    ):

        bpy.utils.unregister_class(
            cls
        )

    print(
        "BLENDGIMP: Main panel unregistered"
    )
