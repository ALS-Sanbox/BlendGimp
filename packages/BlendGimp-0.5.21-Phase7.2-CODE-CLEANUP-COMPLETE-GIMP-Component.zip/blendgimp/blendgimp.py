#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import json
import socket
import threading
import time
import traceback
import os
import tempfile
import uuid
import hashlib
import base64
import math

import gi
gi.require_version("Gimp", "3.0")
gi.require_version("Gegl", "0.4")
gi.require_version("Babl", "0.1")
from gi.repository import Gimp, GLib, Gio, Gegl, Babl


# -----------------------------------------------------------------------------
# BlendGimp IPC configuration
# -----------------------------------------------------------------------------

PLUGIN_PROC = "extension-blendgimp"
HOST = "127.0.0.1"
PORT = 8765
PROTOCOL_VERSION = 1
BLENDGIMP_VERSION = "0.5.21"

# One generated token per open GIMP image ID for the lifetime of this
# persistent BlendGimp plug-in session. This keeps refresh paths stable while
# avoiding dependence on user document names such as "Demo.xcf".
BLENDGIMP_COMPOSITE_TOKENS = {}

# GIMP assigns generic "Untitled" names to new unsaved images. Keep the
# Blender-requested texture name for this engine session so GET_IMAGES and all
# synchronization responses can identify Blender-owned textures without an XCF
# file or a fake on-disk filename.
BLENDGIMP_IMAGE_NAMES = {}

# Per-image visual state maintained only for the lifetime of the persistent
# BlendGimp GIMP plug-in process. `revision` increases whenever the visible
# composite fingerprint changes. It does not alter GIMP's own dirty/save state.
BLENDGIMP_IMAGE_VISUAL_STATE = {}

# Last full-resolution visible composite per GIMP image. This is BlendGimp's
# Stage-1 dirty-rectangle baseline. It is in-memory only and never modifies the
# user's GIMP document.
BLENDGIMP_PIXEL_SNAPSHOTS = {}

# Native GEGL damage trackers, one per open GIMP image. These listen to the
# drawable buffers' "changed" signal and accumulate the exact image-space
# rectangle touched by painting/edit operations.
BLENDGIMP_DAMAGE_TRACKERS = {}

# Blender-originated writes are temporarily tracked by the final composited
# pixel hash. IMAGE_STATE uses this to distinguish a delayed thumbnail/cache
# change caused by our own write from a real subsequent GIMP edit.
BLENDGIMP_ECHO_SUPPRESSION = {}
BLENDGIMP_ECHO_SUPPRESSION_SECONDS = 2.0

# GIMP supports thumbnails up to 1024px. This is now a compatibility fallback
# only when GEGL Buffer::changed cannot be connected in the Python runtime.
# Stage-1 fallback detector that runs inside GIMP and sends only a hash.
BLENDGIMP_STATE_THUMBNAIL_SIZE = 1024

BLENDGIMP_PAINT_LAYER_NAME = "BlendGimp Paint"

# Live direct 3D strokes keep one GIMP undo group open while Blender streams
# several paintbrush chunks. The server closes any remaining groups if the
# Blender socket disconnects unexpectedly.
BLENDGIMP_ACTIVE_DIRECT_STROKES = {}


def _blendgimp_composite_token(image_id):
    image_id = int(image_id)

    token = BLENDGIMP_COMPOSITE_TOKENS.get(
        image_id
    )

    if token is None:
        token = uuid.uuid4().hex
        BLENDGIMP_COMPOSITE_TOKENS[
            image_id
        ] = token

    return token


def _blendgimp_image_name(image):
    image_id = int(image.get_id())

    requested_name = BLENDGIMP_IMAGE_NAMES.get(image_id)

    if requested_name:
        return str(requested_name)

    name = image.get_name()
    return "" if name is None else str(name)


# -----------------------------------------------------------------------------
# Logging
# -----------------------------------------------------------------------------

def log(message):
    print(f"BLENDGIMP-GIMP: {message}", flush=True)


# -----------------------------------------------------------------------------
# GIMP main-thread dispatcher
# -----------------------------------------------------------------------------

class GimpMainThreadDispatcher:
    """Marshal GIMP API work from worker threads onto GIMP's main thread."""

    def __init__(self):
        # Constructed from the persistent procedure's run function, which is
        # executing on GIMP's plug-in main thread.
        self._main_thread_id = threading.get_ident()

    def call(
        self,
        function,
        *args,
        timeout=5.0,
        log_exceptions=True,
        **kwargs
    ):
        """Run *function* on GIMP's main thread and return its result."""

        # Avoid scheduling through GLib when already on the GIMP main thread.
        if threading.get_ident() == self._main_thread_id:
            return function(*args, **kwargs)

        finished = threading.Event()
        result = {}

        def run_on_main_thread():
            try:
                result["value"] = function(*args, **kwargs)
            except Exception as exc:
                result["error"] = exc
                result["traceback"] = traceback.format_exc()
            finally:
                finished.set()

            # GLib.idle_add() should invoke this callback once only.
            return GLib.SOURCE_REMOVE

        GLib.idle_add(run_on_main_thread)

        if not finished.wait(timeout):
            raise TimeoutError(
                f"Timed out after {timeout:.1f}s waiting for GIMP main-thread command"
            )

        if "error" in result:
            if log_exceptions:
                log(
                    "Main-thread command failed:\n"
                    + result.get("traceback", "")
                )
            raise result["error"]

        return result.get("value")


# -----------------------------------------------------------------------------
# Read-only GIMP commands
# -----------------------------------------------------------------------------

def _blendgimp_gfile_path(gfile):
    if gfile is None:
        return ""

    try:
        path = gfile.get_path()
    except Exception:
        path = None

    if path:
        return os.path.abspath(str(path))

    try:
        uri = gfile.get_uri()
    except Exception:
        uri = None

    return "" if not uri else str(uri)


def gimp_get_images_snapshot():
    """
    MAIN THREAD ONLY.

    Return metadata for every image currently open in GIMP.
    This does not read pixel buffers and does not modify image state.
    """

    images_snapshot = []

    for image in Gimp.get_images():
        name = _blendgimp_image_name(image)
        xcf_path = _blendgimp_gfile_path(
            image.get_xcf_file()
        )

        images_snapshot.append(
            {
                "id": int(image.get_id()),
                "name": name,
                "width": int(image.get_width()),
                "height": int(image.get_height()),
                "dirty": bool(image.is_dirty()),
                "xcf_path": xcf_path,
                "saved": bool(xcf_path) and not bool(image.is_dirty()),
            }
        )

    return images_snapshot


def gimp_get_shutdown_state():
    """
    MAIN THREAD ONLY.

    Report whether GIMP can close without discarding unsaved image changes.
    """

    images = list(
        Gimp.get_images()
    )
    dirty_images = []

    for image in images:
        if not image.is_dirty():
            continue

        name = _blendgimp_image_name(image)

        dirty_images.append(
            {
                "id": int(image.get_id()),
                "name": "" if name is None else str(name),
            }
        )

    return {
        "image_count": len(images),
        "dirty_images": dirty_images,
        "dirty_image_count": len(dirty_images),
    }


def gimp_create_image(
    name,
    width,
    height,
    image_format,
    background,
    background_color,
    layer_name,
):
    """MAIN THREAD ONLY. Create a Blender-owned GIMP image and base layer."""

    name = str(name or "BlendGimp Texture").strip()
    layer_name = str(layer_name or "BaseColor").strip()
    width = int(width)
    height = int(height)
    image_format = str(image_format or "RGBA").upper()
    background = str(background or "TRANSPARENT").upper()

    if not name:
        raise ValueError("Image name cannot be empty")

    if not layer_name:
        raise ValueError("Initial layer name cannot be empty")

    if not 1 <= width <= 32768 or not 1 <= height <= 32768:
        raise ValueError("Image dimensions must be between 1 and 32768")

    if image_format not in {"RGB", "RGBA"}:
        raise ValueError("Image format must be RGB or RGBA")

    if background not in {"TRANSPARENT", "SOLID"}:
        raise ValueError("Background must be TRANSPARENT or SOLID")

    if image_format == "RGB" and background == "TRANSPARENT":
        raise ValueError("RGB images require a solid background")

    try:
        color = tuple(
            max(0.0, min(1.0, float(component)))
            for component in background_color
        )
    except (TypeError, ValueError):
        raise ValueError("Background color must contain four numbers")

    if len(color) != 4:
        raise ValueError("Background color must contain four numbers")

    image = None
    context_pushed = False

    try:
        image = Gimp.Image.new(
            width,
            height,
            Gimp.ImageBaseType.RGB,
        )

        if image is None or not image.is_valid():
            raise RuntimeError("GIMP could not create the image")

        layer_type = (
            Gimp.ImageType.RGBA_IMAGE
            if image_format == "RGBA"
            else Gimp.ImageType.RGB_IMAGE
        )

        layer = Gimp.Layer.new(
            image,
            layer_name,
            width,
            height,
            layer_type,
            100.0,
            image.get_default_new_layer_mode(),
        )

        if layer is None or not layer.is_valid():
            raise RuntimeError("GIMP could not create the initial layer")

        if background == "TRANSPARENT":
            filled = layer.fill(Gimp.FillType.TRANSPARENT)
        else:
            context_pushed = bool(Gimp.context_push())

            if not context_pushed:
                raise RuntimeError("GIMP could not isolate the fill context")

            # A solid background is opaque by definition. Gegl.Color accepts
            # normalized floating-point CSS color components.
            solid_color = Gegl.Color.new(
                "rgba("
                f"{color[0]:.9f},"
                f"{color[1]:.9f},"
                f"{color[2]:.9f},1.0)"
            )

            if not Gimp.context_set_foreground(solid_color):
                raise RuntimeError("GIMP could not set the background color")

            filled = layer.fill(Gimp.FillType.FOREGROUND)

        if filled is False:
            raise RuntimeError("GIMP could not initialize the layer pixels")

        if context_pushed:
            Gimp.context_pop()
            context_pushed = False

        if not image.insert_layer(layer, None, 0):
            raise RuntimeError("GIMP could not insert the initial layer")

        image.set_selected_layers([layer])

        image_id = int(image.get_id())
        layer_id = int(layer.get_id())

        BLENDGIMP_IMAGE_NAMES[image_id] = name
        sync_token = _blendgimp_composite_token(image_id)

        Gimp.displays_flush()

        return {
            "image_id": image_id,
            "layer_id": layer_id,
            "name": name,
            "layer_name": str(layer.get_name() or layer_name),
            "width": int(image.get_width()),
            "height": int(image.get_height()),
            "format": image_format,
            "background": background,
            "background_color": [
                color[0],
                color[1],
                color[2],
                0.0 if background == "TRANSPARENT" else 1.0,
            ],
            "sync_token": sync_token,
            "blender_owned": True,
        }

    except Exception:
        if image is not None and image.is_valid():
            try:
                image.delete()
            except Exception:
                pass
        raise

    finally:
        if context_pushed:
            try:
                Gimp.context_pop()
            except Exception:
                pass



# GIMP 3.2.4 layer-mode names supported by BlendGimp.
BLENDGIMP_LAYER_MODE_NAMES = ['NORMAL_LEGACY', 'DISSOLVE', 'BEHIND_LEGACY', 'MULTIPLY_LEGACY', 'SCREEN_LEGACY', 'OVERLAY_LEGACY', 'DIFFERENCE_LEGACY', 'ADDITION_LEGACY', 'SUBTRACT_LEGACY', 'DARKEN_ONLY_LEGACY', 'LIGHTEN_ONLY_LEGACY', 'HSV_HUE_LEGACY', 'HSV_SATURATION_LEGACY', 'HSL_COLOR_LEGACY', 'HSV_VALUE_LEGACY', 'DIVIDE_LEGACY', 'DODGE_LEGACY', 'BURN_LEGACY', 'HARDLIGHT_LEGACY', 'SOFTLIGHT_LEGACY', 'GRAIN_EXTRACT_LEGACY', 'GRAIN_MERGE_LEGACY', 'COLOR_ERASE_LEGACY', 'OVERLAY', 'LCH_HUE', 'LCH_CHROMA', 'LCH_COLOR', 'LCH_LIGHTNESS', 'NORMAL', 'BEHIND', 'MULTIPLY', 'SCREEN', 'DIFFERENCE', 'ADDITION', 'SUBTRACT', 'DARKEN_ONLY', 'LIGHTEN_ONLY', 'HSV_HUE', 'HSV_SATURATION', 'HSL_COLOR', 'HSV_VALUE', 'DIVIDE', 'DODGE', 'BURN', 'HARDLIGHT', 'SOFTLIGHT', 'GRAIN_EXTRACT', 'GRAIN_MERGE', 'VIVID_LIGHT', 'PIN_LIGHT', 'LINEAR_LIGHT', 'HARD_MIX', 'EXCLUSION', 'LINEAR_BURN', 'LUMA_DARKEN_ONLY', 'LUMA_LIGHTEN_ONLY', 'LUMINANCE', 'COLOR_ERASE', 'ERASE', 'MERGE', 'SPLIT', 'PASS_THROUGH', 'REPLACE', 'OVERWRITE']


def _gimp_layer_mode_name(mode):
    """
    MAIN THREAD ONLY.

    Convert a Gimp.LayerMode enum value to its stable Python enum name.
    """

    mode_value = int(mode)

    for mode_name in BLENDGIMP_LAYER_MODE_NAMES:

        enum_value = getattr(
            Gimp.LayerMode,
            mode_name,
            None
        )

        if (
            enum_value is not None
            and int(enum_value) == mode_value
        ):
            return mode_name

    return f"UNKNOWN_{mode_value}"


BLENDGIMP_COLOR_TAG_NAMES = [
    "NONE", "BLUE", "GREEN", "YELLOW", "ORANGE",
    "BROWN", "RED", "VIOLET", "GRAY",
]


def _gimp_color_tag_name(color_tag):
    """Return a stable JSON-safe GIMP color-tag name."""
    try:
        value = int(color_tag)
    except Exception:
        return "NONE"
    for name in BLENDGIMP_COLOR_TAG_NAMES:
        enum_value = getattr(Gimp.ColorTag, name, None)
        if enum_value is not None and int(enum_value) == value:
            return name
    return "NONE"


def _gimp_layer_snapshot(layer, selected_ids):
    """
    MAIN THREAD ONLY.

    Convert a GIMP layer (including group layers) into JSON-safe metadata.
    Group children are collected recursively from topmost to bottommost.
    """

    layer_id = int(layer.get_id())
    name = layer.get_name()
    is_group = bool(layer.is_group())

    image = layer.get_image()

    parent_item = layer.get_parent()

    parent_id = (
        None
        if parent_item is None
        else int(parent_item.get_id())
    )

    position = (
        int(image.get_item_position(layer))
        if image is not None and image.is_valid()
        else -1
    )

    children = []

    if is_group:
        for child_item in layer.get_children():
            child_id = int(child_item.get_id())

            # get_children() is typed as Gimp.Item. Resolve it back to a
            # Gimp.Layer so layer-specific methods such as get_opacity()
            # are always available through the Python binding.
            child_layer = Gimp.Layer.get_by_id(child_id)

            if child_layer is None:
                continue

            children.append(
                _gimp_layer_snapshot(
                    child_layer,
                    selected_ids,
                )
            )

    mask = None
    if not is_group:
        try:
            mask = layer.get_mask()
        except Exception:
            mask = None

    has_mask = bool(mask is not None and mask.is_valid())
    mask_id = int(mask.get_id()) if has_mask else -1
    mask_name = str(mask.get_name() or "Layer Mask") if has_mask else ""

    return {
        "id": layer_id,
        "name": "" if name is None else str(name),
        "visible": bool(layer.get_visible()),
        "opacity": float(layer.get_opacity()),
        "is_group": is_group,
        "selected": layer_id in selected_ids,
        "parent_id": parent_id,
        "position": position,
        "lock_content": bool(layer.get_lock_content()),
        "lock_position": bool(layer.get_lock_position()),
        "lock_visibility": bool(layer.get_lock_visibility()),
        "lock_alpha": bool(layer.get_lock_alpha()),
        "color_tag": _gimp_color_tag_name(layer.get_color_tag()),
        "has_mask": has_mask,
        "mask_id": mask_id,
        "mask_name": mask_name,
        "mask_apply": bool(layer.get_apply_mask()) if has_mask else False,
        "mask_edit": bool(layer.get_edit_mask()) if has_mask else False,
        "mask_show": bool(layer.get_show_mask()) if has_mask else False,
        "mode": _gimp_layer_mode_name(
            layer.get_mode()
        ),
        "mode_value": int(
            layer.get_mode()
        ),
        "children": children,
    }


def gimp_get_image_layers_snapshot(image_id):
    """
    MAIN THREAD ONLY.

    Return the complete layer tree for one currently open GIMP image.

    This is read-only:
        - no layer state is changed
        - no pixels are read
        - no selections are changed
        - no image is saved
    """

    image_id = int(image_id)

    image = Gimp.Image.get_by_id(image_id)

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    selected_ids = set()

    for selected_layer in image.get_selected_layers():
        selected_ids.add(
            int(selected_layer.get_id())
        )

    layers = []

    for layer in image.get_layers():
        layers.append(
            _gimp_layer_snapshot(
                layer,
                selected_ids,
            )
        )

    def count_layers(items):
        total = 0

        for item in items:
            total += 1
            total += count_layers(
                item.get("children", [])
            )

        return total

    image_name = _blendgimp_image_name(image)

    return {
        "image_id": image_id,
        "image_name": (
            ""
            if image_name is None
            else str(image_name)
        ),
        "root_count": len(layers),
        "layer_count": count_layers(layers),
        "layers": layers,
    }


# -----------------------------------------------------------------------------
# Layer mutation helpers
# -----------------------------------------------------------------------------

def _gimp_resolve_image_layer(image_id, layer_id):
    """
    MAIN THREAD ONLY.

    Resolve and validate an image/layer pair.  The layer must currently
    belong to the requested image.
    """

    image_id = int(image_id)
    layer_id = int(layer_id)

    image = Gimp.Image.get_by_id(image_id)

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    layer = Gimp.Layer.get_by_id(layer_id)

    if layer is None or not layer.is_valid():
        raise ValueError(
            f"Layer ID {layer_id} is not a valid GIMP layer"
        )

    owner_image = layer.get_image()

    if (
        owner_image is None
        or not owner_image.is_valid()
        or int(owner_image.get_id()) != image_id
    ):
        raise ValueError(
            f"Layer ID {layer_id} does not belong to image ID {image_id}"
        )

    return image, layer


def _gimp_layer_edit_drawable(layer):
    """MAIN THREAD ONLY. Return the raster drawable currently edited for a layer.

    Layer-mask edit state is authoritative in GIMP. BlendGimp continues to
    identify the owner by layer ID, while raster operations are redirected to
    the layer mask when GIMP reports edit-mask=True.
    """
    if layer is None or not layer.is_valid():
        raise ValueError("Invalid GIMP layer")
    if layer.is_group():
        raise ValueError("Layer groups do not expose an editable raster drawable")
    try:
        if bool(layer.get_edit_mask()):
            mask = layer.get_mask()
            if mask is not None and mask.is_valid():
                return mask, "MASK"
    except Exception:
        pass
    return layer, "LAYER"


BLENDGIMP_MASK_TYPES = {
    "WHITE": Gimp.AddMaskType.WHITE,
    "BLACK": Gimp.AddMaskType.BLACK,
    "ALPHA": Gimp.AddMaskType.ALPHA,
    "ALPHA_TRANSFER": Gimp.AddMaskType.ALPHA_TRANSFER,
    "SELECTION": Gimp.AddMaskType.SELECTION,
    "COPY": Gimp.AddMaskType.COPY,
}


def gimp_add_layer_mask(image_id, layer_id, mask_type="WHITE"):
    """Create and attach a native GIMP layer mask, then enter mask-edit mode."""
    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    if layer.is_group():
        raise ValueError("Layer masks can only be added to raster layers")
    existing = layer.get_mask()
    if existing is not None and existing.is_valid():
        raise ValueError(f"Layer ID {layer_id} already has a mask")
    mask_key = str(mask_type or "WHITE").upper().strip()
    if mask_key not in BLENDGIMP_MASK_TYPES:
        raise ValueError(f"Unsupported layer mask type: {mask_key}")
    mask = layer.create_mask(BLENDGIMP_MASK_TYPES[mask_key])
    if mask is None or not mask.is_valid():
        raise RuntimeError("GIMP could not create the layer mask")
    if layer.add_mask(mask) is False:
        raise RuntimeError("GIMP could not attach the layer mask")
    if layer.set_apply_mask(True) is False:
        raise RuntimeError("GIMP could not enable the new layer mask")
    if layer.set_edit_mask(True) is False:
        raise RuntimeError("GIMP could not enter layer-mask edit mode")
    try:
        layer.set_show_mask(False)
    except Exception:
        pass
    image.set_selected_layers([layer])
    Gimp.displays_flush()
    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "mask_id": int(mask.get_id()),
        "mask_type": mask_key,
        "mask_apply": bool(layer.get_apply_mask()),
        "mask_edit": bool(layer.get_edit_mask()),
        "mask_show": bool(layer.get_show_mask()),
    }


def gimp_set_layer_mask_edit(image_id, layer_id, edit_mask):
    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    if layer.is_group():
        raise ValueError("Layer groups do not have layer masks")
    mask = layer.get_mask()
    if mask is None or not mask.is_valid():
        raise ValueError(f"Layer ID {layer_id} does not have a mask")
    if layer.set_edit_mask(bool(edit_mask)) is False:
        raise RuntimeError("GIMP could not change layer-mask edit state")
    image.set_selected_layers([layer])
    Gimp.displays_flush()
    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "mask_id": int(mask.get_id()),
        "mask_edit": bool(layer.get_edit_mask()),
        "target_kind": "MASK" if bool(layer.get_edit_mask()) else "LAYER",
    }


def gimp_set_layer_mask_apply(image_id, layer_id, apply_mask):
    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    mask = layer.get_mask()
    if mask is None or not mask.is_valid():
        raise ValueError(f"Layer ID {layer_id} does not have a mask")
    if layer.set_apply_mask(bool(apply_mask)) is False:
        raise RuntimeError("GIMP could not change layer-mask enabled state")
    Gimp.displays_flush()
    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "mask_id": int(mask.get_id()),
        "mask_apply": bool(layer.get_apply_mask()),
    }


def gimp_set_layer_mask_show(image_id, layer_id, show_mask):
    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    mask = layer.get_mask()
    if mask is None or not mask.is_valid():
        raise ValueError(f"Layer ID {layer_id} does not have a mask")
    if layer.set_show_mask(bool(show_mask)) is False:
        raise RuntimeError("GIMP could not change layer-mask display state")
    Gimp.displays_flush()
    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "mask_id": int(mask.get_id()),
        "mask_show": bool(layer.get_show_mask()),
    }


def gimp_remove_layer_mask(image_id, layer_id, apply=False):
    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    mask = layer.get_mask()
    if mask is None or not mask.is_valid():
        raise ValueError(f"Layer ID {layer_id} does not have a mask")
    mask_id = int(mask.get_id())
    # Return editing to the layer before the mask object is destroyed.
    try:
        layer.set_edit_mask(False)
    except Exception:
        pass
    mode = Gimp.MaskApplyMode.APPLY if bool(apply) else Gimp.MaskApplyMode.DISCARD
    if layer.remove_mask(mode) is False:
        raise RuntimeError("GIMP could not remove the layer mask")
    image.set_selected_layers([layer])
    Gimp.displays_flush()
    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "mask_id": mask_id,
        "applied": bool(apply),
        "has_mask": False,
    }


def gimp_set_active_layer(image_id, layer_id):
    """
    MAIN THREAD ONLY.

    Select exactly one layer in the requested image.
    """

    image, layer = _gimp_resolve_image_layer(
        image_id,
        layer_id,
    )

    success = image.set_selected_layers(
        [layer]
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not select layer ID {layer_id}"
        )

    Gimp.displays_flush()

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "selected": True,
    }


def gimp_set_layer_visibility(
    image_id,
    layer_id,
    visible,
):
    """
    MAIN THREAD ONLY.

    Set one layer's visibility.
    """

    image, layer = _gimp_resolve_image_layer(
        image_id,
        layer_id,
    )

    visible = bool(visible)

    success = layer.set_visible(
        visible
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not change visibility for layer ID {layer_id}"
        )

    Gimp.displays_flush()

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "visible": bool(layer.get_visible()),
    }


def gimp_set_layer_opacity(
    image_id,
    layer_id,
    opacity,
):
    """
    MAIN THREAD ONLY.

    Set one layer's opacity in GIMP's native 0..100 range.
    """

    image, layer = _gimp_resolve_image_layer(
        image_id,
        layer_id,
    )

    opacity = float(opacity)

    if opacity < 0.0:
        opacity = 0.0
    elif opacity > 100.0:
        opacity = 100.0

    success = layer.set_opacity(
        opacity
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not change opacity for layer ID {layer_id}"
        )

    Gimp.displays_flush()

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "opacity": float(layer.get_opacity()),
    }



# -----------------------------------------------------------------------------
# Full layer-management helpers
# -----------------------------------------------------------------------------

def _gimp_resolve_group_parent(
    image,
    parent_id,
):
    """
    MAIN THREAD ONLY.

    Resolve an optional target group. None / negative means top level.
    """

    if parent_id is None:
        return None

    parent_id = int(parent_id)

    if parent_id < 0:
        return None

    parent = Gimp.Layer.get_by_id(
        parent_id
    )

    if parent is None or not parent.is_valid():
        raise ValueError(
            f"Parent layer ID {parent_id} is not valid"
        )

    if not parent.is_group():
        raise ValueError(
            f"Layer ID {parent_id} is not a group layer"
        )

    parent_image = parent.get_image()

    if (
        parent_image is None
        or not parent_image.is_valid()
        or int(parent_image.get_id()) != int(image.get_id())
    ):
        raise ValueError(
            f"Group layer ID {parent_id} does not belong to image ID {image.get_id()}"
        )

    return parent


def _gimp_get_layer_parent_as_layer(
    layer
):
    """
    MAIN THREAD ONLY.

    Return the layer's parent as Gimp.Layer, or None for top-level layers.
    """

    parent_item = layer.get_parent()

    if parent_item is None:
        return None

    parent_id = int(
        parent_item.get_id()
    )

    parent = Gimp.Layer.get_by_id(
        parent_id
    )

    if parent is None or not parent.is_valid():
        raise RuntimeError(
            f"Could not resolve parent layer ID {parent_id}"
        )

    return parent


def _gimp_new_layer_type_for_image(
    image
):
    """
    MAIN THREAD ONLY.

    Create new editable layers with alpha matching the image base type.
    """

    base_type = image.get_base_type()

    if base_type == Gimp.ImageBaseType.RGB:
        return Gimp.ImageType.RGBA_IMAGE

    if base_type == Gimp.ImageBaseType.GRAY:
        return Gimp.ImageType.GRAYA_IMAGE

    if base_type == Gimp.ImageBaseType.INDEXED:
        return Gimp.ImageType.INDEXEDA_IMAGE

    raise RuntimeError(
        f"Unsupported GIMP image base type: {base_type}"
    )


def gimp_add_layer(
    image_id,
    name,
):
    """
    MAIN THREAD ONLY.

    Create a full-image transparent layer above the selected layer at the
    same hierarchy level. If no layer is selected, create it at the top level.
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    name = str(
        name or "New Layer"
    ).strip()

    if not name:
        name = "New Layer"

    parent = None
    position = 0

    selected_layers = list(
        image.get_selected_layers()
    )

    if selected_layers:

        selected = selected_layers[0]

        parent = (
            _gimp_get_layer_parent_as_layer(
                selected
            )
        )

        position = int(
            image.get_item_position(
                selected
            )
        )

    layer = Gimp.Layer.new(
        image,
        name,
        int(image.get_width()),
        int(image.get_height()),
        _gimp_new_layer_type_for_image(
            image
        ),
        100.0,
        image.get_default_new_layer_mode(),
    )

    if layer is None or not layer.is_valid():
        raise RuntimeError(
            "GIMP could not create the new layer"
        )

    success = image.insert_layer(
        layer,
        parent,
        position,
    )

    if not success:
        raise RuntimeError(
            "GIMP could not insert the new layer"
        )

    image.set_selected_layers(
        [layer]
    )

    Gimp.displays_flush()

    parent_id = (
        None
        if parent is None
        else int(parent.get_id())
    )

    return {
        "image_id": image_id,
        "layer_id": int(layer.get_id()),
        "name": str(layer.get_name() or ""),
        "parent_id": parent_id,
        "position": int(
            image.get_item_position(
                layer
            )
        ),
    }


def gimp_delete_layer(
    image_id,
    layer_id,
):
    """
    MAIN THREAD ONLY.

    Remove a layer or group layer from the image.
    """

    image, layer = (
        _gimp_resolve_image_layer(
            image_id,
            layer_id,
        )
    )

    name = str(
        layer.get_name() or ""
    )

    success = image.remove_layer(
        layer
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not delete layer ID {layer_id}"
        )

    Gimp.displays_flush()

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer_id),
        "name": name,
        "deleted": True,
    }


def gimp_rename_layer(
    image_id,
    layer_id,
    name,
):
    """
    MAIN THREAD ONLY.

    Rename a layer or group layer.
    """

    image, layer = (
        _gimp_resolve_image_layer(
            image_id,
            layer_id,
        )
    )

    name = str(
        name or ""
    ).strip()

    if not name:
        raise ValueError(
            "Layer name cannot be empty"
        )

    success = layer.set_name(
        name
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not rename layer ID {layer_id}"
        )

    Gimp.displays_flush()

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "name": str(layer.get_name() or ""),
    }


def gimp_duplicate_layer(
    image_id,
    layer_id,
):
    """
    MAIN THREAD ONLY.

    Duplicate a layer or group layer directly above the source item.
    """

    image, layer = (
        _gimp_resolve_image_layer(
            image_id,
            layer_id,
        )
    )

    parent = (
        _gimp_get_layer_parent_as_layer(
            layer
        )
    )

    position = int(
        image.get_item_position(
            layer
        )
    )

    duplicate = layer.copy()

    if duplicate is None or not duplicate.is_valid():
        raise RuntimeError(
            f"GIMP could not copy layer ID {layer_id}"
        )

    original_name = str(
        layer.get_name() or "Layer"
    )

    duplicate.set_name(
        f"{original_name} copy"
    )

    success = image.insert_layer(
        duplicate,
        parent,
        position,
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not insert duplicate of layer ID {layer_id}"
        )

    image.set_selected_layers(
        [duplicate]
    )

    Gimp.displays_flush()

    parent_id = (
        None
        if parent is None
        else int(parent.get_id())
    )

    return {
        "image_id": int(image.get_id()),
        "source_layer_id": int(layer.get_id()),
        "layer_id": int(duplicate.get_id()),
        "name": str(duplicate.get_name() or ""),
        "parent_id": parent_id,
        "position": int(
            image.get_item_position(
                duplicate
            )
        ),
    }


def gimp_reorder_layer(
    image_id,
    layer_id,
    direction,
):
    """
    MAIN THREAD ONLY.

    Move a layer one step up or down within its current hierarchy level.
    """

    image, layer = (
        _gimp_resolve_image_layer(
            image_id,
            layer_id,
        )
    )

    direction = str(
        direction or ""
    ).upper()

    if direction == "UP":
        success = image.raise_item(
            layer
        )

    elif direction == "DOWN":
        success = image.lower_item(
            layer
        )

    else:
        raise ValueError(
            "direction must be UP or DOWN"
        )

    if not success:
        raise RuntimeError(
            f"GIMP could not move layer ID {layer_id} {direction.lower()}"
        )

    Gimp.displays_flush()

    parent_item = layer.get_parent()

    parent_id = (
        None
        if parent_item is None
        else int(parent_item.get_id())
    )

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "direction": direction,
        "parent_id": parent_id,
        "position": int(
            image.get_item_position(
                layer
            )
        ),
    }


def gimp_move_layer_to_parent(
    image_id,
    layer_id,
    parent_id,
):
    """
    MAIN THREAD ONLY.

    Move a layer or group layer into a target group, or to the image's
    top-level layer stack when parent_id is None / negative.

    The item is placed at position 0 in the target level. Fine reordering can
    then be done with REORDER_LAYER.
    """

    image, layer = (
        _gimp_resolve_image_layer(
            image_id,
            layer_id,
        )
    )

    parent = (
        _gimp_resolve_group_parent(
            image,
            parent_id,
        )
    )

    if (
        parent is not None
        and int(parent.get_id()) == int(layer.get_id())
    ):
        raise ValueError(
            "A layer group cannot be moved into itself"
        )

    success = image.reorder_item(
        layer,
        parent,
        0,
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not move layer ID {layer_id}"
        )

    image.set_selected_layers(
        [layer]
    )

    Gimp.displays_flush()

    actual_parent_item = layer.get_parent()

    actual_parent_id = (
        None
        if actual_parent_item is None
        else int(actual_parent_item.get_id())
    )

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "parent_id": actual_parent_id,
        "position": int(
            image.get_item_position(
                layer
            )
        ),
    }



# -----------------------------------------------------------------------------
# Remaining layer-feature helpers
# -----------------------------------------------------------------------------

def gimp_create_group(
    image_id,
    name,
):
    """
    MAIN THREAD ONLY.

    Create a group at the same hierarchy level as the selected layer,
    immediately above it, and make the group active.
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    name = str(
        name or "Layer Group"
    ).strip()

    if not name:
        name = "Layer Group"

    parent = None
    position = 0

    selected_layers = list(
        image.get_selected_layers()
    )

    if selected_layers:

        selected = selected_layers[0]

        parent = (
            _gimp_get_layer_parent_as_layer(
                selected
            )
        )

        position = int(
            image.get_item_position(
                selected
            )
        )

    group = Gimp.GroupLayer.new(
        image,
        name,
    )

    if group is None or not group.is_valid():
        raise RuntimeError(
            "GIMP could not create the group layer"
        )

    success = image.insert_layer(
        group,
        parent,
        position,
    )

    if not success:
        raise RuntimeError(
            "GIMP could not insert the group layer"
        )

    image.set_selected_layers(
        [group]
    )

    Gimp.displays_flush()

    return {
        "image_id": image_id,
        "layer_id": int(group.get_id()),
        "name": str(group.get_name() or ""),
        "parent_id": (
            None
            if parent is None
            else int(parent.get_id())
        ),
        "position": int(
            image.get_item_position(
                group
            )
        ),
    }


def gimp_merge_layer_down(
    image_id,
    layer_id,
):
    """
    MAIN THREAD ONLY.

    Merge the requested layer with the first visible layer below it.
    The merged layer expands as necessary.
    """

    image, layer = (
        _gimp_resolve_image_layer(
            image_id,
            layer_id,
        )
    )

    source_name = str(
        layer.get_name() or ""
    )

    merged = image.merge_down(
        layer,
        Gimp.MergeType.EXPAND_AS_NECESSARY,
    )

    if merged is None or not merged.is_valid():
        raise RuntimeError(
            f"GIMP could not merge layer ID {layer_id} down. "
            "Make sure a visible layer exists below it."
        )

    image.set_selected_layers(
        [merged]
    )

    Gimp.displays_flush()

    return {
        "image_id": int(image.get_id()),
        "source_layer_id": int(layer_id),
        "source_name": source_name,
        "layer_id": int(merged.get_id()),
        "name": str(merged.get_name() or ""),
    }


def gimp_merge_visible_layers(image_id):
    """Merge all visible layers into one authoritative GIMP layer."""
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    merged = image.merge_visible_layers(Gimp.MergeType.EXPAND_AS_NECESSARY)
    if merged is None or not merged.is_valid():
        raise RuntimeError("GIMP could not merge the visible layers")
    image.set_selected_layers([merged])
    Gimp.displays_flush()
    return {
        "image_id": image_id,
        "layer_id": int(merged.get_id()),
        "name": str(merged.get_name() or "Merged"),
    }


def gimp_flatten_image(image_id):
    """Flatten all visible layers and discard hidden layers."""
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    flattened = image.flatten()
    if flattened is None or not flattened.is_valid():
        raise RuntimeError("GIMP could not flatten the image")
    image.set_selected_layers([flattened])
    Gimp.displays_flush()
    return {
        "image_id": image_id,
        "layer_id": int(flattened.get_id()),
        "name": str(flattened.get_name() or "Flattened"),
    }


def gimp_duplicate_group(image_id, layer_id):
    """Duplicate a native GIMP group and its child hierarchy."""
    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    if not layer.is_group():
        raise ValueError(f"Layer ID {layer_id} is not a GIMP group")
    result = gimp_duplicate_layer(image_id, layer_id)
    duplicate = Gimp.Layer.get_by_id(int(result["layer_id"]))
    if duplicate is None or not duplicate.is_valid() or not duplicate.is_group():
        raise RuntimeError("GIMP group duplication did not return a valid group")
    result["is_group"] = True
    return result


def gimp_set_layer_color_tag(image_id, layer_id, color_tag):
    """Set a native GIMP item color tag on a layer or group."""
    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    tag_name = str(color_tag or "NONE").upper().strip()
    if tag_name not in BLENDGIMP_COLOR_TAG_NAMES:
        raise ValueError(f"Unsupported GIMP color tag: {tag_name}")
    enum_value = getattr(Gimp.ColorTag, tag_name, None)
    if enum_value is None:
        raise ValueError(f"GIMP runtime does not expose color tag {tag_name}")
    if layer.set_color_tag(enum_value) is False:
        raise RuntimeError(f"GIMP could not set color tag for layer ID {layer_id}")
    Gimp.displays_flush()
    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "color_tag": _gimp_color_tag_name(layer.get_color_tag()),
    }



def _gimp_selection_state(image):
    """Return a compact snapshot of the authoritative GIMP selection."""
    image_id = int(image.get_id())
    width = int(image.get_width())
    height = int(image.get_height())

    try:
        empty = bool(Gimp.Selection.is_empty(image))
    except Exception:
        empty = False

    non_empty = not empty
    bounds_valid = False
    x1 = y1 = x2 = y2 = 0

    if non_empty:
        try:
            raw = Gimp.Selection.bounds(image)
            values = list(raw) if isinstance(raw, (tuple, list)) else [raw]

            # GI bindings may expose C's success return plus output args, or
            # only the output args. Accept both shapes so BlendGimp remains
            # tolerant across GIMP 3.x introspection builds.
            if len(values) >= 6:
                success = bool(values[0])
                non_empty = bool(values[1])
                x1, y1, x2, y2 = [int(v) for v in values[2:6]]
                bounds_valid = bool(success and non_empty)
            elif len(values) == 5:
                non_empty = bool(values[0])
                x1, y1, x2, y2 = [int(v) for v in values[1:5]]
                bounds_valid = bool(non_empty)
            elif len(values) == 4:
                x1, y1, x2, y2 = [int(v) for v in values]
                bounds_valid = True
        except Exception as exc:
            log(f"Selection bounds warning for image ID {image_id}: {exc}")

    if not non_empty:
        x1 = y1 = x2 = y2 = 0
        bounds_valid = True

    return {
        "image_id": image_id,
        "active": bool(non_empty),
        "bounds_valid": bool(bounds_valid),
        "x1": int(x1),
        "y1": int(y1),
        "x2": int(x2),
        "y2": int(y2),
        "image_width": width,
        "image_height": height,
    }


def _gimp_selection_outline_points(image, state=None, max_points=14000):
    """Return a compact dotted-outline point cloud for the current selection mask.

    The selection remains authoritative in GIMP.  This function samples the
    actual selection channel and emits boundary points only, so Blender can
    display fuzzy/by-color/combined/morphology selections without replacing
    their real shape with a bounding rectangle.  Sampling automatically gets
    coarser for large/complex masks to keep the UI payload bounded.
    """
    state = dict(state or _gimp_selection_state(image))
    if not bool(state.get("active", False)) or not bool(state.get("bounds_valid", False)):
        return [], 1, False

    image_width = max(1, int(state.get("image_width", image.get_width())))
    image_height = max(1, int(state.get("image_height", image.get_height())))
    x1 = max(0, min(int(state.get("x1", 0)), image_width))
    y1 = max(0, min(int(state.get("y1", 0)), image_height))
    x2 = max(x1, min(int(state.get("x2", image_width)), image_width))
    y2 = max(y1, min(int(state.get("y2", image_height)), image_height))
    width = x2 - x1
    height = y2 - y1
    if width <= 0 or height <= 0:
        return [], 1, False

    selection = image.get_selection()
    if selection is None or not selection.is_valid():
        return [], 1, False
    buffer = selection.get_buffer()
    if buffer is None:
        return [], 1, False

    rectangle = Gegl.Rectangle.new(x1, y1, width, height)
    raw = None
    last_exc = None
    for pixel_format in ("Y u8", "Y' u8"):
        try:
            raw = _blendgimp_bytes_from_gi(
                buffer.get(rectangle, 1.0, pixel_format, Gegl.AbyssPolicy.NONE)
            )
            if len(raw) == width * height:
                break
        except Exception as exc:
            last_exc = exc
            raw = None
    if raw is None or len(raw) != width * height:
        if last_exc is not None:
            log(f"Selection outline warning for image ID {int(image.get_id())}: {last_exc}")
        return [], 1, False

    # Keep Python-side contour extraction cheap enough that a broad Select by
    # Color operation cannot make the selection command appear to hang.
    # Target roughly <=300k sampled cells regardless of texture dimensions.
    sample_budget = 300000.0
    base_step = max(1, int(math.ceil(math.sqrt((float(width) * float(height)) / sample_budget))))
    max_points = max(256, int(max_points))

    def build(step):
        pts = []
        threshold = 128
        # Sample one cell per step and emit a point when that selected cell
        # touches an unselected neighbor or the image boundary.  This captures
        # disconnected islands and holes without needing ordered contours.
        for ly in range(0, height, step):
            gy = y1 + ly
            row = ly * width
            for lx in range(0, width, step):
                idx = row + lx
                if raw[idx] < threshold:
                    continue
                gx = x1 + lx
                left_selected = (lx - step >= 0 and raw[row + (lx - step)] >= threshold)
                right_selected = (lx + step < width and raw[row + (lx + step)] >= threshold)
                up_selected = (ly - step >= 0 and raw[(ly - step) * width + lx] >= threshold)
                down_selected = (ly + step < height and raw[(ly + step) * width + lx] >= threshold)
                on_image_edge = (gx <= 0 or gy <= 0 or gx + step >= image_width or gy + step >= image_height)
                if on_image_edge or not (left_selected and right_selected and up_selected and down_selected):
                    pts.extend((float(gx) + 0.5 * step, float(gy) + 0.5 * step))
                    if len(pts) // 2 > max_points:
                        return pts, True
        return pts, False

    step = base_step
    points, truncated = build(step)
    # If a noisy color selection creates too many boundary points, increase the
    # sampling stride and rescan so points remain distributed across the whole
    # image instead of truncating only the bottom/right of the contour.
    while truncated and step < 32:
        step *= 2
        points, truncated = build(step)
    if truncated:
        points = points[: max_points * 2]
    return points, step, truncated


def _gimp_attach_selection_outline(image, result):
    """Best-effort contour metadata; never fail the underlying selection.

    Selection creation/modification is authoritative in GIMP.  A contour is
    only Blender UI metadata, so contour extraction errors or expensive masks
    must not turn a successful Select by Color/Fuzzy operation into an IPC
    failure.
    """
    try:
        points, stride, truncated = _gimp_selection_outline_points(image, result)
        result["outline_points"] = points
        result["outline_stride"] = int(stride)
        result["outline_truncated"] = bool(truncated)
        if bool(result.get("active", False)) and points:
            result["shape"] = "MASK"
    except Exception as exc:
        result["outline_points"] = []
        result["outline_stride"] = 0
        result["outline_truncated"] = False
        log(f"Selection outline metadata skipped for image ID {int(image.get_id())}: {exc}")
    return result


def gimp_get_selection_state(image_id):
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    result = _gimp_selection_state(image)
    if bool(result.get("active", False)):
        _gimp_attach_selection_outline(image, result)
    return result


def _gimp_clamp_selection_rect(image, x, y, width, height):
    image_width = max(1, int(image.get_width()))
    image_height = max(1, int(image.get_height()))
    x1 = max(0.0, min(float(x), float(image_width)))
    y1 = max(0.0, min(float(y), float(image_height)))
    x2 = max(0.0, min(float(x) + float(width), float(image_width)))
    y2 = max(0.0, min(float(y) + float(height), float(image_height)))
    left = min(x1, x2)
    top = min(y1, y2)
    right = max(x1, x2)
    bottom = max(y1, y2)
    if right - left < 1.0 or bottom - top < 1.0:
        raise ValueError("Selection must be at least one pixel wide and high")
    return left, top, right - left, bottom - top



def _gimp_channel_op(operation):
    """Resolve a BlendGimp selection-combine name to Gimp.ChannelOps."""
    name = str(operation or "REPLACE").upper().strip()
    if name not in {"REPLACE", "ADD", "SUBTRACT", "INTERSECT"}:
        raise ValueError(f"Unsupported selection operation: {name}")
    value = getattr(Gimp.ChannelOps, name, None)
    if value is None:
        raise RuntimeError(f"GIMP runtime does not expose ChannelOps.{name}")
    return value, name


def _gimp_selection_drawable(image_id, layer_id):
    """Resolve a raster layer/mask usable by fuzzy and by-color selection."""
    image, layer = _gimp_resolve_image_layer(int(image_id), int(layer_id))
    if layer.is_group():
        raise ValueError("Color-based selection requires a raster layer, not a group")
    drawable, target_kind = _gimp_layer_edit_drawable(layer)
    return image, layer, drawable, target_kind


def _gimp_selection_context(threshold, sample_merged, sample_transparent):
    """Push and fully configure an isolated GIMP color-selection context.

    GIMP's Select by Color result depends on the current sample criterion as
    well as threshold/merged/transparent state.  Leaving the criterion at the
    user's previous GIMP value made BlendGimp appear intermittent, so the
    bridge now pins the same deterministic COMPOSITE criterion every time.
    """
    pushed = bool(Gimp.context_push())
    if not pushed:
        raise RuntimeError("GIMP could not isolate the selection context")
    try:
        Gimp.context_set_antialias(True)
    except Exception:
        pass
    try:
        Gimp.context_set_feather(False)
    except Exception:
        pass
    criterion_enum = getattr(Gimp, "SelectCriterion", None)
    composite = getattr(criterion_enum, "COMPOSITE", None) if criterion_enum is not None else None
    if composite is not None:
        try:
            if Gimp.context_set_sample_criterion(composite) is False:
                raise RuntimeError("GIMP could not set the selection sample criterion")
        except AttributeError:
            # Older 3.x GI builds may omit this setter; keep compatibility.
            pass
    if Gimp.context_set_sample_threshold(max(0.0, min(1.0, float(threshold)))) is False:
        Gimp.context_pop()
        raise RuntimeError("GIMP could not set the selection threshold")
    if Gimp.context_set_sample_merged(bool(sample_merged)) is False:
        Gimp.context_pop()
        raise RuntimeError("GIMP could not set sample-merged selection state")
    if Gimp.context_set_sample_transparent(bool(sample_transparent)) is False:
        Gimp.context_pop()
        raise RuntimeError("GIMP could not set transparent sampling state")
    return True


def _gimp_drawable_color_at(drawable, x, y):
    """Read one drawable pixel as a Gegl.Color without touching GIMP state."""
    width = int(drawable.get_width())
    height = int(drawable.get_height())
    ix = max(0, min(int(round(float(x))), max(0, width - 1)))
    iy = max(0, min(int(round(float(y))), max(0, height - 1)))
    buffer = drawable.get_buffer()
    if buffer is None:
        raise RuntimeError("GIMP did not return a buffer for color sampling")
    rect = Gegl.Rectangle.new(ix, iy, 1, 1)
    raw = _blendgimp_bytes_from_gi(
        buffer.get(rect, 1.0, "R'G'B'A u8", Gegl.AbyssPolicy.NONE)
    )
    if len(raw) < 4:
        raise RuntimeError("GIMP returned an incomplete color sample")
    r, g, b, a = [int(v) for v in raw[:4]]
    return Gegl.Color.new(
        f"rgba({r / 255.0:.9f},{g / 255.0:.9f},{b / 255.0:.9f},{a / 255.0:.9f})"
    )


def _gimp_pick_color_native(image, drawable, x, y, sample_merged=False):
    """Sample through GIMP's own color pipeline for Select by Color.

    Using Image.pick_color() keeps the sampled Gegl.Color in the exact same
    color-management path that Image.select_color() expects.  This avoids
    subtle mismatches caused by reconstructing an sRGB u8 color manually from
    the drawable buffer.
    """
    raw = image.pick_color(
        [drawable], float(x), float(y), bool(sample_merged), False, 0.0
    )
    values = list(raw) if isinstance(raw, (tuple, list)) else [raw]
    if values and isinstance(values[0], bool) and not values[0]:
        raise RuntimeError("GIMP could not sample a color at that point")
    for value in reversed(values):
        if isinstance(value, Gegl.Color) or value.__class__.__name__.lower().endswith("color"):
            return value
    raise RuntimeError("GIMP pick_color did not return a color")


def _gimp_pick_merged_color(image, drawable, x, y):
    return _gimp_pick_color_native(image, drawable, x, y, sample_merged=True)


def gimp_select_rectangle(image_id, x, y, width, height, operation="REPLACE"):
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    channel_op, op_name = _gimp_channel_op(operation)
    x, y, width, height = _gimp_clamp_selection_rect(image, x, y, width, height)
    ok = image.select_rectangle(channel_op, x, y, width, height)
    if ok is False:
        raise RuntimeError("GIMP could not create the rectangular selection")
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result["shape"] = "RECTANGLE" if op_name == "REPLACE" else "BOUNDS"
    result["operation"] = op_name
    if op_name != "REPLACE":
        _gimp_attach_selection_outline(image, result)
    return result


def gimp_select_ellipse(image_id, x, y, width, height, operation="REPLACE"):
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    channel_op, op_name = _gimp_channel_op(operation)
    x, y, width, height = _gimp_clamp_selection_rect(image, x, y, width, height)
    ok = image.select_ellipse(channel_op, x, y, width, height)
    if ok is False:
        raise RuntimeError("GIMP could not create the elliptical selection")
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result["shape"] = "ELLIPSE" if op_name == "REPLACE" else "BOUNDS"
    result["operation"] = op_name
    if op_name != "REPLACE":
        _gimp_attach_selection_outline(image, result)
    return result


def gimp_select_polygon(image_id, points, operation="REPLACE"):
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    if not isinstance(points, (list, tuple)):
        raise ValueError("Free Select points must be a list")
    flat = [float(v) for v in points]
    if len(flat) < 6 or len(flat) % 2:
        raise ValueError("Free Select requires at least three x/y points")
    if len(flat) > 8192:
        raise ValueError("Free Select contains too many points")
    channel_op, op_name = _gimp_channel_op(operation)
    ok = image.select_polygon(channel_op, flat)
    if ok is False:
        raise RuntimeError("GIMP could not create the free selection")
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result["shape"] = "FREE" if op_name == "REPLACE" else "BOUNDS"
    result["operation"] = op_name
    result["points"] = flat if op_name == "REPLACE" else []
    if op_name != "REPLACE":
        _gimp_attach_selection_outline(image, result)
    return result


def gimp_select_fuzzy(
    image_id,
    layer_id,
    x,
    y,
    operation="REPLACE",
    threshold=0.15,
    sample_merged=False,
    sample_transparent=True,
):
    image, layer, drawable, target_kind = _gimp_selection_drawable(image_id, layer_id)
    channel_op, op_name = _gimp_channel_op(operation)
    pushed = _gimp_selection_context(threshold, sample_merged, sample_transparent)
    try:
        px = float(x)
        py = float(y)
        if not bool(sample_merged):
            offx, offy = _blendgimp_layer_offsets(layer)
            px -= float(offx)
            py -= float(offy)
        ok = image.select_contiguous_color(channel_op, drawable, px, py)
        if ok is False:
            raise RuntimeError("GIMP could not create the fuzzy selection")
    finally:
        if pushed:
            Gimp.context_pop()
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result.update({
        "shape": "BOUNDS",
        "operation": op_name,
        "target_kind": target_kind,
        "threshold": float(threshold),
        "sample_merged": bool(sample_merged),
    })
    _gimp_attach_selection_outline(image, result)
    return result


def gimp_select_by_color(
    image_id,
    layer_id,
    x,
    y,
    operation="REPLACE",
    threshold=0.15,
    sample_merged=False,
    sample_transparent=True,
):
    image, layer, drawable, target_kind = _gimp_selection_drawable(image_id, layer_id)
    channel_op, op_name = _gimp_channel_op(operation)
    pushed = _gimp_selection_context(threshold, sample_merged, sample_transparent)
    sample_source = "gimp-pick-color"
    retry_used = False
    try:
        try:
            color = _gimp_pick_color_native(
                image, drawable, x, y, sample_merged=bool(sample_merged)
            )
        except Exception:
            # GIMP intentionally rejects pick_color() on fully transparent
            # pixels.  When transparent sampling is enabled, preserve expected
            # Select by Color behavior with an exact drawable-buffer fallback.
            if bool(sample_merged) or not bool(sample_transparent):
                raise
            offx, offy = _blendgimp_layer_offsets(layer)
            color = _gimp_drawable_color_at(drawable, float(x) - offx, float(y) - offy)
            sample_source = "drawable-buffer-transparent-fallback"
        ok = image.select_color(channel_op, drawable, color)
        if ok is False:
            raise RuntimeError("GIMP could not create the Select by Color selection")

        # If a replace operation unexpectedly produces an empty selection,
        # retry once with the exact drawable pixel.  This is a guarded fallback
        # for GI/color-profile edge cases and never changes combine semantics.
        if op_name == "REPLACE":
            probe = _gimp_selection_state(image)
            if not bool(probe.get("active", False)) and not bool(sample_merged):
                offx, offy = _blendgimp_layer_offsets(layer)
                fallback = _gimp_drawable_color_at(drawable, float(x) - offx, float(y) - offy)
                ok = image.select_color(channel_op, drawable, fallback)
                if ok is False:
                    raise RuntimeError("GIMP could not retry the Select by Color selection")
                sample_source = "drawable-buffer-retry"
                retry_used = True
    finally:
        if pushed:
            Gimp.context_pop()
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result.update({
        "shape": "BOUNDS",
        "operation": op_name,
        "target_kind": target_kind,
        "threshold": float(threshold),
        "sample_merged": bool(sample_merged),
        "sample_source": sample_source,
        "sample_retry": bool(retry_used),
    })
    _gimp_attach_selection_outline(image, result)
    return result


def gimp_select_all(image_id):
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    ok = Gimp.Selection.all(image)
    if ok is False:
        raise RuntimeError("GIMP could not select the entire image")
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result["shape"] = "ALL"
    return result


def gimp_select_none(image_id):
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    ok = Gimp.Selection.none(image)
    if ok is False:
        raise RuntimeError("GIMP could not clear the selection")
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result["shape"] = "NONE"
    return result


def gimp_select_invert(image_id):
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    ok = Gimp.Selection.invert(image)
    if ok is False:
        raise RuntimeError("GIMP could not invert the selection")
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result["shape"] = "BOUNDS"
    _gimp_attach_selection_outline(image, result)
    return result


def gimp_modify_selection(image_id, action, radius):
    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)
    if image is None or not image.is_valid():
        raise ValueError(f"Image ID {image_id} is not a valid open GIMP image")
    if Gimp.Selection.is_empty(image):
        raise ValueError("There is no active GIMP selection to modify")
    action = str(action or "").upper().strip()
    amount = max(0.0, float(radius))
    if action == "GROW":
        ok = Gimp.Selection.grow(image, max(1, int(round(amount))))
    elif action == "SHRINK":
        ok = Gimp.Selection.shrink(image, max(1, int(round(amount))))
    elif action == "FEATHER":
        ok = Gimp.Selection.feather(image, max(0.1, amount))
    elif action == "BORDER":
        ok = Gimp.Selection.border(image, max(1, int(round(amount))))
    else:
        raise ValueError(f"Unsupported selection modifier: {action}")
    if ok is False:
        raise RuntimeError(f"GIMP could not {action.lower()} the selection")
    Gimp.displays_flush()
    result = _gimp_selection_state(image)
    result.update({"shape": "BOUNDS", "modifier": action, "radius": amount})
    _gimp_attach_selection_outline(image, result)
    return result

def gimp_set_layer_lock(
    image_id,
    layer_id,
    lock_type,
    locked,
):
    """
    MAIN THREAD ONLY.

    Set content, position, or alpha lock state.
    """

    image, layer = (
        _gimp_resolve_image_layer(
            image_id,
            layer_id,
        )
    )

    lock_type = str(
        lock_type or ""
    ).upper()

    locked = bool(
        locked
    )

    if lock_type == "CONTENT":

        success = layer.set_lock_content(
            locked
        )

        actual = bool(
            layer.get_lock_content()
        )

    elif lock_type == "POSITION":

        success = layer.set_lock_position(
            locked
        )

        actual = bool(
            layer.get_lock_position()
        )

    elif lock_type == "VISIBILITY":

        success = layer.set_lock_visibility(
            locked
        )

        actual = bool(
            layer.get_lock_visibility()
        )

    elif lock_type == "ALPHA":

        success = layer.set_lock_alpha(
            locked
        )

        actual = bool(
            layer.get_lock_alpha()
        )

    else:

        raise ValueError(
            "lock_type must be CONTENT, POSITION, VISIBILITY, or ALPHA"
        )

    if not success:
        raise RuntimeError(
            f"GIMP could not set {lock_type.lower()} lock "
            f"for layer ID {layer_id}"
        )

    Gimp.displays_flush()

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "lock_type": lock_type,
        "locked": actual,
    }


def gimp_set_layer_mode(
    image_id,
    layer_id,
    mode_name,
):
    """
    MAIN THREAD ONLY.

    Change a layer's GIMP blend/combination mode.
    """

    image, layer = (
        _gimp_resolve_image_layer(
            image_id,
            layer_id,
        )
    )

    mode_name = str(
        mode_name or ""
    ).upper()

    if mode_name not in BLENDGIMP_LAYER_MODE_NAMES:
        raise ValueError(
            f"Unsupported GIMP layer mode: {mode_name}"
        )

    mode = getattr(
        Gimp.LayerMode,
        mode_name,
        None
    )

    if mode is None:
        raise ValueError(
            f"GIMP runtime does not expose layer mode {mode_name}"
        )

    success = layer.set_mode(
        mode
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not set blend mode {mode_name} "
            f"for layer ID {layer_id}"
        )

    Gimp.displays_flush()

    actual_mode = layer.get_mode()

    return {
        "image_id": int(image.get_id()),
        "layer_id": int(layer.get_id()),
        "mode": _gimp_layer_mode_name(
            actual_mode
        ),
        "mode_value": int(
            actual_mode
        ),
    }



def _blendgimp_find_named_raster_layer(
    image,
    name
):
    target_name = str(
        name
    )

    def search_layers(
        layers
    ):
        for item in layers:
            layer = Gimp.Layer.get_by_id(
                int(
                    item.get_id()
                )
            )

            if layer is None or not layer.is_valid():
                continue

            if (
                not layer.is_group()
                and str(
                    layer.get_name()
                    or ""
                ) == target_name
            ):
                return layer

            if layer.is_group():
                found = search_layers(
                    layer.get_children()
                )

                if found is not None:
                    return found

        return None

    return search_layers(
        image.get_layers()
    )


def gimp_ensure_blendgimp_paint_layer(
    image_id,
    name=BLENDGIMP_PAINT_LAYER_NAME
):
    """
    MAIN THREAD ONLY.

    Return a persistent full-image raster layer dedicated to paint originating
    from Blender's 3D Texture Paint workflow. Create it at the top level when
    it does not exist.
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    name = str(
        name
        or BLENDGIMP_PAINT_LAYER_NAME
    ).strip()

    if not name:
        name = BLENDGIMP_PAINT_LAYER_NAME

    layer = _blendgimp_find_named_raster_layer(
        image,
        name
    )

    created = False

    if layer is None:

        layer = Gimp.Layer.new(
            image,
            name,
            int(
                image.get_width()
            ),
            int(
                image.get_height()
            ),
            _gimp_new_layer_type_for_image(
                image
            ),
            100.0,
            image.get_default_new_layer_mode(),
        )

        if layer is None or not layer.is_valid():
            raise RuntimeError(
                "GIMP could not create the BlendGimp paint layer"
            )

        success = image.insert_layer(
            layer,
            None,
            0,
        )

        if not success:
            raise RuntimeError(
                "GIMP could not insert the BlendGimp paint layer"
            )

        created = True

    try:
        layer.set_visible(
            True
        )
    except Exception:
        pass

    try:
        layer.set_opacity(
            100.0
        )
    except Exception:
        pass

    Gimp.displays_flush()

    return {
        "image_id": image_id,
        "layer_id": int(
            layer.get_id()
        ),
        "name": str(
            layer.get_name()
            or name
        ),
        "created": bool(
            created
        ),
        "width": int(
            layer.get_width()
        ),
        "height": int(
            layer.get_height()
        ),
    }


def _blendgimp_accept_blender_originated_write(
    image_id
):
    """
    Re-baseline GIMP -> Blender state after a Blender-originated write.

    GIMP 3.2.4 may update the composite thumbnail cache slightly after the
    drawable write itself. A pure thumbnail fingerprint can therefore change
    on the next IMAGE_STATE poll even though the final composite pixels are
    exactly the pixels BlendGimp just accepted from Blender.

    Store the authoritative full-composite hash for a short verification
    window. IMAGE_STATE can then suppress only self-originated cache settling,
    while a real GIMP edit (different composite hash) still passes through.
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        return

    try:
        width, height, composite_pixels = (
            _gimp_get_raw_composite_rgba(
                image
            )
        )

        _blendgimp_store_pixel_snapshot(
            image_id,
            width,
            height,
            composite_pixels
        )

        composite_sha256 = hashlib.sha256(
            composite_pixels
        ).hexdigest()

        fingerprint_info = (
            _gimp_visual_fingerprint(
                image
            )
        )

        tracker = (
            _blendgimp_ensure_damage_tracker(
                image
            )
        )

        previous_state = (
            BLENDGIMP_IMAGE_VISUAL_STATE.get(
                image_id
            )
            or {}
        )

        BLENDGIMP_IMAGE_VISUAL_STATE[
            image_id
        ] = {
            "fingerprint": fingerprint_info[
                "fingerprint"
            ],
            "native_revision": int(
                tracker.get(
                    "revision",
                    1
                )
            ),
            "revision": int(
                previous_state.get(
                    "revision",
                    1
                )
            ),
        }

        BLENDGIMP_ECHO_SUPPRESSION[
            image_id
        ] = {
            "composite_sha256": composite_sha256,
            "deadline": (
                time.monotonic()
                + BLENDGIMP_ECHO_SUPPRESSION_SECONDS
            ),
        }

        _blendgimp_clear_pending_damage(
            image_id
        )

        return {
            "width": int(width),
            "height": int(height),
            "pixels": composite_pixels,
            "sync_token": _blendgimp_composite_token(image_id),
        }

    except Exception as exc:
        log(
            "Warning: could not establish Blender-originated "
            f"echo suppression for image ID {image_id}: {exc}"
        )
        return None


def _blendgimp_filter_self_originated_state_change(
    image,
    image_id,
    fingerprint,
    native_revision,
    fingerprint_changed,
    native_changed
):
    """
    Return (fingerprint_changed, native_changed, suppressed).

    Verification is only performed after a Blender-originated write and only
    when IMAGE_STATE would otherwise report a new change.
    """

    image_id = int(
        image_id
    )

    suppression = BLENDGIMP_ECHO_SUPPRESSION.get(
        image_id
    )

    if suppression is None:
        return (
            fingerprint_changed,
            native_changed,
            False,
        )

    now = time.monotonic()

    if now > float(
        suppression.get(
            "deadline",
            0.0
        )
    ):
        BLENDGIMP_ECHO_SUPPRESSION.pop(
            image_id,
            None
        )

        return (
            fingerprint_changed,
            native_changed,
            False,
        )

    # If nothing appears to have changed, the thumbnail/native state has
    # settled to our accepted baseline; suppression is no longer needed.
    if not fingerprint_changed and not native_changed:
        BLENDGIMP_ECHO_SUPPRESSION.pop(
            image_id,
            None
        )

        return (
            False,
            False,
            False,
        )

    try:
        width, height, current_pixels = (
            _gimp_get_raw_composite_rgba(
                image
            )
        )

        current_sha256 = hashlib.sha256(
            current_pixels
        ).hexdigest()

        expected_sha256 = str(
            suppression.get(
                "composite_sha256",
                ""
            )
        )

        if current_sha256 == expected_sha256:
            # The final composite is unchanged. Only the thumbnail/native
            # observation lagged behind. Accept the new observer state without
            # advancing BlendGimp's external revision.
            _blendgimp_store_pixel_snapshot(
                image_id,
                width,
                height,
                current_pixels
            )

            previous_state = (
                BLENDGIMP_IMAGE_VISUAL_STATE.get(
                    image_id
                )
                or {}
            )

            BLENDGIMP_IMAGE_VISUAL_STATE[
                image_id
            ] = {
                "fingerprint": fingerprint,
                "native_revision": int(
                    native_revision
                ),
                "revision": int(
                    previous_state.get(
                        "revision",
                        1
                    )
                ),
            }

            _blendgimp_clear_pending_damage(
                image_id
            )

            return (
                False,
                False,
                True,
            )

        # Composite pixels differ from the Blender-originated accepted state:
        # this is a real new GIMP-side edit, so stop suppressing immediately.
        BLENDGIMP_ECHO_SUPPRESSION.pop(
            image_id,
            None
        )

        return (
            fingerprint_changed,
            native_changed,
            False,
        )

    except Exception as exc:
        log(
            "Echo-suppression verification failed for "
            f"image ID {image_id}: {exc}"
        )

        BLENDGIMP_ECHO_SUPPRESSION.pop(
            image_id,
            None
        )

        return (
            fingerprint_changed,
            native_changed,
            False,
        )


# -----------------------------------------------------------------------------
# Direct Blender 3D stroke -> GIMP brush engine
# -----------------------------------------------------------------------------

def _gimp_foreground_rgba():
    """MAIN THREAD ONLY. Return GIMP foreground as normalized RGBA."""

    foreground = Gimp.context_get_foreground()

    if foreground is None:
        return None

    try:
        values = list(foreground.get_rgba())
    except Exception:
        return None

    # PyGObject normally exposes Gegl.Color.get_rgba() as four out values.
    # Accept a leading success boolean as well for binding-version tolerance.
    if len(values) == 5 and isinstance(values[0], bool):
        values = values[1:]

    if len(values) != 4:
        return None

    return [
        max(0.0, min(1.0, float(value)))
        for value in values
    ]


def _gimp_color_rgba(color):
    """MAIN THREAD ONLY. Normalize a Gegl.Color to an RGBA list."""

    if color is None:
        return None

    try:
        values = list(color.get_rgba())
    except Exception:
        return None

    if len(values) == 5 and isinstance(values[0], bool):
        values = values[1:]

    if len(values) != 4:
        return None

    return [
        max(0.0, min(1.0, float(value)))
        for value in values
    ]


def _gimp_make_color(rgba):
    values = list(rgba)

    if len(values) not in {3, 4}:
        raise ValueError("rgba must contain 3 or 4 components")

    values = [
        max(0.0, min(1.0, float(value)))
        for value in values
    ]

    if len(values) == 3:
        values.append(1.0)

    color = Gegl.Color.new(
        "rgba("
        f"{values[0]:.9f},"
        f"{values[1]:.9f},"
        f"{values[2]:.9f},"
        f"{values[3]:.9f})"
    )

    if color is None:
        raise RuntimeError("GIMP could not construct the requested color")

    return color, values


def gimp_set_foreground_color(rgba):
    """MAIN THREAD ONLY. Set the GIMP foreground from normalized RGBA."""

    foreground, values = _gimp_make_color(rgba)

    if not Gimp.context_set_foreground(foreground):
        raise RuntimeError("GIMP could not set the foreground color")

    return {
        "foreground_color": values,
    }


def gimp_set_background_color(rgba):
    """MAIN THREAD ONLY. Set the GIMP background from normalized RGBA."""

    background, values = _gimp_make_color(rgba)

    if not Gimp.context_set_background(background):
        raise RuntimeError("GIMP could not set the background color")

    return {
        "background_color": values,
    }


def gimp_list_brushes():
    """MAIN THREAD ONLY. Return installed GIMP brush names."""

    try:
        brushes = Gimp.brushes_get_list(None)
    except TypeError:
        brushes = Gimp.brushes_get_list("")

    names = []
    for brush in brushes or []:
        try:
            name = str(brush.get_name() or "")
        except Exception:
            name = str(brush or "")
        if name:
            names.append(name)

    return {
        "brushes": sorted(set(names), key=str.casefold),
    }


def gimp_list_dynamics():
    """MAIN THREAD ONLY. Return installed paint dynamics and current activation state."""

    try:
        dynamics = Gimp.dynamics_get_name_list(None)
    except TypeError:
        dynamics = Gimp.dynamics_get_name_list("")

    names = [str(name) for name in (dynamics or []) if str(name)]
    try:
        active = str(Gimp.context_get_dynamics_name() or "")
    except Exception:
        active = ""
    try:
        enabled = bool(Gimp.context_are_dynamics_enabled())
    except Exception:
        enabled = False

    return {
        "dynamics": sorted(set(names), key=str.casefold),
        "active_dynamics": active,
        "enabled": enabled,
    }


def gimp_set_dynamics(name):
    """MAIN THREAD ONLY. Set the active GIMP paint dynamics resource."""
    name = str(name or "").strip()
    if not name:
        raise ValueError("Dynamics name is required")
    if not Gimp.context_set_dynamics_name(name):
        raise RuntimeError(f"GIMP could not activate dynamics: {name}")
    return gimp_get_brush_state()


def gimp_set_dynamics_enabled(enabled):
    """MAIN THREAD ONLY. Enable or disable the active GIMP paint dynamics."""
    enabled = bool(enabled)
    if Gimp.context_enable_dynamics(enabled) is False:
        raise RuntimeError(
            "GIMP could not " + ("enable" if enabled else "disable") + " paint dynamics"
        )
    return gimp_get_brush_state()


def gimp_get_brush_state():
    """
    MAIN THREAD ONLY.

    Return the shared GIMP paint context used by BlendGimp 2D and 3D painting.
    """

    brush = Gimp.context_get_brush()
    brush_name = ""

    if brush is not None:
        try:
            brush_name = str(brush.get_name() or "")
        except Exception:
            brush_name = str(brush)

    try:
        dynamics_name = str(Gimp.context_get_dynamics_name() or "")
    except Exception:
        dynamics_name = ""

    try:
        dynamics_enabled = bool(Gimp.context_are_dynamics_enabled())
    except Exception:
        dynamics_enabled = False

    try:
        emulate_dynamics = bool(Gimp.context_get_emulate_brush_dynamics())
    except Exception:
        emulate_dynamics = False

    try:
        background_color = _gimp_color_rgba(Gimp.context_get_background())
    except Exception:
        background_color = None

    def safe_float(getter, default):
        try:
            return float(getter())
        except Exception:
            return float(default)

    return {
        "brush_name": brush_name,
        "brush_size": safe_float(Gimp.context_get_brush_size, 20.0),
        "brush_opacity": safe_float(Gimp.context_get_opacity, 100.0),
        "brush_spacing": safe_float(Gimp.context_get_brush_spacing, 0.10),
        "brush_hardness": safe_float(Gimp.context_get_brush_hardness, 0.50),
        "brush_angle": safe_float(Gimp.context_get_brush_angle, 0.0),
        "brush_aspect_ratio": safe_float(Gimp.context_get_brush_aspect_ratio, 0.0),
        "paint_method": str(Gimp.context_get_paint_method() or ""),
        "dynamics_name": dynamics_name,
        "dynamics_enabled": dynamics_enabled,
        "emulate_dynamics": emulate_dynamics,
        "foreground_color": _gimp_foreground_rgba(),
        "background_color": background_color,
    }


def _gimp_brush_info_tuple(brush):
    """Return best-effort native brush metadata across GI tuple variants."""
    try:
        result = brush.get_info()
    except Exception:
        return {"width": 0, "height": 0, "mask_bpp": 0, "color_bpp": 0}

    values = list(result) if isinstance(result, (tuple, list)) else []
    if values and isinstance(values[0], bool):
        values = values[1:] if values[0] else []
    if len(values) >= 4:
        try:
            return {
                "width": int(values[0]),
                "height": int(values[1]),
                "mask_bpp": int(values[2]),
                "color_bpp": int(values[3]),
            }
        except Exception:
            pass
    return {"width": 0, "height": 0, "mask_bpp": 0, "color_bpp": 0}


def gimp_get_brush_preview(max_size=256):
    """MAIN THREAD ONLY. Return the active GIMP brush's real alpha mask.

    BlendGimp deliberately transports only a compact display mask here.  GIMP
    remains authoritative for the real stroke.  The mask is enough for Blender
    to show the actual star/splatter/textured silhouette immediately while the
    authoritative GIMP pixels stream back in the background.
    """
    brush = Gimp.context_get_brush()
    if brush is None:
        raise RuntimeError("GIMP has no active brush")

    try:
        brush_name = str(brush.get_name() or "")
    except Exception:
        brush_name = str(brush)

    max_size = max(32, min(512, int(max_size or 256)))

    # GIMP 3.2.4 documents the Babl format as optional at the C API level,
    # but PyGObject's generated Brush.get_mask() binding rejects None for
    # argument 3.  Pass an explicit single-channel 8-bit Babl format so the
    # request works reliably in the bundled Windows Python runtime.
    mask_format = Babl.format("Y u8")
    if mask_format is None:
        raise RuntimeError("Babl could not create Y u8 brush-mask format")
    mask_buffer = brush.get_mask(max_size, max_size, mask_format)
    if mask_buffer is None:
        raise RuntimeError(f"GIMP did not return a mask for brush: {brush_name}")

    extent = None
    try:
        extent = mask_buffer.get_extent()
    except Exception:
        extent = None

    info = _gimp_brush_info_tuple(brush)
    if extent is not None:
        x = int(getattr(extent, "x", 0))
        y = int(getattr(extent, "y", 0))
        width = int(getattr(extent, "width", 0))
        height = int(getattr(extent, "height", 0))
    else:
        native_w = max(1, int(info.get("width", 1) or 1))
        native_h = max(1, int(info.get("height", 1) or 1))
        scale = min(1.0, float(max_size) / native_w, float(max_size) / native_h)
        x = 0
        y = 0
        width = max(1, int(round(native_w * scale)))
        height = max(1, int(round(native_h * scale)))

    if width <= 0 or height <= 0:
        raise RuntimeError(f"GIMP returned an empty mask for brush: {brush_name}")

    rect = Gegl.Rectangle.new(x, y, width, height)
    raw = None
    last_exc = None
    for pixel_format in ("Y u8", "Y' u8"):
        try:
            candidate = _blendgimp_bytes_from_gi(
                mask_buffer.get(rect, 1.0, pixel_format, Gegl.AbyssPolicy.NONE)
            )
            if len(candidate) == width * height:
                raw = candidate
                break
        except Exception as exc:
            last_exc = exc

    if raw is None:
        if last_exc is not None:
            raise RuntimeError(f"Could not read GIMP brush mask: {last_exc}")
        raise RuntimeError(
            f"Unexpected GIMP brush mask byte count for {brush_name}: expected {width * height}"
        )

    brush_id = ""
    try:
        brush_id = str(brush.get_id() or "")
    except Exception:
        pass

    return {
        "brush_name": brush_name,
        "brush_id": brush_id,
        "preview_width": width,
        "preview_height": height,
        "native_width": int(info.get("width", 0) or 0),
        "native_height": int(info.get("height", 0) or 0),
        "mask_bpp": int(info.get("mask_bpp", 0) or 0),
        "color_bpp": int(info.get("color_bpp", 0) or 0),
        "mask_b64": base64.b64encode(raw).decode("ascii"),
        "mask_sha256": hashlib.sha256(raw).hexdigest(),
    }


def gimp_set_brush_state(state):
    """MAIN THREAD ONLY. Update any supplied fields in the shared GIMP paint context."""

    if not isinstance(state, dict):
        raise ValueError("brush state must be an object")

    brush_name = str(state.get("brush_name", "") or "").strip()
    if brush_name:
        brush = Gimp.Brush.get_by_name(brush_name)
        if brush is None:
            raise ValueError(f"GIMP brush not found: {brush_name}")
        if not Gimp.context_set_brush(brush):
            raise RuntimeError(f"GIMP could not activate brush: {brush_name}")

    setters = (
        ("brush_size", Gimp.context_set_brush_size, float),
        ("brush_opacity", Gimp.context_set_opacity, float),
        ("brush_spacing", Gimp.context_set_brush_spacing, float),
        ("brush_hardness", Gimp.context_set_brush_hardness, float),
        ("brush_angle", Gimp.context_set_brush_angle, float),
        ("brush_aspect_ratio", Gimp.context_set_brush_aspect_ratio, float),
    )

    for key, setter, caster in setters:
        if key not in state or state.get(key) is None:
            continue
        value = caster(state[key])
        if setter(value) is False:
            raise RuntimeError(f"GIMP could not set {key}")

    if state.get("foreground_color") is not None:
        gimp_set_foreground_color(state["foreground_color"])

    if state.get("background_color") is not None:
        gimp_set_background_color(state["background_color"])

    dynamics_name = str(state.get("dynamics_name", "") or "").strip()
    if dynamics_name:
        if not Gimp.context_set_dynamics_name(dynamics_name):
            raise RuntimeError(f"GIMP could not activate dynamics: {dynamics_name}")

    if state.get("dynamics_enabled") is not None:
        enabled = bool(state.get("dynamics_enabled"))
        if Gimp.context_enable_dynamics(enabled) is False:
            raise RuntimeError(
                "GIMP could not " + ("enable" if enabled else "disable") + " paint dynamics"
            )

    return gimp_get_brush_state()


BLENDGIMP_FILL_TYPES = {
    "FOREGROUND": Gimp.FillType.FOREGROUND,
    "BACKGROUND": Gimp.FillType.BACKGROUND,
}


def gimp_bucket_fill(
    image_id,
    layer_id,
    x,
    y,
    fill_type="FOREGROUND",
):
    """MAIN THREAD ONLY. Seed-fill the selected raster layer at image coordinates."""

    image_id = int(image_id)
    layer_id = int(layer_id)
    image_x = float(x)
    image_y = float(y)
    fill_key = str(fill_type or "FOREGROUND").upper().strip()

    if fill_key not in BLENDGIMP_FILL_TYPES:
        raise ValueError(f"Unsupported BlendGimp fill type: {fill_key}")

    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    if layer.is_group():
        raise ValueError("GIMP Fill requires a raster layer")
    drawable, target_kind = _gimp_layer_edit_drawable(layer)

    image_width = int(image.get_width())
    image_height = int(image.get_height())
    if image_x < 0.0 or image_y < 0.0 or image_x >= image_width or image_y >= image_height:
        raise ValueError(
            f"Fill coordinate ({image_x:.1f}, {image_y:.1f}) is outside image "
            f"{image_width}x{image_height}"
        )

    # edit_bucket_fill interprets coordinates in image space when sample-merged
    # is enabled, otherwise in drawable-local space. BlendGimp always receives
    # image-space UV coordinates, so translate only when GIMP is sampling the
    # target drawable itself. This preserves the user's GIMP fill context.
    sample_merged = bool(Gimp.context_get_sample_merged())
    layer_offset_x, layer_offset_y = _blendgimp_layer_offsets(layer)
    bucket_x = image_x if sample_merged else image_x - float(layer_offset_x)
    bucket_y = image_y if sample_merged else image_y - float(layer_offset_y)

    layer_width = int(layer.get_width())
    layer_height = int(layer.get_height())
    if not sample_merged and (
        bucket_x < 0.0
        or bucket_y < 0.0
        or bucket_x >= layer_width
        or bucket_y >= layer_height
    ):
        raise ValueError(
            f"Fill coordinate is outside target layer bounds after offset: "
            f"({bucket_x:.1f}, {bucket_y:.1f}) in {layer_width}x{layer_height}"
        )

    # A newly created BlendGimp texture is commonly transparent. GIMP's seed
    # fill context may ignore transparent pixels unless sample-transparent is
    # enabled, which makes edit_bucket_fill() return success without changing
    # the drawable. Enable it only for this operation and restore the user's
    # prior GIMP context immediately afterward.
    previous_sample_transparent = None
    sample_transparent_changed = False
    try:
        previous_sample_transparent = bool(Gimp.context_get_sample_transparent())
        if not previous_sample_transparent:
            if Gimp.context_set_sample_transparent(True) is False:
                raise RuntimeError("GIMP could not enable transparent sampling for Fill")
            sample_transparent_changed = True
    except AttributeError:
        # Binding-tolerance fallback: older/introspection variants may not
        # expose the getter. The setter is available in supported GIMP 3.2.4.
        if Gimp.context_set_sample_transparent(True) is False:
            raise RuntimeError("GIMP could not enable transparent sampling for Fill")
        sample_transparent_changed = True

    if not image.undo_group_start():
        if sample_transparent_changed and previous_sample_transparent is not None:
            try:
                Gimp.context_set_sample_transparent(previous_sample_transparent)
            except Exception:
                pass
        raise RuntimeError("GIMP could not start the Fill undo group")

    try:
        success = drawable.edit_bucket_fill(
            BLENDGIMP_FILL_TYPES[fill_key],
            float(bucket_x),
            float(bucket_y),
        )
        if success is False:
            raise RuntimeError("GIMP bucket fill returned failure")
        Gimp.displays_flush()
    finally:
        try:
            image.undo_group_end()
        except Exception:
            pass
        if sample_transparent_changed:
            try:
                if previous_sample_transparent is None:
                    # We cannot know the prior state on a binding without the
                    # getter. False is GIMP's conservative/default behavior.
                    Gimp.context_set_sample_transparent(False)
                else:
                    Gimp.context_set_sample_transparent(previous_sample_transparent)
            except Exception as exc:
                log(f"BUCKET_FILL warning: could not restore sample-transparent context: {exc}")

    return {
        "image_id": image_id,
        "layer_id": layer_id,
        "x": image_x,
        "y": image_y,
        "drawable_x": float(bucket_x),
        "drawable_y": float(bucket_y),
        "fill_type": fill_key,
        "sample_merged": sample_merged,
        "sample_transparent": True,
        "layer_offset_x": int(layer_offset_x),
        "layer_offset_y": int(layer_offset_y),
        "target_kind": target_kind,
    }


BLENDGIMP_GRADIENT_TYPES = {
    "LINEAR": Gimp.GradientType.LINEAR,
    "BILINEAR": Gimp.GradientType.BILINEAR,
    "RADIAL": Gimp.GradientType.RADIAL,
    "SQUARE": Gimp.GradientType.SQUARE,
    "CONICAL_SYMMETRIC": Gimp.GradientType.CONICAL_SYMMETRIC,
    "CONICAL_ASYMMETRIC": Gimp.GradientType.CONICAL_ASYMMETRIC,
    "SHAPEBURST_ANGULAR": Gimp.GradientType.SHAPEBURST_ANGULAR,
    "SHAPEBURST_SPHERICAL": Gimp.GradientType.SHAPEBURST_SPHERICAL,
    "SHAPEBURST_DIMPLED": Gimp.GradientType.SHAPEBURST_DIMPLED,
    "SPIRAL_CLOCKWISE": Gimp.GradientType.SPIRAL_CLOCKWISE,
    "SPIRAL_ANTICLOCKWISE": Gimp.GradientType.SPIRAL_ANTICLOCKWISE,
}

BLENDGIMP_GRADIENT_REPEAT_MODES = {
    "NONE": Gimp.RepeatMode.NONE,
    "TRUNCATE": Gimp.RepeatMode.TRUNCATE,
    "SAWTOOTH": Gimp.RepeatMode.SAWTOOTH,
    "TRIANGULAR": Gimp.RepeatMode.TRIANGULAR,
}


def gimp_list_gradients():
    """MAIN THREAD ONLY. Return installed GIMP gradient resource names."""

    try:
        gradients = Gimp.gradients_get_list(None)
    except TypeError:
        gradients = Gimp.gradients_get_list("")

    names = []
    active_name = ""
    try:
        active = Gimp.context_get_gradient()
        if active is not None:
            active_name = str(active.get_name() or "")
    except Exception:
        active_name = ""

    for gradient in gradients or []:
        try:
            name = str(gradient.get_name() or "")
        except Exception:
            name = str(gradient or "")
        if name:
            names.append(name)

    return {
        "gradients": sorted(set(names), key=str.casefold),
        "active_gradient": active_name,
    }


def _blendgimp_gradient_by_name(name):
    wanted = str(name or "").strip()
    if not wanted:
        raise ValueError("Gradient resource name is empty")

    try:
        gradients = Gimp.gradients_get_list(None)
    except TypeError:
        gradients = Gimp.gradients_get_list("")

    for gradient in gradients or []:
        try:
            candidate = str(gradient.get_name() or "")
        except Exception:
            candidate = str(gradient or "")
        if candidate == wanted:
            return gradient

    raise ValueError(f"GIMP gradient resource not found: {wanted}")


def gimp_gradient_fill(
    image_id,
    layer_id,
    x1,
    y1,
    x2,
    y2,
    gradient_source="FG_BG",
    gradient_name="",
    gradient_type="LINEAR",
    reverse=False,
    repeat_mode="NONE",
):
    """MAIN THREAD ONLY. Apply one authoritative GIMP gradient operation."""

    image_id = int(image_id)
    layer_id = int(layer_id)
    x1 = float(x1)
    y1 = float(y1)
    x2 = float(x2)
    y2 = float(y2)
    source_key = str(gradient_source or "FG_BG").upper().strip()
    type_key = str(gradient_type or "LINEAR").upper().strip()
    repeat_key = str(repeat_mode or "NONE").upper().strip()
    gradient_name = str(gradient_name or "").strip()

    if type_key not in BLENDGIMP_GRADIENT_TYPES:
        raise ValueError(f"Unsupported BlendGimp gradient type: {type_key}")
    if repeat_key not in BLENDGIMP_GRADIENT_REPEAT_MODES:
        raise ValueError(f"Unsupported BlendGimp gradient repeat mode: {repeat_key}")
    if source_key not in {"FG_BG", "RESOURCE"}:
        raise ValueError(f"Unsupported BlendGimp gradient source: {source_key}")
    if abs(x2 - x1) < 0.001 and abs(y2 - y1) < 0.001:
        raise ValueError("Gradient start and end points must be different")

    image, layer = _gimp_resolve_image_layer(image_id, layer_id)
    if layer.is_group():
        raise ValueError("GIMP Gradient requires a raster layer")
    drawable, target_kind = _gimp_layer_edit_drawable(layer)

    layer_offset_x, layer_offset_y = _blendgimp_layer_offsets(layer)
    drawable_x1 = x1 - float(layer_offset_x)
    drawable_y1 = y1 - float(layer_offset_y)
    drawable_x2 = x2 - float(layer_offset_x)
    drawable_y2 = y2 - float(layer_offset_y)

    if source_key == "FG_BG":
        if Gimp.context_set_gradient_fg_bg_rgb() is False:
            raise RuntimeError("GIMP could not activate the FG/BG RGB gradient")
        active_gradient_name = "FG to BG (RGB)"
    else:
        gradient = _blendgimp_gradient_by_name(gradient_name)
        if Gimp.context_set_gradient(gradient) is False:
            raise RuntimeError(f"GIMP could not activate gradient: {gradient_name}")
        try:
            active_gradient_name = str(gradient.get_name() or gradient_name)
        except Exception:
            active_gradient_name = gradient_name

    if Gimp.context_set_gradient_reverse(bool(reverse)) is False:
        raise RuntimeError("GIMP could not set gradient reverse state")
    if Gimp.context_set_gradient_repeat_mode(
        BLENDGIMP_GRADIENT_REPEAT_MODES[repeat_key]
    ) is False:
        raise RuntimeError("GIMP could not set gradient repeat mode")

    if not image.undo_group_start():
        raise RuntimeError("GIMP could not start the Gradient undo group")

    try:
        success = drawable.edit_gradient_fill(
            BLENDGIMP_GRADIENT_TYPES[type_key],
            0.0,
            False,
            3,
            0.2,
            True,
            float(drawable_x1),
            float(drawable_y1),
            float(drawable_x2),
            float(drawable_y2),
        )
        if success is False:
            raise RuntimeError("GIMP gradient fill returned failure")
        Gimp.displays_flush()
    finally:
        try:
            image.undo_group_end()
        except Exception:
            pass

    return {
        "image_id": image_id,
        "layer_id": layer_id,
        "x1": x1,
        "y1": y1,
        "x2": x2,
        "y2": y2,
        "drawable_x1": float(drawable_x1),
        "drawable_y1": float(drawable_y1),
        "drawable_x2": float(drawable_x2),
        "drawable_y2": float(drawable_y2),
        "gradient_source": source_key,
        "gradient_name": active_gradient_name,
        "gradient_type": type_key,
        "reverse": bool(reverse),
        "repeat_mode": repeat_key,
        "layer_offset_x": int(layer_offset_x),
        "layer_offset_y": int(layer_offset_y),
        "target_kind": target_kind,
    }


BLENDGIMP_PAINT_TOOL_NAMES = {
    "PAINTBRUSH": "Paintbrush",
    "PENCIL": "Pencil",
    "ERASER": "Eraser",
    "AIRBRUSH": "Airbrush",
    "SMUDGE": "Smudge",
    "CLONE": "Clone",
    "HEAL": "Heal",
}


def _normalize_blendgimp_paint_tool(tool):
    tool = str(tool or "PAINTBRUSH").upper().strip()
    if tool not in BLENDGIMP_PAINT_TOOL_NAMES:
        raise ValueError(f"Unsupported BlendGimp paint tool: {tool}")
    return tool


def _call_gimp_stroke_tool(tool, layer, coordinates):
    tool = _normalize_blendgimp_paint_tool(tool)
    function = {
        "PAINTBRUSH": Gimp.paintbrush_default,
        "PENCIL": Gimp.pencil,
        "ERASER": Gimp.eraser_default,
        "AIRBRUSH": Gimp.airbrush_default,
        "SMUDGE": Gimp.smudge_default,
    }[tool]

    # Current GIMP 3 GI builds hide the C array-length argument. Retain the
    # explicit-length fallback for binding-version tolerance.
    try:
        success = function(layer, coordinates)
    except TypeError:
        success = function(layer, len(coordinates), coordinates)

    if success is False:
        raise RuntimeError(f"GIMP {BLENDGIMP_PAINT_TOOL_NAMES[tool]} returned failure")


def _call_gimp_clone_tool(
    layer,
    source_layer,
    source_x,
    source_y,
    coordinates,
):
    clone_type = Gimp.CloneType.IMAGE
    try:
        success = Gimp.clone(
            layer,
            source_layer,
            clone_type,
            float(source_x),
            float(source_y),
            coordinates,
        )
    except TypeError:
        success = Gimp.clone(
            layer,
            source_layer,
            clone_type,
            float(source_x),
            float(source_y),
            len(coordinates),
            coordinates,
        )
    if success is False:
        raise RuntimeError("GIMP Clone returned failure")


def _call_gimp_heal_tool(
    layer,
    source_layer,
    source_x,
    source_y,
    coordinates,
):
    try:
        success = Gimp.heal(
            layer,
            source_layer,
            float(source_x),
            float(source_y),
            coordinates,
        )
    except TypeError:
        success = Gimp.heal(
            layer,
            source_layer,
            float(source_x),
            float(source_y),
            len(coordinates),
            coordinates,
        )
    if success is False:
        raise RuntimeError("GIMP Heal returned failure")


def _blendgimp_clone_segment(
    image_id,
    layer_id,
    source_image_id,
    source_layer_id,
    source_x,
    source_y,
    reference_dest_x,
    reference_dest_y,
    strokes,
):
    """Clone one image-space segment while preserving source alignment."""
    _, layer = _gimp_resolve_image_layer(int(image_id), int(layer_id))
    _, source_layer = _gimp_resolve_image_layer(int(source_image_id), int(source_layer_id))

    if layer.is_group() or source_layer.is_group():
        raise ValueError("GIMP Clone requires raster source and destination layers")
    drawable, _target_kind = _gimp_layer_edit_drawable(layer)
    source_drawable, _source_target_kind = _gimp_layer_edit_drawable(source_layer)
    if not isinstance(strokes, (list, tuple)) or len(strokes) < 2 or len(strokes) % 2:
        raise ValueError("Clone stroke coordinates must contain x/y pairs")

    image_coordinates = [float(value) for value in strokes]
    first_x = image_coordinates[0]
    first_y = image_coordinates[1]

    source_offset_x, source_offset_y = _blendgimp_layer_offsets(source_layer)
    dest_offset_x, dest_offset_y = _blendgimp_layer_offsets(layer)

    adjusted_source_x = (
        float(source_x)
        + (first_x - float(reference_dest_x))
        - float(source_offset_x)
    )
    adjusted_source_y = (
        float(source_y)
        + (first_y - float(reference_dest_y))
        - float(source_offset_y)
    )

    local_coordinates = []
    for index in range(0, len(image_coordinates), 2):
        local_coordinates.extend((
            image_coordinates[index] - float(dest_offset_x),
            image_coordinates[index + 1] - float(dest_offset_y),
        ))

    _call_gimp_clone_tool(
        drawable,
        source_drawable,
        adjusted_source_x,
        adjusted_source_y,
        local_coordinates,
    )
    return int(len(image_coordinates) // 2)


def _blendgimp_heal_segment(
    image_id,
    layer_id,
    source_image_id,
    source_layer_id,
    source_x,
    source_y,
    reference_dest_x,
    reference_dest_y,
    strokes,
):
    """Heal one image-space segment while preserving source alignment."""
    _, layer = _gimp_resolve_image_layer(int(image_id), int(layer_id))
    _, source_layer = _gimp_resolve_image_layer(int(source_image_id), int(source_layer_id))

    if layer.is_group() or source_layer.is_group():
        raise ValueError("GIMP Heal requires raster source and destination layers")
    drawable, _target_kind = _gimp_layer_edit_drawable(layer)
    source_drawable, _source_target_kind = _gimp_layer_edit_drawable(source_layer)
    if not isinstance(strokes, (list, tuple)) or len(strokes) < 2 or len(strokes) % 2:
        raise ValueError("Heal stroke coordinates must contain x/y pairs")

    image_coordinates = [float(value) for value in strokes]
    first_x = image_coordinates[0]
    first_y = image_coordinates[1]

    source_offset_x, source_offset_y = _blendgimp_layer_offsets(source_layer)
    dest_offset_x, dest_offset_y = _blendgimp_layer_offsets(layer)

    adjusted_source_x = (
        float(source_x)
        + (first_x - float(reference_dest_x))
        - float(source_offset_x)
    )
    adjusted_source_y = (
        float(source_y)
        + (first_y - float(reference_dest_y))
        - float(source_offset_y)
    )

    local_coordinates = []
    for index in range(0, len(image_coordinates), 2):
        local_coordinates.extend((
            image_coordinates[index] - float(dest_offset_x),
            image_coordinates[index + 1] - float(dest_offset_y),
        ))

    _call_gimp_heal_tool(
        drawable,
        source_drawable,
        adjusted_source_x,
        adjusted_source_y,
        local_coordinates,
    )
    return int(len(image_coordinates) // 2)


def gimp_paint_stroke(
    image_id,
    layer_id,
    strokes,
    tool="PAINTBRUSH",
    flush=True,
    include_brush_state=True
):
    """MAIN THREAD ONLY. Paint one image-space stroke with a real GIMP paint tool."""

    image_id = int(image_id)
    layer_id = int(layer_id)
    tool = _normalize_blendgimp_paint_tool(tool)

    image, layer = _gimp_resolve_image_layer(image_id, layer_id)

    if layer.is_group():
        raise ValueError("Direct GIMP painting requires a raster layer")
    drawable, target_kind = _gimp_layer_edit_drawable(layer)

    if not isinstance(strokes, (list, tuple)):
        raise ValueError("Stroke coordinates must be a list")

    if len(strokes) < 2:
        raise ValueError("A GIMP stroke requires at least one x/y point")

    if len(strokes) % 2 != 0:
        raise ValueError("GIMP stroke coordinate count must be even")

    if len(strokes) > 32768:
        raise ValueError("GIMP stroke contains too many coordinate values")

    coordinates = [float(value) for value in strokes]
    if tool in {"CLONE", "HEAL"}:
        raise ValueError(f"{BLENDGIMP_PAINT_TOOL_NAMES[tool]} strokes require an explicit source and streamed source state")
    _call_gimp_stroke_tool(tool, drawable, coordinates)

    if flush:
        Gimp.displays_flush()

    brush_state = gimp_get_brush_state() if include_brush_state else {}

    return {
        "image_id": image_id,
        "layer_id": layer_id,
        "tool": tool,
        "target_kind": target_kind,
        "point_count": int(len(coordinates) // 2),
        **brush_state,
    }


def gimp_begin_direct_paint_stroke(
    image_id,
    layer_id,
    stroke_id,
    tool="PAINTBRUSH",
    source_image_id=None,
    source_layer_id=None,
    source_x=None,
    source_y=None,
):
    """MAIN THREAD ONLY. Open one GIMP undo group for a streamed BlendGimp stroke."""

    image_id = int(image_id)
    layer_id = int(layer_id)
    stroke_id = str(stroke_id).strip()
    tool = _normalize_blendgimp_paint_tool(tool)

    if not stroke_id:
        raise ValueError("Direct paint stroke ID is required")

    image, layer = _gimp_resolve_image_layer(image_id, layer_id)

    if layer.is_group():
        raise ValueError("Direct GIMP painting requires a raster layer")
    _drawable, target_kind = _gimp_layer_edit_drawable(layer)

    if stroke_id in BLENDGIMP_ACTIVE_DIRECT_STROKES:
        raise ValueError(f"Direct paint stroke {stroke_id} is already active")

    source_state = {}
    if tool in {"CLONE", "HEAL"}:
        tool_name = BLENDGIMP_PAINT_TOOL_NAMES[tool]
        if source_image_id is None or source_layer_id is None or source_x is None or source_y is None:
            raise ValueError(f"{tool_name} requires source image, layer, and coordinates")
        source_image_id = int(source_image_id)
        source_layer_id = int(source_layer_id)
        source_x = float(source_x)
        source_y = float(source_y)
        _, source_layer = _gimp_resolve_image_layer(source_image_id, source_layer_id)
        if source_layer.is_group():
            raise ValueError(f"{tool_name} source must be a raster layer")
        source_state = {
            "source_image_id": source_image_id,
            "source_layer_id": source_layer_id,
            "source_x": source_x,
            "source_y": source_y,
            "reference_dest_x": None,
            "reference_dest_y": None,
        }

    stale_ids = [
        active_id
        for active_id, active in BLENDGIMP_ACTIVE_DIRECT_STROKES.items()
        if int(active.get("image_id", -1)) == image_id
    ]

    for stale_id in stale_ids:
        stale = BLENDGIMP_ACTIVE_DIRECT_STROKES.pop(stale_id, None)
        if stale is None:
            continue
        stale_image = Gimp.Image.get_by_id(int(stale.get("image_id", -1)))
        if stale_image is not None and stale_image.is_valid():
            try:
                stale_image.undo_group_end()
            except Exception:
                pass

    if not image.undo_group_start():
        raise RuntimeError("GIMP could not start the direct-paint undo group")

    base_brush_state = gimp_get_brush_state()

    BLENDGIMP_ACTIVE_DIRECT_STROKES[stroke_id] = {
        "image_id": image_id,
        "layer_id": layer_id,
        "tool": tool,
        "target_kind": target_kind,
        "base_brush_size": float(base_brush_state.get("brush_size", 20.0)),
        "base_brush_opacity": float(base_brush_state.get("brush_opacity", 100.0)),
        "pressure_application": "metadata-only",
        "pressure_subsegments": 0,
        "chunk_count": 0,
        "point_count": 0,
        "input_sample_count": 0,
        "tablet_sample_count": 0,
        "pressure_sum": 0.0,
        "pressure_min": 1.0,
        "pressure_max": 0.0,
        "tilt_max": 0.0,
        **source_state,
    }

    return {
        "stroke_id": stroke_id,
        "image_id": image_id,
        "layer_id": layer_id,
        "tool": tool,
        "target_kind": target_kind,
        **({
            "source_image_id": int(source_state["source_image_id"]),
            "source_layer_id": int(source_state["source_layer_id"]),
            "source_x": float(source_state["source_x"]),
            "source_y": float(source_state["source_y"]),
        } if source_state else {}),
        **gimp_get_brush_state(),
    }


def _normalize_blendgimp_input_sample(sample):
    """Normalize compact Blender tablet metadata.

    Format: [pressure, tilt_x, tilt_y, is_tablet].  This foundation phase
    transports the values faithfully but does not yet alter GIMP paint-tool
    behavior; application is handled by later 6.4 work.
    """
    try:
        if isinstance(sample, dict):
            pressure = float(sample.get("pressure", 1.0))
            tilt_x = float(sample.get("tilt_x", 0.0))
            tilt_y = float(sample.get("tilt_y", 0.0))
            is_tablet = bool(sample.get("is_tablet", False))
        else:
            pressure = float(sample[0])
            tilt_x = float(sample[1])
            tilt_y = float(sample[2])
            is_tablet = bool(sample[3])
    except Exception:
        pressure, tilt_x, tilt_y, is_tablet = 1.0, 0.0, 0.0, False
    return [
        max(0.0, min(1.0, pressure)),
        tilt_x,
        tilt_y,
        1 if is_tablet else 0,
    ]


def _blendgimp_input_stats(samples, expected_points):
    expected_points = max(0, int(expected_points))
    if not isinstance(samples, (list, tuple)):
        samples = []
    normalized = [
        _normalize_blendgimp_input_sample(sample)
        for sample in list(samples)[:expected_points]
    ]
    if len(normalized) < expected_points:
        normalized.extend(
            [[1.0, 0.0, 0.0, 0] for _ in range(expected_points - len(normalized))]
        )
    if not normalized:
        return {
            "input_sample_count": 0,
            "tablet_sample_count": 0,
            "pressure_min": 1.0,
            "pressure_max": 1.0,
            "pressure_sum": 0.0,
            "tilt_max": 0.0,
        }
    pressures = [float(sample[0]) for sample in normalized]
    tilt_max = max(
        (float(sample[1]) ** 2 + float(sample[2]) ** 2) ** 0.5
        for sample in normalized
    )
    return {
        "input_sample_count": len(normalized),
        "tablet_sample_count": sum(1 for sample in normalized if bool(sample[3])),
        "pressure_min": min(pressures),
        "pressure_max": max(pressures),
        "pressure_sum": sum(pressures),
        "tilt_max": float(tilt_max),
    }


BLENDGIMP_PRESSURE_LEVELS = 16
BLENDGIMP_PRESSURE_ZERO_EPSILON = 0.01
BLENDGIMP_PRESSURE_MIN_BRUSH_SIZE = 1.0


def _blendgimp_pressure_groups(coordinates, samples):
    """Build pressure-coherent coordinate groups for one GIMP PDB call series.

    GIMP's Paintbrush/Pencil/Eraser PDB calls accept XY coordinates but no
    per-point tablet pressure.  BlendGimp therefore groups tablet samples into
    a small number of pressure levels and lets GIMP rasterize each connected
    group using its real brush engine.  Group boundaries overlap one point so
    the resulting stroke remains continuous.  Non-tablet gaps inside an
    otherwise tablet-driven stroke inherit the nearest preceding pen pressure
    (or the first pen pressure before the first tablet-tagged sample) rather
    than producing a false 100% pressure spike.
    """
    if not isinstance(coordinates, (list, tuple)):
        return []
    point_count = len(coordinates) // 2
    if point_count <= 0:
        return []

    raw_samples = list(samples) if isinstance(samples, (list, tuple)) else []
    normalized = [
        _normalize_blendgimp_input_sample(sample)
        for sample in raw_samples[:point_count]
    ]
    if len(normalized) < point_count:
        normalized.extend(
            [[1.0, 0.0, 0.0, 0] for _ in range(point_count - len(normalized))]
        )

    tablet_pressures = [
        float(sample[0]) for sample in normalized if bool(sample[3])
    ]
    if not tablet_pressures:
        return []

    first_tablet_pressure = tablet_pressures[0]
    pressure_values = []
    last_pressure = first_tablet_pressure
    for sample in normalized:
        if bool(sample[3]):
            last_pressure = float(sample[0])
        pressure_values.append(max(0.0, min(1.0, float(last_pressure))))

    levels = max(2, int(BLENDGIMP_PRESSURE_LEVELS))
    buckets = [
        int(round(value * float(levels - 1)))
        for value in pressure_values
    ]

    runs = []
    run_start = 0
    run_bucket = buckets[0]
    for index in range(1, point_count):
        if buckets[index] == run_bucket:
            continue
        runs.append((run_start, index - 1))
        run_start = index
        run_bucket = buckets[index]
    runs.append((run_start, point_count - 1))

    groups = []
    for start, end in runs:
        coordinate_start = max(0, start - 1) if start > 0 else start
        group_coordinates = []
        for point_index in range(coordinate_start, end + 1):
            group_coordinates.extend((
                float(coordinates[point_index * 2]),
                float(coordinates[point_index * 2 + 1]),
            ))
        representative = sum(pressure_values[start:end + 1]) / max(1, end - start + 1)
        groups.append((group_coordinates, max(0.0, min(1.0, representative))))
    return groups


def _call_gimp_pressure_tool(tool, layer, coordinates, pressure, base_brush_size):
    """Apply one pressure-coherent subsegment using GIMP's raster engine.

    Airbrush and Smudge expose a native pressure parameter in GIMP 3.2.4.
    Paintbrush, Pencil, and Eraser do not, so pressure is mapped to GIMP brush
    size for the duration of the subsegment.  The caller restores the shared
    brush size after the full segment has been processed.
    """
    tool = _normalize_blendgimp_paint_tool(tool)
    pressure = max(0.0, min(1.0, float(pressure)))
    if pressure <= BLENDGIMP_PRESSURE_ZERO_EPSILON:
        return False

    if tool in {"AIRBRUSH", "SMUDGE"}:
        function = Gimp.airbrush if tool == "AIRBRUSH" else Gimp.smudge
        # GIMP's PDB pressure parameter uses the tool's traditional 0..100
        # pressure scale.  BlendGimp transports normalized Blender pressure.
        native_pressure = pressure * 100.0
        try:
            success = function(layer, native_pressure, coordinates)
        except TypeError:
            success = function(layer, native_pressure, len(coordinates), coordinates)
        if success is False:
            raise RuntimeError(
                f"GIMP {BLENDGIMP_PAINT_TOOL_NAMES[tool]} pressure stroke returned failure"
            )
        return True

    if tool in {"PAINTBRUSH", "PENCIL", "ERASER"}:
        pressure_size = max(
            float(BLENDGIMP_PRESSURE_MIN_BRUSH_SIZE),
            float(base_brush_size) * pressure,
        )
        if Gimp.context_set_brush_size(pressure_size) is False:
            raise RuntimeError("GIMP could not apply tablet pressure brush size")
        _call_gimp_stroke_tool(tool, layer, coordinates)
        return True

    return False


def _gimp_paint_pressure_segment(image_id, layer_id, coordinates, samples, tool, base_brush_size):
    """Paint one segment with tablet pressure, returning application diagnostics."""
    groups = _blendgimp_pressure_groups(coordinates, samples)
    if not groups or tool not in {"PAINTBRUSH", "PENCIL", "ERASER", "AIRBRUSH", "SMUDGE"}:
        result = gimp_paint_stroke(
            image_id, layer_id, coordinates, tool=tool, flush=False, include_brush_state=False
        )
        return int(result.get("point_count", 0)), "metadata-only", 0

    _image, layer = _gimp_resolve_image_layer(int(image_id), int(layer_id))
    drawable, _target_kind = _gimp_layer_edit_drawable(layer)
    calls = 0
    try:
        for group_coordinates, pressure in groups:
            if _call_gimp_pressure_tool(
                tool, drawable, group_coordinates, pressure, float(base_brush_size)
            ):
                calls += 1
    finally:
        if tool in {"PAINTBRUSH", "PENCIL", "ERASER"}:
            try:
                Gimp.context_set_brush_size(float(base_brush_size))
            except Exception:
                pass

    application = (
        "gimp-native-pressure"
        if tool in {"AIRBRUSH", "SMUDGE"}
        else "gimp-brush-size-pressure"
    )
    return int(len(coordinates) // 2), application, int(calls)


def gimp_paint_direct_stroke_chunk(
    image_id,
    layer_id,
    stroke_id,
    strokes,
    segments=None,
    input_samples=None,
    input_segments=None
):
    """MAIN THREAD ONLY. Paint one chunk inside an already-open undo group."""

    image_id = int(image_id)
    layer_id = int(layer_id)
    stroke_id = str(stroke_id)

    active = BLENDGIMP_ACTIVE_DIRECT_STROKES.get(stroke_id)
    if active is None:
        raise ValueError(f"Direct paint stroke {stroke_id} is not active")

    if (
        int(active.get("image_id", -1)) != image_id
        or int(active.get("layer_id", -1)) != layer_id
    ):
        raise ValueError("Direct paint stroke target changed while streaming")

    tool = _normalize_blendgimp_paint_tool(active.get("tool", "PAINTBRUSH"))
    _image, current_layer = _gimp_resolve_image_layer(image_id, layer_id)
    _current_drawable, current_target_kind = _gimp_layer_edit_drawable(current_layer)
    if str(active.get("target_kind", "LAYER")) != current_target_kind:
        raise ValueError("Layer/mask paint target changed while streaming")

    if isinstance(segments, (list, tuple)) and segments:
        stroke_segments = list(segments)
        raw_input_segments = list(input_segments) if isinstance(input_segments, (list, tuple)) else []
    else:
        stroke_segments = [strokes]
        raw_input_segments = [input_samples] if input_samples is not None else []

    total_point_count = 0
    chunk_input_stats = {
        "input_sample_count": 0,
        "tablet_sample_count": 0,
        "pressure_sum": 0.0,
        "pressure_min": 1.0,
        "pressure_max": 0.0,
        "tilt_max": 0.0,
    }
    for segment_index, segment in enumerate(stroke_segments):
        point_count = (len(segment) // 2) if isinstance(segment, (list, tuple)) else 0
        samples = raw_input_segments[segment_index] if segment_index < len(raw_input_segments) else None
        stats = _blendgimp_input_stats(samples, point_count)
        count = int(stats["input_sample_count"])
        if count:
            if int(chunk_input_stats["input_sample_count"]) == 0:
                chunk_input_stats["pressure_min"] = float(stats["pressure_min"])
                chunk_input_stats["pressure_max"] = float(stats["pressure_max"])
            else:
                chunk_input_stats["pressure_min"] = min(float(chunk_input_stats["pressure_min"]), float(stats["pressure_min"]))
                chunk_input_stats["pressure_max"] = max(float(chunk_input_stats["pressure_max"]), float(stats["pressure_max"]))
            chunk_input_stats["input_sample_count"] += count
            chunk_input_stats["tablet_sample_count"] += int(stats["tablet_sample_count"])
            chunk_input_stats["pressure_sum"] += float(stats["pressure_sum"])
            chunk_input_stats["tilt_max"] = max(float(chunk_input_stats["tilt_max"]), float(stats["tilt_max"]))
    if tool in {"CLONE", "HEAL"}:
        first_segment = next((segment for segment in stroke_segments if isinstance(segment, (list, tuple)) and len(segment) >= 2), None)
        if first_segment is None:
            raise ValueError(f"{BLENDGIMP_PAINT_TOOL_NAMES[tool]} chunk has no destination coordinates")
        if active.get("reference_dest_x") is None:
            active["reference_dest_x"] = float(first_segment[0])
            active["reference_dest_y"] = float(first_segment[1])

        segment_function = _blendgimp_clone_segment if tool == "CLONE" else _blendgimp_heal_segment
        for segment in stroke_segments:
            if not isinstance(segment, (list, tuple)) or len(segment) < 2:
                continue
            total_point_count += segment_function(
                image_id,
                layer_id,
                int(active["source_image_id"]),
                int(active["source_layer_id"]),
                float(active["source_x"]),
                float(active["source_y"]),
                float(active["reference_dest_x"]),
                float(active["reference_dest_y"]),
                segment,
            )
    else:
        pressure_application = "mouse-fast-path"
        pressure_subsegments = 0
        for segment_index, segment in enumerate(stroke_segments):
            if not isinstance(segment, (list, tuple)) or len(segment) < 2:
                continue
            samples = raw_input_segments[segment_index] if segment_index < len(raw_input_segments) else None
            segment_tablet_samples = 0
            if isinstance(samples, (list, tuple)):
                segment_tablet_samples = sum(
                    1
                    for sample in list(samples)[: len(segment) // 2]
                    if bool(_normalize_blendgimp_input_sample(sample)[3])
                )

            if segment_tablet_samples > 0:
                painted_points, segment_application, segment_calls = _gimp_paint_pressure_segment(
                    image_id,
                    layer_id,
                    segment,
                    samples,
                    tool,
                    float(active.get("base_brush_size", 20.0)),
                )
                total_point_count += int(painted_points)
                pressure_subsegments += int(segment_calls)
                if segment_application != "metadata-only":
                    pressure_application = segment_application
            else:
                result = gimp_paint_stroke(
                    image_id,
                    layer_id,
                    segment,
                    tool=tool,
                    flush=False,
                    include_brush_state=False,
                )
                total_point_count += int(result.get("point_count", 0))

        active["pressure_application"] = pressure_application
        active["pressure_subsegments"] = int(active.get("pressure_subsegments", 0)) + int(pressure_subsegments)

    Gimp.displays_flush()

    result = {
        "image_id": image_id,
        "layer_id": layer_id,
        "tool": tool,
        "point_count": int(total_point_count),
        "segment_count": len(stroke_segments),
        **({
            "source_image_id": int(active["source_image_id"]),
            "source_layer_id": int(active["source_layer_id"]),
            "source_x": float(active["source_x"]),
            "source_y": float(active["source_y"]),
            "reference_dest_x": float(active["reference_dest_x"]),
            "reference_dest_y": float(active["reference_dest_y"]),
        } if tool in {"CLONE", "HEAL"} else {}),
        **gimp_get_brush_state(),
    }

    active["chunk_count"] = int(active.get("chunk_count", 0)) + 1
    active["point_count"] = int(active.get("point_count", 0)) + int(result.get("point_count", 0))
    previous_input_count = int(active.get("input_sample_count", 0))
    chunk_input_count = int(chunk_input_stats["input_sample_count"])
    if chunk_input_count:
        if previous_input_count == 0:
            active["pressure_min"] = float(chunk_input_stats["pressure_min"])
            active["pressure_max"] = float(chunk_input_stats["pressure_max"])
        else:
            active["pressure_min"] = min(float(active.get("pressure_min", 1.0)), float(chunk_input_stats["pressure_min"]))
            active["pressure_max"] = max(float(active.get("pressure_max", 0.0)), float(chunk_input_stats["pressure_max"]))
        active["input_sample_count"] = previous_input_count + chunk_input_count
        active["tablet_sample_count"] = int(active.get("tablet_sample_count", 0)) + int(chunk_input_stats["tablet_sample_count"])
        active["pressure_sum"] = float(active.get("pressure_sum", 0.0)) + float(chunk_input_stats["pressure_sum"])
        active["tilt_max"] = max(float(active.get("tilt_max", 0.0)), float(chunk_input_stats["tilt_max"]))

    return {
        "stroke_id": stroke_id,
        "chunk_index": int(active["chunk_count"]),
        "total_point_count": int(active["point_count"]),
        "tablet_transport": (
            "pressure-applied"
            if str(active.get("pressure_application", "metadata-only")) not in {"metadata-only", "mouse-fast-path"}
            else "metadata-only"
        ),
        "pressure_application": str(active.get("pressure_application", "metadata-only")),
        "pressure_subsegments": int(pressure_subsegments if tool not in {"CLONE", "HEAL"} else 0),
        "input_sample_count": int(chunk_input_stats["input_sample_count"]),
        "tablet_sample_count": int(chunk_input_stats["tablet_sample_count"]),
        "pressure_min": float(chunk_input_stats["pressure_min"]),
        "pressure_max": float(chunk_input_stats["pressure_max"] if int(chunk_input_stats["input_sample_count"]) else 1.0),
        "pressure_avg": (
            float(chunk_input_stats["pressure_sum"]) / max(1, int(chunk_input_stats["input_sample_count"]))
        ),
        "tilt_max": float(chunk_input_stats["tilt_max"]),
        **result,
    }


def gimp_end_direct_paint_stroke(
    stroke_id
):
    """
    MAIN THREAD ONLY.

    Close the undo group for one streamed stroke.
    """

    stroke_id = str(
        stroke_id
    )

    active = BLENDGIMP_ACTIVE_DIRECT_STROKES.pop(
        stroke_id,
        None
    )

    if active is None:
        return {
            "stroke_id": stroke_id,
            "ended": False,
            "tool": "PAINTBRUSH",
            "chunk_count": 0,
            "point_count": 0,
        }

    image_id = int(
        active.get(
            "image_id",
            -1
        )
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is not None and image.is_valid():

        if not image.undo_group_end():
            raise RuntimeError(
                "GIMP could not close the direct-paint undo group"
            )

    Gimp.displays_flush()

    return {
        "stroke_id": stroke_id,
        "ended": True,
        "image_id": image_id,
        "layer_id": int(
            active.get(
                "layer_id",
                -1
            )
        ),
        "chunk_count": int(
            active.get(
                "chunk_count",
                0
            )
        ),
        "point_count": int(
            active.get(
                "point_count",
                0
            )
        ),
        "tool": _normalize_blendgimp_paint_tool(
            active.get("tool", "PAINTBRUSH")
        ),
        "tablet_transport": (
            "pressure-applied"
            if str(active.get("pressure_application", "metadata-only")) not in {"metadata-only", "mouse-fast-path"}
            else "metadata-only"
        ),
        "pressure_application": str(active.get("pressure_application", "metadata-only")),
        "pressure_subsegments": int(active.get("pressure_subsegments", 0)),
        "input_sample_count": int(active.get("input_sample_count", 0)),
        "tablet_sample_count": int(active.get("tablet_sample_count", 0)),
        "pressure_min": float(active.get("pressure_min", 1.0)),
        "pressure_max": float(active.get("pressure_max", 1.0) if int(active.get("input_sample_count", 0)) else 1.0),
        "pressure_avg": (
            float(active.get("pressure_sum", 0.0)) / max(1, int(active.get("input_sample_count", 0)))
        ),
        "tilt_max": float(active.get("tilt_max", 0.0)),
    }


def gimp_close_all_direct_paint_strokes():
    """
    MAIN THREAD ONLY.

    Safety cleanup for a Blender disconnect or GIMP plug-in shutdown.
    """

    active_ids = list(
        BLENDGIMP_ACTIVE_DIRECT_STROKES.keys()
    )

    closed = 0

    for stroke_id in active_ids:

        try:
            result = gimp_end_direct_paint_stroke(
                stroke_id
            )

            if result.get(
                "ended",
                False
            ):
                closed += 1

        except Exception as exc:
            log(
                "Could not close stale direct paint stroke "
                f"{stroke_id}: {exc}"
            )

    return closed


# -----------------------------------------------------------------------------
# Blender -> GIMP binary pixel writes
# -----------------------------------------------------------------------------

def _blendgimp_crop_rgba_region(
    raw_pixels,
    source_width,
    source_height,
    crop_x,
    crop_y,
    crop_width,
    crop_height
):
    """
    Crop top-left-origin RGBA8 bytes.
    """

    if (
        crop_x == 0
        and crop_y == 0
        and crop_width == source_width
        and crop_height == source_height
    ):
        return bytes(
            raw_pixels
        )

    source_row_bytes = (
        source_width
        * 4
    )

    crop_row_bytes = (
        crop_width
        * 4
    )

    result = bytearray(
        crop_row_bytes
        * crop_height
    )

    for row in range(
        crop_height
    ):

        source_start = (
            (
                crop_y
                + row
            )
            * source_row_bytes
            + crop_x
            * 4
        )

        source_end = (
            source_start
            + crop_row_bytes
        )

        destination_start = (
            row
            * crop_row_bytes
        )

        result[
            destination_start:
            destination_start + crop_row_bytes
        ] = raw_pixels[
            source_start:
            source_end
        ]

    return bytes(
        result
    )


def gimp_set_layer_pixels_binary(
    image_id,
    layer_id,
    image_x,
    image_y,
    region_width,
    region_height,
    raw_pixels
):
    """
    MAIN THREAD ONLY.

    Apply top-left-origin straight RGBA8 pixels from Blender to a GIMP layer.

    Coordinates from Blender are image-space coordinates. They are converted
    to drawable-local coordinates before writing to GIMP's shadow buffer.

    The shadow buffer is merged with undo=True so a Blender-originated paint
    push remains undoable from GIMP.
    """

    image_id = int(
        image_id
    )

    layer_id = int(
        layer_id
    )

    image_x = int(
        image_x
    )

    image_y = int(
        image_y
    )

    region_width = int(
        region_width
    )

    region_height = int(
        region_height
    )

    if region_width <= 0 or region_height <= 0:
        raise ValueError(
            "Pixel write region must be larger than zero"
        )

    image, layer = _gimp_resolve_image_layer(
        image_id,
        layer_id
    )

    if layer.is_group():
        raise ValueError(
            "Cannot write raster pixels directly to a GIMP group layer"
        )
    drawable, target_kind = _gimp_layer_edit_drawable(layer)

    expected_length = (
        region_width
        * region_height
        * 4
    )

    if len(
        raw_pixels
    ) != expected_length:
        raise ValueError(
            "Blender pixel payload has the wrong size. "
            f"Expected {expected_length}, got {len(raw_pixels)}"
        )

    layer_offset_x, layer_offset_y = (
        _blendgimp_layer_offsets(
            layer
        )
    )

    layer_width = int(
        drawable.get_width()
    )

    layer_height = int(
        drawable.get_height()
    )

    requested_left = image_x
    requested_top = image_y
    requested_right = (
        image_x
        + region_width
    )
    requested_bottom = (
        image_y
        + region_height
    )

    layer_left = layer_offset_x
    layer_top = layer_offset_y
    layer_right = (
        layer_offset_x
        + layer_width
    )
    layer_bottom = (
        layer_offset_y
        + layer_height
    )

    write_left = max(
        requested_left,
        layer_left
    )

    write_top = max(
        requested_top,
        layer_top
    )

    write_right = min(
        requested_right,
        layer_right
    )

    write_bottom = min(
        requested_bottom,
        layer_bottom
    )

    if (
        write_right <= write_left
        or write_bottom <= write_top
    ):
        raise ValueError(
            "Blender pixel region does not overlap the selected GIMP layer"
        )

    write_width = (
        write_right
        - write_left
    )

    write_height = (
        write_bottom
        - write_top
    )

    source_crop_x = (
        write_left
        - requested_left
    )

    source_crop_y = (
        write_top
        - requested_top
    )

    write_pixels = (
        _blendgimp_crop_rgba_region(
            raw_pixels,
            region_width,
            region_height,
            source_crop_x,
            source_crop_y,
            write_width,
            write_height,
        )
    )

    local_x = (
        write_left
        - layer_offset_x
    )

    local_y = (
        write_top
        - layer_offset_y
    )

    shadow = drawable.get_shadow_buffer()

    if shadow is None:
        raise RuntimeError(
            "GIMP did not return a shadow buffer for the selected layer"
        )

    rectangle = Gegl.Rectangle.new(
        local_x,
        local_y,
        write_width,
        write_height,
    )

    # GEGL's introspectable setter is exposed as Buffer.set() in Python
    # bindings. Different GI builds may expose the inferred-length and
    # explicit-length variants, so support both.
    try:

        shadow.set(
            rectangle,
            "R'G'B'A u8",
            write_pixels,
        )

    except TypeError:

        shadow.set(
            rectangle,
            "R'G'B'A u8",
            write_pixels,
            len(
                write_pixels
            ),
        )

    shadow.flush()

    merged = drawable.merge_shadow(
        True
    )

    if merged is False:
        raise RuntimeError(
            "GIMP could not merge the Blender pixel write into the layer"
        )

    updated = drawable.update(
        local_x,
        local_y,
        write_width,
        write_height,
    )

    if updated is False:
        raise RuntimeError(
            "GIMP could not update the written drawable region"
        )

    Gimp.displays_flush()

    accepted_composite = _blendgimp_accept_blender_originated_write(
        image_id
    )

    composite_patch = b""
    composite_width = int(image.get_width())
    composite_height = int(image.get_height())
    sync_token = _blendgimp_composite_token(image_id)
    if accepted_composite is not None:
        composite_width = int(accepted_composite.get("width", composite_width))
        composite_height = int(accepted_composite.get("height", composite_height))
        sync_token = str(accepted_composite.get("sync_token", sync_token))
        composite_patch = _blendgimp_crop_rgba_region(
            accepted_composite.get("pixels", b""),
            composite_width,
            composite_height,
            write_left,
            write_top,
            write_width,
            write_height,
        )

    return {
        "image_id": image_id,
        "layer_id": layer_id,
        "image_x": write_left,
        "image_y": write_top,
        "layer_x": local_x,
        "layer_y": local_y,
        "width": write_width,
        "height": write_height,
        "byte_length": len(
            write_pixels
        ),
        "sync_token": sync_token,
        "image_width": composite_width,
        "image_height": composite_height,
        "composite_x": write_left,
        "composite_y": write_top,
        "composite_width": write_width,
        "composite_height": write_height,
        "composite_byte_length": len(composite_patch),
        "target_kind": target_kind,
        "_binary_payload": composite_patch,
        "clipped": bool(
            write_width != region_width
            or write_height != region_height
            or write_left != requested_left
            or write_top != requested_top
        ),
    }


def gimp_get_layer_pixels_binary(
    image_id,
    layer_id,
    image_x=None,
    image_y=None,
    region_width=None,
    region_height=None,
):
    """MAIN THREAD ONLY. Return raw raster-layer RGBA8 without compositing."""

    image, layer = _gimp_resolve_image_layer(int(image_id), int(layer_id))
    if layer.is_group():
        raise ValueError("Cannot read raster pixels directly from a GIMP group layer")
    drawable, target_kind = _gimp_layer_edit_drawable(layer)

    image_width = int(image.get_width())
    image_height = int(image.get_height())
    layer_width = int(drawable.get_width())
    layer_height = int(drawable.get_height())
    layer_offset_x, layer_offset_y = _blendgimp_layer_offsets(layer)

    if image_x is None or image_y is None or region_width is None or region_height is None:
        requested_left = layer_offset_x
        requested_top = layer_offset_y
        requested_right = layer_offset_x + layer_width
        requested_bottom = layer_offset_y + layer_height
    else:
        requested_left = int(image_x)
        requested_top = int(image_y)
        requested_right = requested_left + int(region_width)
        requested_bottom = requested_top + int(region_height)

    read_left = max(requested_left, layer_offset_x, 0)
    read_top = max(requested_top, layer_offset_y, 0)
    read_right = min(requested_right, layer_offset_x + layer_width, image_width)
    read_bottom = min(requested_bottom, layer_offset_y + layer_height, image_height)

    if read_right <= read_left or read_bottom <= read_top:
        return {
            "image_id": int(image_id), "layer_id": int(layer_id),
            "image_width": image_width, "image_height": image_height,
            "x": int(read_left), "y": int(read_top),
            "width": 0, "height": 0, "layer_offset_x": layer_offset_x,
            "layer_offset_y": layer_offset_y, "pixel_format": "R'G'B'A u8",
            "origin": "top-left", "target_kind": target_kind, "byte_length": 0, "_binary_payload": b"",
        }

    read_width = read_right - read_left
    read_height = read_bottom - read_top
    local_x = read_left - layer_offset_x
    local_y = read_top - layer_offset_y
    buffer = drawable.get_buffer()
    if buffer is None:
        raise RuntimeError("GIMP did not return a GEGL buffer for the selected layer")
    rectangle = Gegl.Rectangle.new(local_x, local_y, read_width, read_height)
    pixel_result = buffer.get(rectangle, 1.0, "R'G'B'A u8", Gegl.AbyssPolicy.NONE)
    raw_pixels = _blendgimp_bytes_from_gi(pixel_result)
    expected = read_width * read_height * 4
    if len(raw_pixels) != expected:
        raise RuntimeError(
            f"Unexpected layer byte count. Expected {expected}, got {len(raw_pixels)}"
        )
    return {
        "image_id": int(image_id), "layer_id": int(layer_id),
        "image_width": image_width, "image_height": image_height,
        "x": int(read_left), "y": int(read_top),
        "width": int(read_width), "height": int(read_height),
        "layer_offset_x": int(layer_offset_x), "layer_offset_y": int(layer_offset_y),
        "layer_width": int(layer_width), "layer_height": int(layer_height),
        "pixel_format": "R'G'B'A u8", "alpha": "straight",
        "origin": "top-left", "target_kind": target_kind, "byte_length": len(raw_pixels),
        "_binary_payload": raw_pixels,
    }


# -----------------------------------------------------------------------------
# Native GEGL damage tracking
# -----------------------------------------------------------------------------

def _blendgimp_union_rect(
    current,
    incoming
):
    if incoming is None:
        return current

    (
        x,
        y,
        width,
        height,
    ) = incoming

    if width <= 0 or height <= 0:
        return current

    if current is None:
        return (
            int(x),
            int(y),
            int(width),
            int(height),
        )

    (
        current_x,
        current_y,
        current_width,
        current_height,
    ) = current

    left = min(
        current_x,
        x
    )

    top = min(
        current_y,
        y
    )

    right = max(
        current_x + current_width,
        x + width
    )

    bottom = max(
        current_y + current_height,
        y + height
    )

    return (
        int(left),
        int(top),
        int(right - left),
        int(bottom - top),
    )


def _blendgimp_clip_rect_to_image(
    image,
    x,
    y,
    width,
    height
):
    image_width = int(
        image.get_width()
    )

    image_height = int(
        image.get_height()
    )

    left = max(
        0,
        int(x)
    )

    top = max(
        0,
        int(y)
    )

    right = min(
        image_width,
        int(x + width)
    )

    bottom = min(
        image_height,
        int(y + height)
    )

    if right <= left or bottom <= top:
        return None

    return (
        left,
        top,
        right - left,
        bottom - top,
    )


def _blendgimp_mark_damage(
    image_id,
    rectangle,
    full=False,
    reason="buffer"
):
    image_id = int(
        image_id
    )

    tracker = BLENDGIMP_DAMAGE_TRACKERS.get(
        image_id
    )

    if tracker is None:
        return

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        return

    if full:
        rectangle = (
            0,
            0,
            int(image.get_width()),
            int(image.get_height()),
        )

    if rectangle is None:
        return

    rectangle = _blendgimp_clip_rect_to_image(
        image,
        *rectangle
    )

    if rectangle is None:
        return

    tracker[
        "damage"
    ] = _blendgimp_union_rect(
        tracker.get(
            "damage"
        ),
        rectangle
    )

    tracker[
        "revision"
    ] = int(
        tracker.get(
            "revision",
            1
        )
    ) + 1

    tracker[
        "last_reason"
    ] = str(
        reason
    )


def _blendgimp_drawable_buffer_changed(
    buffer,
    rectangle,
    context
):
    """
    GEGL Buffer::changed callback.

    `rectangle` is in drawable-local GEGL coordinates. Convert it to image
    coordinates using the drawable offsets captured in mutable callback
    context.
    """

    if not context.get(
        "active",
        True
    ):
        return

    try:
        image_id = int(
            context[
                "image_id"
            ]
        )

        offset_x = int(
            context.get(
                "offset_x",
                0
            )
        )

        offset_y = int(
            context.get(
                "offset_y",
                0
            )
        )

        if rectangle is None:
            image = Gimp.Image.get_by_id(
                image_id
            )

            if image is None or not image.is_valid():
                return

            _blendgimp_mark_damage(
                image_id,
                (
                    0,
                    0,
                    int(image.get_width()),
                    int(image.get_height()),
                ),
                reason="buffer-full"
            )

            return

        rect_x = int(
            getattr(
                rectangle,
                "x",
                0
            )
        )

        rect_y = int(
            getattr(
                rectangle,
                "y",
                0
            )
        )

        rect_width = int(
            getattr(
                rectangle,
                "width",
                0
            )
        )

        rect_height = int(
            getattr(
                rectangle,
                "height",
                0
            )
        )

        _blendgimp_mark_damage(
            image_id,
            (
                offset_x + rect_x,
                offset_y + rect_y,
                rect_width,
                rect_height,
            ),
            reason="gegl-buffer"
        )

    except Exception as exc:
        log(
            "GEGL damage callback failed: "
            f"{exc}"
        )


def _blendgimp_layer_offsets(
    drawable
):
    try:
        offsets = drawable.get_offsets()

        if isinstance(
            offsets,
            tuple
        ) and len(offsets) >= 2:
            return (
                int(
                    offsets[-2]
                ),
                int(
                    offsets[-1]
                ),
            )

    except Exception:
        pass

    return (
        0,
        0,
    )


def _blendgimp_layer_structure_signature(
    image
):
    """
    Cheap non-pixel signature covering visual layer-stack changes that do not
    necessarily modify a drawable GEGL buffer: visibility, opacity, modes,
    offsets, ordering, masks, dimensions, and hierarchy.
    """

    signature = [
        "image",
        int(
            image.get_width()
        ),
        int(
            image.get_height()
        ),
    ]

    def append_layer(
        layer,
        parent_id
    ):
        layer_id = int(
            layer.get_id()
        )

        offset_x, offset_y = (
            _blendgimp_layer_offsets(
                layer
            )
        )

        mask_id = -1
        apply_mask = False
        show_mask = False

        try:
            mask = layer.get_mask()

            if (
                mask is not None
                and mask.is_valid()
            ):
                mask_id = int(
                    mask.get_id()
                )

                apply_mask = bool(
                    layer.get_apply_mask()
                )

                show_mask = bool(
                    layer.get_show_mask()
                )

        except Exception:
            pass

        try:
            composite_mode = int(
                layer.get_composite_mode()
            )
        except Exception:
            composite_mode = -1

        signature.extend(
            [
                "layer",
                layer_id,
                int(
                    parent_id
                ),
                int(
                    bool(
                        layer.is_group()
                    )
                ),
                int(
                    bool(
                        layer.get_visible()
                    )
                ),
                round(
                    float(
                        layer.get_opacity()
                    ),
                    5
                ),
                int(
                    layer.get_mode()
                ),
                composite_mode,
                offset_x,
                offset_y,
                int(
                    layer.get_width()
                ),
                int(
                    layer.get_height()
                ),
                mask_id,
                int(
                    apply_mask
                ),
                int(
                    show_mask
                ),
            ]
        )

        if layer.is_group():
            for child_item in layer.get_children():

                child_layer = Gimp.Layer.get_by_id(
                    int(
                        child_item.get_id()
                    )
                )

                if child_layer is not None:
                    append_layer(
                        child_layer,
                        layer_id
                    )

    for root_layer in image.get_layers():
        append_layer(
            root_layer,
            -1
        )

    return tuple(
        signature
    )


def _blendgimp_collect_watch_drawables(
    image
):
    """
    Yield leaf layers and layer masks that can emit real pixel-buffer damage.
    Group buffers are intentionally skipped to avoid duplicate child damage.
    """

    result = []

    def append_layer(
        layer
    ):
        if layer.is_group():

            for child_item in layer.get_children():

                child_layer = Gimp.Layer.get_by_id(
                    int(
                        child_item.get_id()
                    )
                )

                if child_layer is not None:
                    append_layer(
                        child_layer
                    )

            return

        result.append(
            (
                "layer",
                layer,
                _blendgimp_layer_offsets(
                    layer
                ),
            )
        )

        try:
            mask = layer.get_mask()

            if (
                mask is not None
                and mask.is_valid()
            ):

                result.append(
                    (
                        "mask",
                        mask,
                        _blendgimp_layer_offsets(
                            layer
                        ),
                    )
                )

        except Exception:
            pass

    for root_layer in image.get_layers():
        append_layer(
            root_layer
        )

    return result


def _blendgimp_ensure_damage_tracker(
    image
):
    image_id = int(
        image.get_id()
    )

    tracker = BLENDGIMP_DAMAGE_TRACKERS.get(
        image_id
    )

    if tracker is None:

        tracker = {
            "revision": 1,
            "reported_revision": 0,
            "damage": None,
            "watchers": {},
            "signal_ok": True,
            "signal_error": "",
            "structure_signature": None,
            "last_reason": "initial",
        }

        BLENDGIMP_DAMAGE_TRACKERS[
            image_id
        ] = tracker

    current_signature = (
        _blendgimp_layer_structure_signature(
            image
        )
    )

    previous_signature = tracker.get(
        "structure_signature"
    )

    if previous_signature is None:

        tracker[
            "structure_signature"
        ] = current_signature

    elif previous_signature != current_signature:

        tracker[
            "structure_signature"
        ] = current_signature

        _blendgimp_mark_damage(
            image_id,
            None,
            full=True,
            reason="layer-structure"
        )

    desired_keys = set()

    if tracker.get(
        "signal_ok",
        True
    ):

        for (
            kind,
            drawable,
            offsets,
        ) in _blendgimp_collect_watch_drawables(
            image
        ):

            drawable_id = int(
                drawable.get_id()
            )

            key = (
                str(
                    kind
                ),
                drawable_id,
            )

            desired_keys.add(
                key
            )

            existing = tracker[
                "watchers"
            ].get(
                key
            )

            offset_x, offset_y = (
                offsets
            )

            if existing is not None:

                existing[
                    "context"
                ][
                    "offset_x"
                ] = offset_x

                existing[
                    "context"
                ][
                    "offset_y"
                ] = offset_y

                continue

            try:

                buffer = drawable.get_buffer()

                if buffer is None:
                    continue

                callback_context = {
                    "active": True,
                    "image_id": image_id,
                    "drawable_id": drawable_id,
                    "kind": str(
                        kind
                    ),
                    "offset_x": offset_x,
                    "offset_y": offset_y,
                }

                handler_id = buffer.signal_connect(
                    "changed",
                    _blendgimp_drawable_buffer_changed,
                    callback_context
                )

                tracker[
                    "watchers"
                ][
                    key
                ] = {
                    "buffer": buffer,
                    "handler_id": int(
                        handler_id
                    ),
                    "context": callback_context,
                }

            except Exception as exc:

                tracker[
                    "signal_ok"
                ] = False

                tracker[
                    "signal_error"
                ] = str(
                    exc
                )

                log(
                    "GEGL Buffer::changed unavailable for "
                    f"image ID {image_id}: {exc}. "
                    "Falling back to thumbnail revision detection."
                )

                break

    # Mark stale callback contexts inactive. We intentionally keep the GObject
    # reference/handler safe instead of relying on disconnect behavior across
    # every PyGObject/GEGL build.
    for key, watcher in list(
        tracker[
            "watchers"
        ].items()
    ):

        if key not in desired_keys:

            watcher[
                "context"
            ][
                "active"
            ] = False

            tracker[
                "watchers"
            ].pop(
                key,
                None
            )

    return tracker


def _blendgimp_pending_damage(
    image_id
):
    tracker = BLENDGIMP_DAMAGE_TRACKERS.get(
        int(
            image_id
        )
    )

    if tracker is None:
        return None

    return tracker.get(
        "damage"
    )


def _blendgimp_clear_pending_damage(
    image_id
):
    tracker = BLENDGIMP_DAMAGE_TRACKERS.get(
        int(
            image_id
        )
    )

    if tracker is not None:
        tracker[
            "damage"
        ] = None


# -----------------------------------------------------------------------------
# Direct full-composite RGBA transport
# -----------------------------------------------------------------------------

def _blendgimp_bytes_from_gi(value):
    """
    MAIN THREAD ONLY.

    Normalize byte-array shapes PyGObject may return for introspectable GEGL
    methods into a normal Python bytes object.
    """

    if value is None:
        return b""

    if isinstance(value, bytes):
        return value

    if isinstance(value, bytearray):
        return bytes(value)

    if isinstance(value, memoryview):
        return value.tobytes()

    if isinstance(value, tuple):
        for part in value:
            if isinstance(
                part,
                (bytes, bytearray, memoryview)
            ):
                return _blendgimp_bytes_from_gi(part)

            if hasattr(part, "get_data"):
                try:
                    return _blendgimp_bytes_from_gi(
                        part.get_data()
                    )
                except Exception:
                    pass

    if hasattr(value, "get_data"):
        try:
            return _blendgimp_bytes_from_gi(
                value.get_data()
            )
        except Exception:
            pass

    try:
        return bytes(value)
    except Exception as exc:
        raise TypeError(
            "Could not convert GEGL pixel result to bytes: "
            f"{type(value).__name__}: {exc}"
        )


def _gimp_get_raw_composite_rgba(
    image
):
    """
    MAIN THREAD ONLY.

    Return (width, height, raw_rgba8_bytes) for the current visible composite.
    The user's original GIMP document is never flattened or modified.
    """

    if image is None or not image.is_valid():
        raise ValueError(
            "Cannot extract pixels from an invalid GIMP image"
        )

    width = int(
        image.get_width()
    )

    height = int(
        image.get_height()
    )

    if width <= 0 or height <= 0:
        raise RuntimeError(
            f"GIMP image has invalid dimensions {width}x{height}"
        )

    duplicate = None

    try:
        duplicate = image.duplicate()

        if duplicate is None or not duplicate.is_valid():
            raise RuntimeError(
                f"GIMP could not duplicate image ID {image.get_id()} "
                "for composite extraction"
            )

        merged = duplicate.merge_visible_layers(
            Gimp.MergeType.CLIP_TO_IMAGE
        )

        if merged is None or not merged.is_valid():
            raw_pixels = bytes(
                width
                * height
                * 4
            )

        else:
            buffer = merged.get_buffer()

            if buffer is None:
                raise RuntimeError(
                    "GIMP did not return a GEGL buffer for the "
                    "merged visible composite"
                )

            rectangle = Gegl.Rectangle.new(
                0,
                0,
                width,
                height,
            )

            pixel_result = buffer.get(
                rectangle,
                1.0,
                "R'G'B'A u8",
                Gegl.AbyssPolicy.NONE,
            )

            raw_pixels = _blendgimp_bytes_from_gi(
                pixel_result
            )

        expected_length = (
            width
            * height
            * 4
        )

        if len(
            raw_pixels
        ) != expected_length:
            raise RuntimeError(
                "Unexpected composite byte count. "
                f"Expected {expected_length}, got {len(raw_pixels)}"
            )

        return (
            width,
            height,
            raw_pixels,
        )

    finally:
        if (
            duplicate is not None
            and duplicate.is_valid()
        ):
            try:
                duplicate.delete()
            except Exception:
                log(
                    "Warning: could not delete temporary "
                    "pixel-extraction image duplicate"
                )


def _blendgimp_store_pixel_snapshot(
    image_id,
    width,
    height,
    raw_pixels
):
    BLENDGIMP_PIXEL_SNAPSHOTS[
        int(image_id)
    ] = {
        "width": int(width),
        "height": int(height),
        "pixels": bytes(raw_pixels),
    }


def _blendgimp_dirty_bbox(
    previous_pixels,
    current_pixels,
    width,
    height
):
    """
    Find the exact changed-pixel bounding rectangle.

    Coordinates use GIMP/GEGL convention:
        x grows left -> right
        y grows top -> bottom
    """

    if len(
        previous_pixels
    ) != len(
        current_pixels
    ):
        return (
            0,
            0,
            width,
            height,
        )

    if previous_pixels == current_pixels:
        return None

    row_bytes = (
        width
        * 4
    )

    previous = memoryview(
        previous_pixels
    )

    current = memoryview(
        current_pixels
    )

    min_x = width
    min_y = height
    max_x = -1
    max_y = -1

    for y in range(
        height
    ):
        row_start = (
            y
            * row_bytes
        )

        row_end = (
            row_start
            + row_bytes
        )

        old_row = previous[
            row_start:
            row_end
        ]

        new_row = current[
            row_start:
            row_end
        ]

        if old_row == new_row:
            continue

        min_y = min(
            min_y,
            y
        )

        max_y = max(
            max_y,
            y
        )

        first_x = None

        for x in range(
            width
        ):
            byte_index = (
                x
                * 4
            )

            if (
                old_row[
                    byte_index:
                    byte_index + 4
                ]
                !=
                new_row[
                    byte_index:
                    byte_index + 4
                ]
            ):
                first_x = x
                break

        last_x = None

        for x in range(
            width - 1,
            -1,
            -1
        ):
            byte_index = (
                x
                * 4
            )

            if (
                old_row[
                    byte_index:
                    byte_index + 4
                ]
                !=
                new_row[
                    byte_index:
                    byte_index + 4
                ]
            ):
                last_x = x
                break

        if first_x is not None:
            min_x = min(
                min_x,
                first_x
            )

        if last_x is not None:
            max_x = max(
                max_x,
                last_x
            )

    if (
        max_x < min_x
        or max_y < min_y
    ):
        return None

    return (
        min_x,
        min_y,
        max_x - min_x + 1,
        max_y - min_y + 1,
    )


def _blendgimp_extract_region_rgba(
    raw_pixels,
    image_width,
    x,
    y,
    region_width,
    region_height
):
    row_bytes = (
        image_width
        * 4
    )

    region_row_bytes = (
        region_width
        * 4
    )

    result = bytearray(
        region_row_bytes
        * region_height
    )

    for region_row in range(
        region_height
    ):
        source_y = (
            y
            + region_row
        )

        source_start = (
            source_y
            * row_bytes
            + x
            * 4
        )

        source_end = (
            source_start
            + region_row_bytes
        )

        destination_start = (
            region_row
            * region_row_bytes
        )

        result[
            destination_start:
            destination_start + region_row_bytes
        ] = raw_pixels[
            source_start:
            source_end
        ]

    return bytes(
        result
    )


def gimp_get_image_pixels_binary(
    image_id
):
    """
    MAIN THREAD ONLY.

    Full-image direct RGBA8 transfer using a binary payload following a small
    newline-delimited JSON header. This avoids base64 expansion and JSON pixel
    parsing while retaining the existing command socket.
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    (
        width,
        height,
        raw_pixels,
    ) = _gimp_get_raw_composite_rgba(
        image
    )

    _blendgimp_store_pixel_snapshot(
        image_id,
        width,
        height,
        raw_pixels
    )

    _blendgimp_clear_pending_damage(
        image_id
    )

    image_name = _blendgimp_image_name(image)

    return {
        "image_id": image_id,
        "sync_token": _blendgimp_composite_token(
            image_id
        ),
        "image_name": (
            ""
            if image_name is None
            else str(image_name)
        ),
        "width": width,
        "height": height,
        "channels": 4,
        "pixel_format": "R'G'B'A u8",
        "alpha": "straight",
        "origin": "top-left",
        "encoding": "binary",
        "transport": "direct-rgba-binary",
        "byte_length": len(
            raw_pixels
        ),
        "sha256": hashlib.sha256(
            raw_pixels
        ).hexdigest(),
        "_binary_payload": raw_pixels,
    }


def gimp_rebase_image_dirty_baseline(
    image_id
):
    """
    MAIN THREAD ONLY.

    Reset BlendGimp's visible-composite dirty baseline without returning the
    pixel payload to Blender.  The zero-layer case uses a synthetic transparent
    RGBA8 buffer, avoiding an unnecessary 4K GEGL render and 67 MB socket
    transfer after the final layer is deleted.
    """

    image_id = int(image_id)

    image = Gimp.Image.get_by_id(image_id)

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    width = int(image.get_width())
    height = int(image.get_height())

    try:
        layers = list(image.get_layers() or [])
    except Exception:
        layers = []

    if len(layers) == 0:
        raw_pixels = bytes(width * height * 4)
        source = "zero-layer-transparent"
    else:
        width, height, raw_pixels = _gimp_get_raw_composite_rgba(image)
        source = "rendered-composite"

    _blendgimp_store_pixel_snapshot(
        image_id,
        width,
        height,
        raw_pixels
    )

    _blendgimp_clear_pending_damage(image_id)

    return {
        "image_id": image_id,
        "sync_token": _blendgimp_composite_token(image_id),
        "width": width,
        "height": height,
        "channels": 4,
        "layer_count": len(layers),
        "rebased": True,
        "changed": False,
        "source": source,
        "byte_length": 0,
    }


def gimp_get_image_pixels(
    image_id
):
    """
    MAIN THREAD ONLY.

    Full-image direct RGBA transfer. This also establishes/refreshes the dirty
    rectangle baseline for later automatic partial updates.
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    (
        width,
        height,
        raw_pixels,
    ) = _gimp_get_raw_composite_rgba(
        image
    )

    _blendgimp_store_pixel_snapshot(
        image_id,
        width,
        height,
        raw_pixels
    )

    encoded_pixels = base64.b64encode(
        raw_pixels
    ).decode(
        "ascii"
    )

    image_name = _blendgimp_image_name(image)

    return {
        "image_id": image_id,
        "sync_token": _blendgimp_composite_token(
            image_id
        ),
        "image_name": (
            ""
            if image_name is None
            else str(image_name)
        ),
        "width": width,
        "height": height,
        "channels": 4,
        "pixel_format": "R'G'B'A u8",
        "alpha": "straight",
        "origin": "top-left",
        "encoding": "base64",
        "transport": "direct-rgba-json",
        "byte_length": len(
            raw_pixels
        ),
        "encoded_length": len(
            encoded_pixels
        ),
        "sha256": hashlib.sha256(
            raw_pixels
        ).hexdigest(),
        "pixels_b64": encoded_pixels,
    }


def gimp_get_image_dirty_pixels_binary(
    image_id,
    full_width_rows=False
):
    """
    MAIN THREAD ONLY.

    Hybrid dirty-region synchronization.

    If native GEGL damage supplied a rectangle, compare/transmit only that
    rectangle. If no native rectangle exists, render once and run the proven
    full-image pixel diff to discover the changed bounding box.

    This intentionally does NOT interpret "signal connected but no damage
    callback" as "nothing changed".
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    tracker = (
        _blendgimp_ensure_damage_tracker(
            image
        )
    )

    previous = (
        BLENDGIMP_PIXEL_SNAPSHOTS.get(
            image_id
        )
    )

    native_damage = (
        _blendgimp_pending_damage(
            image_id
        )
    )

    width = int(
        image.get_width()
    )

    height = int(
        image.get_height()
    )

    dimensions_changed = (
        previous is None
        or int(
            previous.get(
                "width",
                -1
            )
        ) != width
        or int(
            previous.get(
                "height",
                -1
            )
        ) != height
    )

    (
        current_width,
        current_height,
        current_pixels,
    ) = _gimp_get_raw_composite_rgba(
        image
    )

    width = current_width
    height = current_height

    damage_detector = (
        "gegl-damage"
        if (
            native_damage is not None
            and not dimensions_changed
        )
        else "pixel-diff"
    )

    common = {
        "image_id": image_id,
        "sync_token": _blendgimp_composite_token(
            image_id
        ),
        "image_name": _blendgimp_image_name(image),
        "width": width,
        "height": height,
        "channels": 4,
        "pixel_format": "R'G'B'A u8",
        "alpha": "straight",
        "origin": "top-left",
        "encoding": "binary",
        "transport": "dirty-rgba-binary",
        "damage_detector": damage_detector,
        "native_signal_connected": bool(
            tracker.get(
                "signal_ok",
                False
            )
        ),
    }

    if dimensions_changed:

        dirty_bbox = (
            0,
            0,
            width,
            height,
        )

        full_refresh = True

    elif native_damage is not None:

        dirty_bbox = (
            native_damage
        )

        full_refresh = (
            dirty_bbox
            == (
                0,
                0,
                width,
                height,
            )
        )

    else:

        # Critical reliability path for GIMP 3.2.4:
        # the GEGL signal may be connected but silent.
        dirty_bbox = _blendgimp_dirty_bbox(
            previous.get(
                "pixels",
                b""
            ),
            current_pixels,
            width,
            height,
        )

        full_refresh = False

    if dirty_bbox is None:

        _blendgimp_store_pixel_snapshot(
            image_id,
            width,
            height,
            current_pixels
        )

        _blendgimp_clear_pending_damage(
            image_id
        )

        return {
            **common,
            "changed": False,
            "full_refresh": False,
            "x": 0,
            "y": 0,
            "region_width": 0,
            "region_height": 0,
            "byte_length": 0,
            "_binary_payload": b"",
        }

    (
        x,
        y,
        region_width,
        region_height,
    ) = dirty_bbox

    current_region = (
        _blendgimp_extract_region_rgba(
            current_pixels,
            width,
            x,
            y,
            region_width,
            region_height,
        )
    )

    # Filter native structural/damage events that do not alter the visible
    # composite. When the full pixel-diff path produced the bbox, a visible
    # difference is already guaranteed.
    if (
        native_damage is not None
        and previous is not None
        and not dimensions_changed
    ):

        previous_region = (
            _blendgimp_extract_region_rgba(
                previous.get(
                    "pixels",
                    b""
                ),
                width,
                x,
                y,
                region_width,
                region_height,
            )
        )

        if previous_region == current_region:

            _blendgimp_store_pixel_snapshot(
                image_id,
                width,
                height,
                current_pixels
            )

            _blendgimp_clear_pending_damage(
                image_id
            )

            return {
                **common,
                "changed": False,
                "full_refresh": False,
                "x": int(
                    x
                ),
                "y": int(
                    y
                ),
                "region_width": int(
                    region_width
                ),
                "region_height": int(
                    region_height
                ),
                "byte_length": 0,
                "filtered_damage": True,
                "_binary_payload": b"",
            }

    # Texture Paint final commits can request a full-width row stripe.
    # This transfers more bytes than the minimal dirty rectangle, but allows
    # Blender to apply the result with one contiguous Image.pixels slice
    # assignment instead of hundreds of Python row assignments. On local IPC
    # that trade is substantially faster for 2K/4K interactive painting.
    if bool(full_width_rows) and region_width != width:
        x = 0
        region_width = width
        current_region = _blendgimp_extract_region_rgba(
            current_pixels,
            width,
            x,
            y,
            region_width,
            region_height,
        )

    _blendgimp_store_pixel_snapshot(
        image_id,
        width,
        height,
        current_pixels
    )

    _blendgimp_clear_pending_damage(
        image_id
    )

    full_byte_length = (
        width
        * height
        * 4
    )

    region_byte_length = len(
        current_region
    )

    return {
        **common,
        "changed": True,
        "full_refresh": bool(
            full_refresh
        ),
        "x": int(
            x
        ),
        "y": int(
            y
        ),
        "region_width": int(
            region_width
        ),
        "region_height": int(
            region_height
        ),
        "byte_length": region_byte_length,
        "full_byte_length": full_byte_length,
        "saved_bytes": max(
            0,
            full_byte_length
            - region_byte_length
        ),
        "full_width_rows": bool(full_width_rows),
        "sha256": hashlib.sha256(
            current_region
        ).hexdigest(),
        "_binary_payload": current_region,
    }


def gimp_get_image_dirty_pixels(
    image_id
):
    """
    MAIN THREAD ONLY.

    Compare the current visible composite to BlendGimp's previous full RGBA
    snapshot and return only the exact changed bounding rectangle.

    If no baseline exists (or image dimensions changed), the full image is
    returned once and becomes the new baseline.
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    (
        width,
        height,
        current_pixels,
    ) = _gimp_get_raw_composite_rgba(
        image
    )

    previous = BLENDGIMP_PIXEL_SNAPSHOTS.get(
        image_id
    )

    full_refresh = (
        previous is None
        or int(
            previous.get(
                "width",
                -1
            )
        ) != width
        or int(
            previous.get(
                "height",
                -1
            )
        ) != height
    )

    if full_refresh:
        dirty_bbox = (
            0,
            0,
            width,
            height,
        )

    else:
        dirty_bbox = _blendgimp_dirty_bbox(
            previous.get(
                "pixels",
                b""
            ),
            current_pixels,
            width,
            height,
        )

    _blendgimp_store_pixel_snapshot(
        image_id,
        width,
        height,
        current_pixels
    )

    image_name = _blendgimp_image_name(image)

    if dirty_bbox is None:
        return {
            "image_id": image_id,
            "sync_token": _blendgimp_composite_token(
                image_id
            ),
            "image_name": (
                ""
                if image_name is None
                else str(image_name)
            ),
            "width": width,
            "height": height,
            "channels": 4,
            "pixel_format": "R'G'B'A u8",
            "alpha": "straight",
            "origin": "top-left",
            "encoding": "base64",
            "transport": "dirty-rgba-json",
            "changed": False,
            "full_refresh": False,
            "x": 0,
            "y": 0,
            "region_width": 0,
            "region_height": 0,
            "byte_length": 0,
            "encoded_length": 0,
            "pixels_b64": "",
        }

    (
        x,
        y,
        region_width,
        region_height,
    ) = dirty_bbox

    region_pixels = _blendgimp_extract_region_rgba(
        current_pixels,
        width,
        x,
        y,
        region_width,
        region_height,
    )

    encoded_pixels = base64.b64encode(
        region_pixels
    ).decode(
        "ascii"
    )

    full_byte_length = (
        width
        * height
        * 4
    )

    region_byte_length = len(
        region_pixels
    )

    return {
        "image_id": image_id,
        "sync_token": _blendgimp_composite_token(
            image_id
        ),
        "image_name": (
            ""
            if image_name is None
            else str(image_name)
        ),
        "width": width,
        "height": height,
        "channels": 4,
        "pixel_format": "R'G'B'A u8",
        "alpha": "straight",
        "origin": "top-left",
        "encoding": "base64",
        "transport": "dirty-rgba-json",
        "changed": True,
        "full_refresh": bool(
            full_refresh
        ),
        "x": int(x),
        "y": int(y),
        "region_width": int(
            region_width
        ),
        "region_height": int(
            region_height
        ),
        "byte_length": region_byte_length,
        "full_byte_length": full_byte_length,
        "saved_bytes": max(
            0,
            full_byte_length
            - region_byte_length
        ),
        "encoded_length": len(
            encoded_pixels
        ),
        "sha256": hashlib.sha256(
            region_pixels
        ).hexdigest(),
        "pixels_b64": encoded_pixels,
    }


# -----------------------------------------------------------------------------
# Automatic texture-sync state tracking
# -----------------------------------------------------------------------------

def _gimp_visual_fingerprint(image):
    """
    MAIN THREAD ONLY.

    Compute a compact fingerprint of the current visible image composite.
    This does not modify GIMP's dirty flag and does not export a file.
    """

    thumbnail = image.get_thumbnail(
        BLENDGIMP_STATE_THUMBNAIL_SIZE,
        BLENDGIMP_STATE_THUMBNAIL_SIZE,
        Gimp.PixbufTransparency.KEEP_ALPHA,
    )

    if thumbnail is None:
        raise RuntimeError(
            f"GIMP could not create a state thumbnail for image ID {image.get_id()}"
        )

    pixels = thumbnail.get_pixels()

    try:
        pixel_bytes = bytes(pixels)
    except Exception:
        pixel_bytes = pixels.tobytes()

    digest = hashlib.sha256()

    metadata = (
        f"{thumbnail.get_width()}x{thumbnail.get_height()}|"
        f"{thumbnail.get_rowstride()}|"
        f"{thumbnail.get_n_channels()}|"
        f"{int(bool(thumbnail.get_has_alpha()))}|"
        f"{image.get_width()}x{image.get_height()}"
    ).encode("utf-8")

    digest.update(metadata)
    digest.update(pixel_bytes)

    return {
        "fingerprint": digest.hexdigest(),
        "thumbnail_width": int(thumbnail.get_width()),
        "thumbnail_height": int(thumbnail.get_height()),
    }


def gimp_get_image_state(image_id):
    """
    MAIN THREAD ONLY.

    Reliable hybrid change detector.

    The visible-composite thumbnail fingerprint is always checked because the
    GIMP 3.2.4 Python runtime can successfully connect to GEGL Buffer::changed
    without delivering paint callbacks to this persistent plug-in.

    GEGL damage revision is still included as a second signal. If it fires it
    can catch changes the thumbnail misses and later provide an exact dirty
    rectangle. If it stays silent, Auto Sync still works through the proven
    fingerprint + pixel-diff path.
    """

    image_id = int(
        image_id
    )

    image = Gimp.Image.get_by_id(
        image_id
    )

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    tracker = (
        _blendgimp_ensure_damage_tracker(
            image
        )
    )

    fingerprint_info = (
        _gimp_visual_fingerprint(
            image
        )
    )

    fingerprint = fingerprint_info[
        "fingerprint"
    ]

    native_revision = int(
        tracker.get(
            "revision",
            1
        )
    )

    previous = (
        BLENDGIMP_IMAGE_VISUAL_STATE.get(
            image_id
        )
    )

    if previous is None:

        fingerprint_changed = True
        native_changed = True
        revision = 1
        self_originated_suppressed = False

    else:

        fingerprint_changed = (
            previous.get(
                "fingerprint"
            )
            != fingerprint
        )

        native_changed = (
            int(
                previous.get(
                    "native_revision",
                    native_revision
                )
            )
            != native_revision
        )

        (
            fingerprint_changed,
            native_changed,
            self_originated_suppressed,
        ) = _blendgimp_filter_self_originated_state_change(
            image,
            image_id,
            fingerprint,
            native_revision,
            fingerprint_changed,
            native_changed,
        )

        previous = (
            BLENDGIMP_IMAGE_VISUAL_STATE.get(
                image_id
            )
            or previous
        )

        revision = int(
            previous.get(
                "revision",
                1
            )
        )

        if (
            fingerprint_changed
            or native_changed
        ):
            revision += 1

    changed = (
        previous is None
        or fingerprint_changed
        or native_changed
    )

    BLENDGIMP_IMAGE_VISUAL_STATE[
        image_id
    ] = {
        "fingerprint": fingerprint,
        "native_revision": native_revision,
        "revision": revision,
    }

    image_name = _blendgimp_image_name(image)

    pending_damage = tracker.get(
        "damage"
    )

    if pending_damage is None:

        damage_x = 0
        damage_y = 0
        damage_width = 0
        damage_height = 0

    else:

        (
            damage_x,
            damage_y,
            damage_width,
            damage_height,
        ) = pending_damage

    return {
        "image_id": image_id,
        "sync_token": _blendgimp_composite_token(
            image_id
        ),
        "image_name": (
            ""
            if image_name is None
            else str(image_name)
        ),
        "width": int(
            image.get_width()
        ),
        "height": int(
            image.get_height()
        ),
        "dirty": bool(
            image.is_dirty()
        ),
        "revision": revision,
        "changed": changed,
        "detector": "hybrid",
        "fingerprint_changed": bool(
            fingerprint_changed
        ),
        "native_changed": bool(
            native_changed
        ),
        "self_originated_suppressed": bool(
            self_originated_suppressed
        ),
        "native_signal_connected": bool(
            tracker.get(
                "signal_ok",
                False
            )
        ),
        "native_revision": native_revision,
        "damage_available": bool(
            pending_damage is not None
        ),
        "damage_x": int(
            damage_x
        ),
        "damage_y": int(
            damage_y
        ),
        "damage_width": int(
            damage_width
        ),
        "damage_height": int(
            damage_height
        ),
        "damage_reason": str(
            tracker.get(
                "last_reason",
                ""
            )
        ),
        "watcher_count": len(
            tracker.get(
                "watchers",
                {}
            )
        ),
        "signal_error": str(
            tracker.get(
                "signal_error",
                ""
            )
        ),
        "fingerprint": fingerprint,
        "thumbnail_width": fingerprint_info[
            "thumbnail_width"
        ],
        "thumbnail_height": fingerprint_info[
            "thumbnail_height"
        ],
    }


# -----------------------------------------------------------------------------
# Native XCF open/save transport
# -----------------------------------------------------------------------------

def gimp_open_xcf(input_path):
    """
    MAIN THREAD ONLY.

    Open a native XCF document inside the headless GIMP engine and return
    metadata required for Blender to adopt it as a BlendGimp texture.
    """

    requested_path = os.path.abspath(
        os.path.expanduser(str(input_path or "").strip())
    )

    if not requested_path:
        raise ValueError("OPEN_XCF requires a file path")

    if not requested_path.lower().endswith(".xcf"):
        raise ValueError("BlendGimp Open XCF only accepts .xcf files")

    if not os.path.isfile(requested_path):
        raise FileNotFoundError(
            f"XCF file does not exist: {requested_path}"
        )

    normalized_requested = os.path.normcase(requested_path)

    # Reuse an already-open document rather than silently loading a duplicate.
    for existing in Gimp.get_images():
        existing_path = _blendgimp_gfile_path(existing.get_xcf_file())
        if existing_path and os.path.normcase(os.path.abspath(existing_path)) == normalized_requested:
            image = existing
            already_open = True
            break
    else:
        input_file = Gio.File.new_for_path(requested_path)
        image = Gimp.file_load(
            Gimp.RunMode.NONINTERACTIVE,
            input_file,
        )
        already_open = False

    if image is None or not image.is_valid():
        raise RuntimeError(
            f"GIMP could not open XCF: {requested_path}"
        )

    image_id = int(image.get_id())

    # Native loaded filenames are authoritative for reopened documents.
    BLENDGIMP_IMAGE_NAMES.pop(image_id, None)

    xcf_path = _blendgimp_gfile_path(
        image.get_xcf_file()
    ) or requested_path

    return {
        "image_id": image_id,
        "sync_token": _blendgimp_composite_token(image_id),
        "image_name": str(_blendgimp_image_name(image) or ""),
        "path": xcf_path,
        "dirty": bool(image.is_dirty()),
        "width": int(image.get_width()),
        "height": int(image.get_height()),
        "already_open": bool(already_open),
    }


def gimp_save_image(image_id, output_path=None):
    """
    MAIN THREAD ONLY.

    Save one open GIMP image as native XCF so BlendGimp layers and all GIMP
    editability are preserved. If ``output_path`` is empty, save back to the
    image's existing XCF file.
    """

    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    requested_path = str(output_path or "").strip()

    if requested_path:
        requested_path = os.path.abspath(
            os.path.expanduser(requested_path)
        )
        if not requested_path.lower().endswith(".xcf"):
            requested_path += ".xcf"

        parent_dir = os.path.dirname(requested_path)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

        output_file = Gio.File.new_for_path(requested_path)
    else:
        output_file = image.get_xcf_file()
        if output_file is None:
            raise ValueError(
                "Image has no XCF save path; use Save As first"
            )

    success = Gimp.file_save(
        Gimp.RunMode.NONINTERACTIVE,
        image,
        output_file,
        None,
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not save image ID {image_id} as XCF"
        )

    # GIMP normally associates the XCF path after file_save(). Keep an
    # explicit fallback so future Save operations have a stable destination.
    if image.get_xcf_file() is None:
        try:
            image.set_file(output_file)
        except Exception:
            pass

    saved_path = _blendgimp_gfile_path(
        image.get_xcf_file() or output_file
    )

    return {
        "image_id": image_id,
        "sync_token": _blendgimp_composite_token(image_id),
        "image_name": str(_blendgimp_image_name(image) or ""),
        "path": saved_path,
        "dirty": bool(image.is_dirty()),
        "width": int(image.get_width()),
        "height": int(image.get_height()),
    }


# -----------------------------------------------------------------------------
# Composite export transport
# -----------------------------------------------------------------------------

def gimp_export_composite(image_id):
    """
    MAIN THREAD ONLY.

    Export the current visible GIMP image composite to BlendGimp's temporary
    cache as PNG. The GIMP image/layer structure is not flattened or modified.

    This is the first reliable full-image transport used by Stage 1. Later,
    direct pixel/shared-memory transport can replace it for high-frequency
    synchronization while this remains a useful fallback/debug path.
    """

    image_id = int(image_id)
    image = Gimp.Image.get_by_id(image_id)

    if image is None or not image.is_valid():
        raise ValueError(
            f"Image ID {image_id} is not a valid open GIMP image"
        )

    cache_dir = os.path.join(
        tempfile.gettempdir(),
        "BlendGimp",
        "cache",
    )

    os.makedirs(
        cache_dir,
        exist_ok=True,
    )

    sync_token = _blendgimp_composite_token(
        image_id
    )

    output_path = os.path.join(
        cache_dir,
        f"blendgimp_{sync_token}.png",
    )

    output_file = Gio.File.new_for_path(
        output_path
    )

    success = Gimp.file_save(
        Gimp.RunMode.NONINTERACTIVE,
        image,
        output_file,
        None,
    )

    if not success:
        raise RuntimeError(
            f"GIMP could not export image ID {image_id} to PNG"
        )

    if not os.path.isfile(output_path):
        raise RuntimeError(
            "GIMP reported a successful export but the cache file was not created"
        )

    stat = os.stat(output_path)
    image_name = _blendgimp_image_name(image)

    return {
        "image_id": image_id,
        "sync_token": sync_token,
        "image_name": "" if image_name is None else str(image_name),
        "width": int(image.get_width()),
        "height": int(image.get_height()),
        "format": "PNG",
        "transport": "file",
        "path": os.path.abspath(output_path),
        "file_size": int(stat.st_size),
        "mtime_ns": int(stat.st_mtime_ns),
    }


# -----------------------------------------------------------------------------
# IPC server
# -----------------------------------------------------------------------------

class BlendGimpIPCServer:
    """Newline-delimited JSON server used by the Blender extension."""

    def __init__(self, dispatcher, gimp_version):
        self.dispatcher = dispatcher
        self.gimp_version = gimp_version

        self._stop_event = threading.Event()
        self._thread = None
        self._server_socket = None
        self._shutdown_scheduled = False

    def start(self):
        if self._thread is not None and self._thread.is_alive():
            return

        self._thread = threading.Thread(
            target=self._server_loop,
            name="BlendGimpIPCServer",
            daemon=True,
        )
        self._thread.start()

    def stop(self):
        self._stop_event.set()

        server_socket = self._server_socket
        self._server_socket = None

        if server_socket is not None:
            try:
                server_socket.close()
            except OSError:
                pass

    def _server_loop(self):
        log(f"Starting server on {HOST}:{PORT}")

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
                self._server_socket = server

                server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                server.bind((HOST, PORT))
                server.listen(1)
                server.settimeout(0.5)

                log(f"Server listening on {HOST}:{PORT}")

                while not self._stop_event.is_set():
                    try:
                        client, address = server.accept()
                    except socket.timeout:
                        continue
                    except OSError:
                        if self._stop_event.is_set():
                            break
                        raise

                    log(f"Blender connected from {address[0]}:{address[1]}")

                    try:
                        with client:
                            client.settimeout(0.5)
                            self._handle_client(client)
                    except Exception:
                        log("Client connection error:\n" + traceback.format_exc())
                    finally:

                        try:
                            closed = self.dispatcher.call(
                                gimp_close_all_direct_paint_strokes,
                                timeout=5.0,
                            )

                            if closed:
                                log(
                                    "Closed "
                                    f"{closed} active direct paint "
                                    "stroke(s) after disconnect"
                                )

                        except Exception as exc:
                            log(
                                "Direct paint disconnect cleanup failed: "
                                f"{exc}"
                            )

                        log("Blender disconnected")

        except Exception:
            if not self._stop_event.is_set():
                log("IPC server failed:\n" + traceback.format_exc())
        finally:
            self._server_socket = None
            log("Server stopped")

    def _handle_client(self, client):
        """
        Receive newline-delimited JSON commands.

        Commands may optionally declare:
            binary_payload = true
            binary_length  = N

        In that case exactly N raw bytes immediately follow the JSON newline
        and are attached internally as `_binary_payload` before dispatch.
        """

        buffer = b""
        pending_message = None
        pending_length = 0

        while not self._stop_event.is_set():

            try:
                chunk = client.recv(
                    65536
                )
            except socket.timeout:
                continue

            if not chunk:
                return

            buffer += chunk

            while True:

                # ------------------------------------------------------------
                # Complete an inbound raw binary frame first.
                # ------------------------------------------------------------

                if pending_message is not None:

                    if len(
                        buffer
                    ) < pending_length:
                        break

                    binary_payload = buffer[
                        :pending_length
                    ]

                    buffer = buffer[
                        pending_length:
                    ]

                    message = pending_message

                    pending_message = None
                    pending_length = 0

                    message[
                        "_binary_payload"
                    ] = binary_payload

                    response = self._dispatch_message(
                        message
                    )

                    self._send_response(
                        client,
                        response
                    )

                    continue

                # ------------------------------------------------------------
                # Otherwise read one JSON command header.
                # ------------------------------------------------------------

                if b"\n" not in buffer:
                    break

                raw_line, buffer = buffer.split(
                    b"\n",
                    1
                )

                raw_line = raw_line.strip()

                if not raw_line:
                    continue

                try:
                    message = json.loads(
                        raw_line.decode(
                            "utf-8"
                        )
                    )
                except Exception as exc:
                    self._send_json(
                        client,
                        {
                            "type": "ERROR",
                            "ok": False,
                            "error": f"Invalid JSON: {exc}",
                        },
                    )
                    continue

                if message.get(
                    "binary_payload",
                    False
                ):

                    try:
                        binary_length = int(
                            message.get(
                                "binary_length",
                                0
                            )
                        )
                    except Exception:
                        binary_length = -1

                    if binary_length < 0:
                        self._send_json(
                            client,
                            {
                                "type": "ERROR",
                                "ok": False,
                                "error": (
                                    "Invalid binary payload length"
                                ),
                            },
                        )
                        continue

                    pending_message = message
                    pending_length = binary_length

                    # A zero-length binary request can dispatch immediately.
                    if pending_length == 0:

                        message[
                            "_binary_payload"
                        ] = b""

                        pending_message = None

                        response = (
                            self._dispatch_message(
                                message
                            )
                        )

                        self._send_response(
                            client,
                            response
                        )

                    continue

                response = self._dispatch_message(
                    message
                )

                self._send_response(
                    client,
                    response
                )

    def _dispatch_message(self, message):
        if not isinstance(message, dict):
            return {
                "type": "ERROR",
                "ok": False,
                "error": "Message must be a JSON object",
            }

        # Accept both names while the protocol is still young. The currently
        # used protocol sends the command in `type`.
        message_type = message.get("type") or message.get("command")

        if not isinstance(message_type, str) or not message_type:
            return self._error_response(
                message,
                command=None,
                error="Missing message type",
            )

        message_type = message_type.upper()

        # GET_IMAGE_STATE is intentionally quiet because Auto Sync polls it
        # frequently. Actual revision changes are logged below.
        if message_type != "GET_IMAGE_STATE":
            log(f"Received message: {message_type}")

        if message_type == "HELLO":
            response = {
                "type": "READY",
                "ok": True,
                "protocol": PROTOCOL_VERSION,
                "server": "BlendGimp-GIMP",
                "blendgimp_version": BLENDGIMP_VERSION,
                "gimp_version": self.gimp_version,
            }
            self._copy_request_id(message, response)
            log("Sent READY")
            return response

        if message_type == "PING":
            response = {
                "type": "PONG",
                "ok": True,
            }
            self._copy_request_id(message, response)
            log("Sent PONG")
            return response

        if message_type == "STATUS":
            response = {
                "type": "STATUS",
                "ok": True,
                "status": "READY",
                "protocol": PROTOCOL_VERSION,
                "blendgimp_version": BLENDGIMP_VERSION,
                "gimp_version": self.gimp_version,
            }
            self._copy_request_id(message, response)
            log("Sent STATUS")
            return response

        if message_type == "SHUTDOWN_ENGINE":
            force = bool(
                message.get(
                    "force",
                    False
                )
            )

            try:
                shutdown_state = self.dispatcher.call(
                    gimp_get_shutdown_state,
                    timeout=5.0,
                )

                dirty_image_count = int(
                    shutdown_state.get(
                        "dirty_image_count",
                        0
                    )
                )

                if dirty_image_count and not force:
                    response = {
                        "type": "ENGINE_SHUTDOWN_REFUSED",
                        "ok": False,
                        "error": (
                            "GIMP has unsaved image changes; "
                            "save or close them before stopping the engine"
                        ),
                        **shutdown_state,
                    }
                    self._copy_request_id(message, response)
                    log(
                        "Graceful shutdown refused: "
                        f"{dirty_image_count} dirty image(s)"
                    )
                    return response

                response = {
                    "type": "ENGINE_SHUTDOWN_ACCEPTED",
                    "ok": True,
                    **shutdown_state,
                    "force": force,
                    "discarded_dirty_image_count": (
                        dirty_image_count if force else 0
                    ),
                    "_shutdown_after_response": True,
                    "_shutdown_force": force,
                }
                self._copy_request_id(message, response)
                if force:
                    log(
                        "Forced GIMP shutdown accepted; "
                        f"discarding {dirty_image_count} dirty image(s)"
                    )
                else:
                    log("Graceful GIMP shutdown accepted")
                return response

            except Exception as exc:
                log(f"SHUTDOWN_ENGINE failed: {exc}")
                return self._error_response(
                    message,
                    command="SHUTDOWN_ENGINE",
                    error=str(exc),
                )

        if message_type == "CREATE_IMAGE":
            log("CREATE_IMAGE received")

            try:
                result = self.dispatcher.call(
                    gimp_create_image,
                    message.get("name", "BlendGimp Texture"),
                    message.get("width"),
                    message.get("height"),
                    message.get("format", "RGBA"),
                    message.get("background", "TRANSPARENT"),
                    message.get(
                        "background_color",
                        [0.0, 0.0, 0.0, 1.0],
                    ),
                    message.get("layer_name", "BaseColor"),
                    timeout=30.0,
                )

                response = {
                    "type": "IMAGE_CREATED",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)

                log(
                    "IMAGE_CREATED "
                    f"image ID {result['image_id']} "
                    f"layer ID {result['layer_id']} "
                    f"{result['width']}x{result['height']} "
                    f"{result['format']}"
                )
                return response

            except Exception as exc:
                log(f"CREATE_IMAGE failed: {exc}")
                return self._error_response(
                    message,
                    command="CREATE_IMAGE",
                    error=str(exc),
                )

        if message_type == "OPEN_XCF":
            log("OPEN_XCF received")

            try:
                result = self.dispatcher.call(
                    gimp_open_xcf,
                    message.get("path", ""),
                    timeout=60.0,
                )

                response = {
                    "type": "XCF_OPENED",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)

                log(
                    f"OPEN_XCF image ID {result['image_id']} <- "
                    f"{result.get('path', '')} "
                    f"already_open={result.get('already_open', False)}"
                )
                return response

            except Exception as exc:
                log(f"OPEN_XCF failed: {exc}")
                return self._error_response(
                    message,
                    command="OPEN_XCF",
                    error=str(exc),
                )

        if message_type == "SAVE_IMAGE":
            log("SAVE_IMAGE received")

            if "image_id" not in message:
                return self._error_response(
                    message,
                    command="SAVE_IMAGE",
                    error="SAVE_IMAGE requires image_id",
                )

            try:
                image_id = int(message["image_id"])
                result = self.dispatcher.call(
                    gimp_save_image,
                    image_id,
                    message.get("path", ""),
                    timeout=60.0,
                )

                response = {
                    "type": "IMAGE_SAVED",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)

                log(
                    f"SAVE_IMAGE image ID {image_id} -> "
                    f"{result.get('path', '')} "
                    f"dirty={result.get('dirty', False)}"
                )
                return response

            except Exception as exc:
                log(f"SAVE_IMAGE failed: {exc}")
                return self._error_response(
                    message,
                    command="SAVE_IMAGE",
                    error=str(exc),
                )

        if message_type == "GET_IMAGES":
            log("GET_IMAGES received")

            try:
                images = self.dispatcher.call(
                    gimp_get_images_snapshot,
                    timeout=5.0,
                )

                response = {
                    "type": "IMAGES",
                    "ok": True,
                    "images": images,
                }
                self._copy_request_id(message, response)

                log(f"GET_IMAGES returned {len(images)} image(s)")
                return response

            except Exception as exc:
                log(f"GET_IMAGES failed: {exc}")
                return self._error_response(
                    message,
                    command="GET_IMAGES",
                    error=str(exc),
                )


        if message_type == "GET_IMAGE_LAYERS":
            log("GET_IMAGE_LAYERS received")

            if "image_id" not in message:
                return self._error_response(
                    message,
                    command="GET_IMAGE_LAYERS",
                    error="GET_IMAGE_LAYERS requires image_id",
                )

            try:
                image_id = int(message["image_id"])

            except (TypeError, ValueError):
                return self._error_response(
                    message,
                    command="GET_IMAGE_LAYERS",
                    error="image_id must be an integer",
                )

            try:
                snapshot = self.dispatcher.call(
                    gimp_get_image_layers_snapshot,
                    image_id,
                    timeout=5.0,
                )

                response = {
                    "type": "IMAGE_LAYERS",
                    "ok": True,
                    **snapshot,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "GET_IMAGE_LAYERS returned "
                    f"{snapshot['layer_count']} layer(s) "
                    f"for image ID {image_id}"
                )

                return response

            except Exception as exc:
                log(
                    "GET_IMAGE_LAYERS failed "
                    f"for image ID {image_id}: {exc}"
                )

                return self._error_response(
                    message,
                    command="GET_IMAGE_LAYERS",
                    error=str(exc),
                )


        if message_type == "SET_ACTIVE_LAYER":
            log("SET_ACTIVE_LAYER received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])

            except KeyError as exc:
                return self._error_response(
                    message,
                    command="SET_ACTIVE_LAYER",
                    error=f"Missing required field: {exc.args[0]}",
                )

            except (TypeError, ValueError):
                return self._error_response(
                    message,
                    command="SET_ACTIVE_LAYER",
                    error="image_id and layer_id must be integers",
                )

            try:
                result = self.dispatcher.call(
                    gimp_set_active_layer,
                    image_id,
                    layer_id,
                    timeout=5.0,
                )

                response = {
                    "type": "ACTIVE_LAYER_SET",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"SET_ACTIVE_LAYER selected layer ID {layer_id} "
                    f"in image ID {image_id}"
                )

                return response

            except Exception as exc:
                log(
                    f"SET_ACTIVE_LAYER failed for layer ID {layer_id}: {exc}"
                )

                return self._error_response(
                    message,
                    command="SET_ACTIVE_LAYER",
                    error=str(exc),
                )

        if message_type == "SET_LAYER_VISIBILITY":
            log("SET_LAYER_VISIBILITY received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])

                if "visible" not in message:
                    raise KeyError("visible")

                visible_value = message["visible"]

                if not isinstance(visible_value, bool):
                    raise TypeError(
                        "visible must be a JSON boolean"
                    )

            except KeyError as exc:
                return self._error_response(
                    message,
                    command="SET_LAYER_VISIBILITY",
                    error=f"Missing required field: {exc.args[0]}",
                )

            except (TypeError, ValueError) as exc:
                return self._error_response(
                    message,
                    command="SET_LAYER_VISIBILITY",
                    error=str(exc),
                )

            try:
                result = self.dispatcher.call(
                    gimp_set_layer_visibility,
                    image_id,
                    layer_id,
                    visible_value,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_VISIBILITY_SET",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"SET_LAYER_VISIBILITY layer ID {layer_id} "
                    f"visible={result['visible']}"
                )

                return response

            except Exception as exc:
                log(
                    f"SET_LAYER_VISIBILITY failed for layer ID {layer_id}: {exc}"
                )

                return self._error_response(
                    message,
                    command="SET_LAYER_VISIBILITY",
                    error=str(exc),
                )

        if message_type == "SET_LAYER_OPACITY":
            log("SET_LAYER_OPACITY received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                opacity = float(message["opacity"])

            except KeyError as exc:
                return self._error_response(
                    message,
                    command="SET_LAYER_OPACITY",
                    error=f"Missing required field: {exc.args[0]}",
                )

            except (TypeError, ValueError):
                return self._error_response(
                    message,
                    command="SET_LAYER_OPACITY",
                    error="image_id/layer_id must be integers and opacity must be numeric",
                )

            try:
                result = self.dispatcher.call(
                    gimp_set_layer_opacity,
                    image_id,
                    layer_id,
                    opacity,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_OPACITY_SET",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"SET_LAYER_OPACITY layer ID {layer_id} "
                    f"opacity={result['opacity']:.1f}"
                )

                return response

            except Exception as exc:
                log(
                    f"SET_LAYER_OPACITY failed for layer ID {layer_id}: {exc}"
                )

                return self._error_response(
                    message,
                    command="SET_LAYER_OPACITY",
                    error=str(exc),
                )


        if message_type == "ADD_LAYER_MASK":
            log("ADD_LAYER_MASK received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                mask_type = str(message.get("mask_type", "WHITE"))
                result = self.dispatcher.call(
                    gimp_add_layer_mask, image_id, layer_id, mask_type, timeout=5.0
                )
                response = {"type": "LAYER_MASK_ADDED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(f"ADD_LAYER_MASK layer ID {layer_id} mask ID {result['mask_id']} type={result['mask_type']}")
                return response
            except Exception as exc:
                log(f"ADD_LAYER_MASK failed: {exc}")
                return self._error_response(message, command="ADD_LAYER_MASK", error=str(exc))

        if message_type == "SET_LAYER_MASK_EDIT":
            log("SET_LAYER_MASK_EDIT received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                edit_mask = bool(message["edit_mask"])
                result = self.dispatcher.call(
                    gimp_set_layer_mask_edit, image_id, layer_id, edit_mask, timeout=5.0
                )
                response = {"type": "LAYER_MASK_EDIT_SET", "ok": True, **result}
                self._copy_request_id(message, response)
                log(f"SET_LAYER_MASK_EDIT layer ID {layer_id} target={result['target_kind']}")
                return response
            except Exception as exc:
                log(f"SET_LAYER_MASK_EDIT failed: {exc}")
                return self._error_response(message, command="SET_LAYER_MASK_EDIT", error=str(exc))

        if message_type == "SET_LAYER_MASK_APPLY":
            log("SET_LAYER_MASK_APPLY received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                apply_mask = bool(message["apply_mask"])
                result = self.dispatcher.call(
                    gimp_set_layer_mask_apply, image_id, layer_id, apply_mask, timeout=5.0
                )
                response = {"type": "LAYER_MASK_APPLY_SET", "ok": True, **result}
                self._copy_request_id(message, response)
                return response
            except Exception as exc:
                log(f"SET_LAYER_MASK_APPLY failed: {exc}")
                return self._error_response(message, command="SET_LAYER_MASK_APPLY", error=str(exc))

        if message_type == "SET_LAYER_MASK_SHOW":
            log("SET_LAYER_MASK_SHOW received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                show_mask = bool(message["show_mask"])
                result = self.dispatcher.call(
                    gimp_set_layer_mask_show, image_id, layer_id, show_mask, timeout=5.0
                )
                response = {"type": "LAYER_MASK_SHOW_SET", "ok": True, **result}
                self._copy_request_id(message, response)
                return response
            except Exception as exc:
                log(f"SET_LAYER_MASK_SHOW failed: {exc}")
                return self._error_response(message, command="SET_LAYER_MASK_SHOW", error=str(exc))

        if message_type == "REMOVE_LAYER_MASK":
            log("REMOVE_LAYER_MASK received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                apply_mask = bool(message.get("apply", False))
                result = self.dispatcher.call(
                    gimp_remove_layer_mask, image_id, layer_id, apply_mask, timeout=5.0
                )
                response = {"type": "LAYER_MASK_REMOVED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(f"REMOVE_LAYER_MASK layer ID {layer_id} applied={bool(apply_mask)}")
                return response
            except Exception as exc:
                log(f"REMOVE_LAYER_MASK failed: {exc}")
                return self._error_response(message, command="REMOVE_LAYER_MASK", error=str(exc))

        if message_type == "ADD_LAYER":
            log("ADD_LAYER received")

            try:
                image_id = int(message["image_id"])
                name = str(message.get("name", "New Layer"))

                result = self.dispatcher.call(
                    gimp_add_layer,
                    image_id,
                    name,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_ADDED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"ADD_LAYER created layer ID {result['layer_id']} "
                    f"name={result['name']}"
                )

                return response

            except Exception as exc:
                log(f"ADD_LAYER failed: {exc}")

                return self._error_response(
                    message,
                    command="ADD_LAYER",
                    error=str(exc),
                )

        if message_type == "DELETE_LAYER":
            log("DELETE_LAYER received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])

                result = self.dispatcher.call(
                    gimp_delete_layer,
                    image_id,
                    layer_id,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_DELETED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"DELETE_LAYER deleted layer ID {layer_id}"
                )

                return response

            except Exception as exc:
                log(f"DELETE_LAYER failed: {exc}")

                return self._error_response(
                    message,
                    command="DELETE_LAYER",
                    error=str(exc),
                )

        if message_type == "RENAME_LAYER":
            log("RENAME_LAYER received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                name = str(message["name"])

                result = self.dispatcher.call(
                    gimp_rename_layer,
                    image_id,
                    layer_id,
                    name,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_RENAMED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"RENAME_LAYER layer ID {layer_id} "
                    f"name={result['name']}"
                )

                return response

            except Exception as exc:
                log(f"RENAME_LAYER failed: {exc}")

                return self._error_response(
                    message,
                    command="RENAME_LAYER",
                    error=str(exc),
                )

        if message_type == "DUPLICATE_LAYER":
            log("DUPLICATE_LAYER received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])

                result = self.dispatcher.call(
                    gimp_duplicate_layer,
                    image_id,
                    layer_id,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_DUPLICATED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"DUPLICATE_LAYER copied layer ID {layer_id} "
                    f"to new layer ID {result['layer_id']}"
                )

                return response

            except Exception as exc:
                log(f"DUPLICATE_LAYER failed: {exc}")

                return self._error_response(
                    message,
                    command="DUPLICATE_LAYER",
                    error=str(exc),
                )

        if message_type == "REORDER_LAYER":
            log("REORDER_LAYER received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                direction = str(message["direction"]).upper()

                result = self.dispatcher.call(
                    gimp_reorder_layer,
                    image_id,
                    layer_id,
                    direction,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_REORDERED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"REORDER_LAYER moved layer ID {layer_id} "
                    f"{direction.lower()} to position {result['position']}"
                )

                return response

            except Exception as exc:
                log(f"REORDER_LAYER failed: {exc}")

                return self._error_response(
                    message,
                    command="REORDER_LAYER",
                    error=str(exc),
                )

        if message_type == "MOVE_LAYER":
            log("MOVE_LAYER received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])

                parent_id = message.get(
                    "parent_id",
                    None
                )

                if parent_id is not None:
                    parent_id = int(parent_id)

                result = self.dispatcher.call(
                    gimp_move_layer_to_parent,
                    image_id,
                    layer_id,
                    parent_id,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_MOVED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"MOVE_LAYER moved layer ID {layer_id} "
                    f"to parent {result['parent_id']}"
                )

                return response

            except Exception as exc:
                log(f"MOVE_LAYER failed: {exc}")

                return self._error_response(
                    message,
                    command="MOVE_LAYER",
                    error=str(exc),
                )


        if message_type == "CREATE_GROUP":
            log("CREATE_GROUP received")

            try:
                image_id = int(message["image_id"])
                name = str(
                    message.get(
                        "name",
                        "Layer Group"
                    )
                )

                result = self.dispatcher.call(
                    gimp_create_group,
                    image_id,
                    name,
                    timeout=5.0,
                )

                response = {
                    "type": "GROUP_CREATED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"CREATE_GROUP created group ID {result['layer_id']} "
                    f"name={result['name']}"
                )

                return response

            except Exception as exc:
                log(
                    f"CREATE_GROUP failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="CREATE_GROUP",
                    error=str(exc),
                )

        if message_type == "MERGE_LAYER_DOWN":
            log("MERGE_LAYER_DOWN received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])

                result = self.dispatcher.call(
                    gimp_merge_layer_down,
                    image_id,
                    layer_id,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_MERGED_DOWN",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"MERGE_LAYER_DOWN merged source layer ID {layer_id} "
                    f"into resulting layer ID {result['layer_id']}"
                )

                return response

            except Exception as exc:
                log(
                    f"MERGE_LAYER_DOWN failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="MERGE_LAYER_DOWN",
                    error=str(exc),
                )

        if message_type == "MERGE_VISIBLE_LAYERS":
            log("MERGE_VISIBLE_LAYERS received")
            try:
                image_id = int(message["image_id"])
                result = self.dispatcher.call(
                    gimp_merge_visible_layers, image_id, timeout=5.0
                )
                response = {"type": "VISIBLE_LAYERS_MERGED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(f"MERGE_VISIBLE_LAYERS image ID {image_id} -> layer ID {result['layer_id']}")
                return response
            except Exception as exc:
                log(f"MERGE_VISIBLE_LAYERS failed: {exc}")
                return self._error_response(message, command="MERGE_VISIBLE_LAYERS", error=str(exc))

        if message_type == "FLATTEN_IMAGE":
            log("FLATTEN_IMAGE received")
            try:
                image_id = int(message["image_id"])
                result = self.dispatcher.call(
                    gimp_flatten_image, image_id, timeout=5.0
                )
                response = {"type": "IMAGE_FLATTENED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(f"FLATTEN_IMAGE image ID {image_id} -> layer ID {result['layer_id']}")
                return response
            except Exception as exc:
                log(f"FLATTEN_IMAGE failed: {exc}")
                return self._error_response(message, command="FLATTEN_IMAGE", error=str(exc))

        if message_type == "DUPLICATE_GROUP":
            log("DUPLICATE_GROUP received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                result = self.dispatcher.call(
                    gimp_duplicate_group, image_id, layer_id, timeout=5.0
                )
                response = {"type": "GROUP_DUPLICATED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(f"DUPLICATE_GROUP group ID {layer_id} -> group ID {result['layer_id']}")
                return response
            except Exception as exc:
                log(f"DUPLICATE_GROUP failed: {exc}")
                return self._error_response(message, command="DUPLICATE_GROUP", error=str(exc))

        if message_type == "SET_LAYER_COLOR_TAG":
            log("SET_LAYER_COLOR_TAG received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                color_tag = str(message.get("color_tag", "NONE"))
                result = self.dispatcher.call(
                    gimp_set_layer_color_tag, image_id, layer_id, color_tag, timeout=5.0
                )
                response = {"type": "LAYER_COLOR_TAG_SET", "ok": True, **result}
                self._copy_request_id(message, response)
                log(f"SET_LAYER_COLOR_TAG layer ID {layer_id} tag={result['color_tag']}")
                return response
            except Exception as exc:
                log(f"SET_LAYER_COLOR_TAG failed: {exc}")
                return self._error_response(message, command="SET_LAYER_COLOR_TAG", error=str(exc))


        if message_type == "GET_SELECTION_STATE":
            try:
                image_id = int(message["image_id"])
                result = self.dispatcher.call(gimp_get_selection_state, image_id, timeout=5.0)
                response = {"type": "SELECTION_STATE", "ok": True, **result}
                self._copy_request_id(message, response)
                return response
            except Exception as exc:
                log(f"GET_SELECTION_STATE failed: {exc}")
                return self._error_response(message, command="GET_SELECTION_STATE", error=str(exc))

        if message_type in {"SELECT_RECTANGLE", "SELECT_ELLIPSE"}:
            log(f"{message_type} received")
            try:
                image_id = int(message["image_id"])
                x = float(message["x"])
                y = float(message["y"])
                width = float(message["width"])
                height = float(message["height"])
                operation = str(message.get("operation", "REPLACE"))
                func = gimp_select_rectangle if message_type == "SELECT_RECTANGLE" else gimp_select_ellipse
                result = self.dispatcher.call(
                    func, image_id, x, y, width, height, operation, timeout=5.0
                )
                response = {"type": "SELECTION_CHANGED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(
                    f"{message_type} image ID {image_id} operation={result.get('operation', operation)} "
                    f"bounds={result['x1']},{result['y1']}..{result['x2']},{result['y2']}"
                )
                return response
            except Exception as exc:
                log(f"{message_type} failed: {exc}")
                return self._error_response(message, command=message_type, error=str(exc))

        if message_type == "SELECT_POLYGON":
            log("SELECT_POLYGON received")
            try:
                image_id = int(message["image_id"])
                points = message.get("points", [])
                operation = str(message.get("operation", "REPLACE"))
                result = self.dispatcher.call(
                    gimp_select_polygon, image_id, points, operation, timeout=5.0
                )
                response = {"type": "SELECTION_CHANGED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(
                    f"SELECT_POLYGON image ID {image_id} operation={result.get('operation', operation)} "
                    f"points={len(points)//2} active={result['active']}"
                )
                return response
            except Exception as exc:
                log(f"SELECT_POLYGON failed: {exc}")
                return self._error_response(message, command="SELECT_POLYGON", error=str(exc))

        if message_type in {"SELECT_FUZZY", "SELECT_BY_COLOR"}:
            log(f"{message_type} received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                x = float(message["x"])
                y = float(message["y"])
                operation = str(message.get("operation", "REPLACE"))
                threshold = float(message.get("threshold", 0.15))
                sample_merged = bool(message.get("sample_merged", False))
                sample_transparent = bool(message.get("sample_transparent", True))
                func = gimp_select_fuzzy if message_type == "SELECT_FUZZY" else gimp_select_by_color
                result = self.dispatcher.call(
                    func,
                    image_id,
                    layer_id,
                    x,
                    y,
                    operation,
                    threshold,
                    sample_merged,
                    sample_transparent,
                    timeout=15.0,
                )
                response = {"type": "SELECTION_CHANGED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(
                    f"{message_type} image ID {image_id} layer ID {layer_id} "
                    f"operation={result.get('operation', operation)} threshold={threshold:.3f} "
                    f"active={result['active']}"
                )
                return response
            except Exception as exc:
                log(f"{message_type} failed: {exc}")
                return self._error_response(message, command=message_type, error=str(exc))

        if message_type in {"SELECT_GROW", "SELECT_SHRINK", "SELECT_FEATHER", "SELECT_BORDER"}:
            log(f"{message_type} received")
            try:
                image_id = int(message["image_id"])
                radius = float(message.get("radius", 1.0))
                action = message_type.removeprefix("SELECT_")
                result = self.dispatcher.call(
                    gimp_modify_selection, image_id, action, radius, timeout=5.0
                )
                response = {"type": "SELECTION_CHANGED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(
                    f"{message_type} image ID {image_id} radius={radius:.2f} "
                    f"active={result['active']}"
                )
                return response
            except Exception as exc:
                log(f"{message_type} failed: {exc}")
                return self._error_response(message, command=message_type, error=str(exc))

        if message_type in {"SELECT_ALL", "SELECT_NONE", "SELECT_INVERT"}:
            log(f"{message_type} received")
            try:
                image_id = int(message["image_id"])
                func = {
                    "SELECT_ALL": gimp_select_all,
                    "SELECT_NONE": gimp_select_none,
                    "SELECT_INVERT": gimp_select_invert,
                }[message_type]
                result = self.dispatcher.call(func, image_id, timeout=5.0)
                response = {"type": "SELECTION_CHANGED", "ok": True, **result}
                self._copy_request_id(message, response)
                log(f"{message_type} image ID {image_id} active={result['active']}")
                return response
            except Exception as exc:
                log(f"{message_type} failed: {exc}")
                return self._error_response(message, command=message_type, error=str(exc))

        if message_type == "SET_LAYER_LOCK":
            log("SET_LAYER_LOCK received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                lock_type = str(message["lock_type"]).upper()

                if "locked" not in message:
                    raise KeyError("locked")

                locked = message["locked"]

                if not isinstance(
                    locked,
                    bool
                ):
                    raise TypeError(
                        "locked must be a JSON boolean"
                    )

                result = self.dispatcher.call(
                    gimp_set_layer_lock,
                    image_id,
                    layer_id,
                    lock_type,
                    locked,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_LOCK_SET",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"SET_LAYER_LOCK layer ID {layer_id} "
                    f"{lock_type}={result['locked']}"
                )

                return response

            except Exception as exc:
                log(
                    f"SET_LAYER_LOCK failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="SET_LAYER_LOCK",
                    error=str(exc),
                )

        if message_type == "SET_LAYER_MODE":
            log("SET_LAYER_MODE received")

            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                mode_name = str(message["mode"]).upper()

                result = self.dispatcher.call(
                    gimp_set_layer_mode,
                    image_id,
                    layer_id,
                    mode_name,
                    timeout=5.0,
                )

                response = {
                    "type": "LAYER_MODE_SET",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"SET_LAYER_MODE layer ID {layer_id} "
                    f"mode={result['mode']}"
                )

                return response

            except Exception as exc:
                log(
                    f"SET_LAYER_MODE failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="SET_LAYER_MODE",
                    error=str(exc),
                )


        if message_type == "SET_FOREGROUND_COLOR":
            log("SET_FOREGROUND_COLOR received")

            try:
                rgba = message.get(
                    "rgba",
                    [0.0, 0.0, 0.0, 1.0]
                )

                result = self.dispatcher.call(
                    gimp_set_foreground_color,
                    rgba,
                    timeout=5.0,
                )

                response = {
                    "type": "FOREGROUND_COLOR_SET",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "SET_FOREGROUND_COLOR "
                    f"rgba={result['foreground_color']}"
                )

                return response

            except Exception as exc:
                log(
                    f"SET_FOREGROUND_COLOR failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="SET_FOREGROUND_COLOR",
                    error=str(exc),
                )

        if message_type == "SET_BACKGROUND_COLOR":
            log("SET_BACKGROUND_COLOR received")

            try:
                result = self.dispatcher.call(
                    gimp_set_background_color,
                    message.get("rgba", [1.0, 1.0, 1.0, 1.0]),
                    timeout=5.0,
                )
                response = {
                    "type": "BACKGROUND_COLOR_SET",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                return response
            except Exception as exc:
                log(f"SET_BACKGROUND_COLOR failed: {exc}")
                return self._error_response(
                    message,
                    command="SET_BACKGROUND_COLOR",
                    error=str(exc),
                )

        if message_type == "GET_DYNAMICS":
            log("GET_DYNAMICS received")

            try:
                result = self.dispatcher.call(
                    gimp_list_dynamics,
                    timeout=5.0,
                )
                response = {
                    "type": "DYNAMICS",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                log(
                    f"GET_DYNAMICS returned {len(result.get('dynamics', []))} dynamics; "
                    f"active={result.get('active_dynamics', '')} enabled={result.get('enabled', False)}"
                )
                return response
            except Exception as exc:
                log(f"GET_DYNAMICS failed: {exc}")
                return self._error_response(
                    message,
                    command="GET_DYNAMICS",
                    error=str(exc),
                )

        if message_type == "SET_DYNAMICS":
            log("SET_DYNAMICS received")

            try:
                result = self.dispatcher.call(
                    gimp_set_dynamics,
                    message.get("name", ""),
                    timeout=5.0,
                )
                response = {
                    "type": "BRUSH_STATE_SET",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                log(f"SET_DYNAMICS active={result.get('dynamics_name', '')}")
                return response
            except Exception as exc:
                log(f"SET_DYNAMICS failed: {exc}")
                return self._error_response(
                    message,
                    command="SET_DYNAMICS",
                    error=str(exc),
                )

        if message_type == "SET_DYNAMICS_ENABLED":
            log("SET_DYNAMICS_ENABLED received")

            try:
                result = self.dispatcher.call(
                    gimp_set_dynamics_enabled,
                    bool(message.get("enabled", False)),
                    timeout=5.0,
                )
                response = {
                    "type": "BRUSH_STATE_SET",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                log(f"SET_DYNAMICS_ENABLED enabled={result.get('dynamics_enabled', False)}")
                return response
            except Exception as exc:
                log(f"SET_DYNAMICS_ENABLED failed: {exc}")
                return self._error_response(
                    message,
                    command="SET_DYNAMICS_ENABLED",
                    error=str(exc),
                )

        if message_type == "SET_BRUSH_STATE":
            log("SET_BRUSH_STATE received")

            try:
                result = self.dispatcher.call(
                    gimp_set_brush_state,
                    message.get("state", {}),
                    timeout=5.0,
                )
                response = {
                    "type": "BRUSH_STATE_SET",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                return response
            except Exception as exc:
                log(f"SET_BRUSH_STATE failed: {exc}")
                return self._error_response(
                    message,
                    command="SET_BRUSH_STATE",
                    error=str(exc),
                )

        if message_type == "GET_BRUSHES":
            log("GET_BRUSHES received")

            try:
                result = self.dispatcher.call(
                    gimp_list_brushes,
                    timeout=5.0,
                )
                response = {
                    "type": "BRUSHES",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                return response
            except Exception as exc:
                log(f"GET_BRUSHES failed: {exc}")
                return self._error_response(
                    message,
                    command="GET_BRUSHES",
                    error=str(exc),
                )

        if message_type == "GET_BRUSH_PREVIEW":
            log("GET_BRUSH_PREVIEW received")

            try:
                result = self.dispatcher.call(
                    gimp_get_brush_preview,
                    message.get("max_size", 256),
                    timeout=5.0,
                )
                response = {
                    "type": "BRUSH_PREVIEW",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                log(
                    "GET_BRUSH_PREVIEW returned "
                    f"brush={result.get('brush_name', '')} "
                    f"size={result.get('preview_width', 0)}x{result.get('preview_height', 0)}"
                )
                return response
            except Exception as exc:
                log(f"GET_BRUSH_PREVIEW failed: {exc}")
                return self._error_response(
                    message,
                    command="GET_BRUSH_PREVIEW",
                    error=str(exc),
                )

        if message_type == "GET_BRUSH_STATE":
            log("GET_BRUSH_STATE received")

            try:
                result = self.dispatcher.call(
                    gimp_get_brush_state,
                    timeout=5.0,
                )

                response = {
                    "type": "BRUSH_STATE",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                return response

            except Exception as exc:
                log(
                    f"GET_BRUSH_STATE failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="GET_BRUSH_STATE",
                    error=str(exc),
                )

        if message_type == "GET_GRADIENTS":
            log("GET_GRADIENTS received")

            try:
                result = self.dispatcher.call(
                    gimp_list_gradients,
                    timeout=10.0,
                )
                response = {
                    "type": "GRADIENTS",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                log(f"GET_GRADIENTS returned {len(result.get('gradients', []))} gradient(s)")
                return response
            except Exception as exc:
                log(f"GET_GRADIENTS failed: {exc}")
                return self._error_response(
                    message,
                    command="GET_GRADIENTS",
                    error=str(exc),
                )

        if message_type == "GRADIENT_FILL":
            log("GRADIENT_FILL received")

            try:
                result = self.dispatcher.call(
                    gimp_gradient_fill,
                    int(message["image_id"]),
                    int(message["layer_id"]),
                    float(message["x1"]),
                    float(message["y1"]),
                    float(message["x2"]),
                    float(message["y2"]),
                    str(message.get("gradient_source", "FG_BG")),
                    str(message.get("gradient_name", "")),
                    str(message.get("gradient_type", "LINEAR")),
                    bool(message.get("reverse", False)),
                    str(message.get("repeat_mode", "NONE")),
                    timeout=20.0,
                )
                response = {
                    "type": "GRADIENT_FILLED",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)
                log(
                    "GRADIENT_FILL "
                    f"image ID {result['image_id']} layer ID {result['layer_id']} "
                    f"start=({result['x1']:.1f},{result['y1']:.1f}) "
                    f"end=({result['x2']:.1f},{result['y2']:.1f}) "
                    f"type={result['gradient_type']} source={result['gradient_source']} "
                    f"gradient={result['gradient_name']} reverse={result['reverse']} "
                    f"repeat={result['repeat_mode']}"
                )
                return response
            except Exception as exc:
                log(f"GRADIENT_FILL failed: {exc}")
                return self._error_response(
                    message,
                    command="GRADIENT_FILL",
                    error=str(exc),
                )

        if message_type == "BUCKET_FILL":
            log("BUCKET_FILL received")

            try:
                result = self.dispatcher.call(
                    gimp_bucket_fill,
                    int(message["image_id"]),
                    int(message["layer_id"]),
                    float(message["x"]),
                    float(message["y"]),
                    str(message.get("fill_type", "FOREGROUND")),
                    timeout=15.0,
                )

                response = {
                    "type": "BUCKET_FILLED",
                    "ok": True,
                    **result,
                }
                self._copy_request_id(message, response)

                log(
                    "BUCKET_FILL "
                    f"image ID {result['image_id']} layer ID {result['layer_id']} "
                    f"x={result['x']:.1f} y={result['y']:.1f} "
                    f"fill={result['fill_type']} "
                    f"sample_merged={result['sample_merged']} "
                    f"sample_transparent={result.get('sample_transparent', True)}"
                )
                return response

            except Exception as exc:
                log(f"BUCKET_FILL failed: {exc}")
                return self._error_response(
                    message,
                    command="BUCKET_FILL",
                    error=str(exc),
                )

        if message_type == "BEGIN_PAINT_STROKE":
            log("BEGIN_PAINT_STROKE received")

            try:
                result = self.dispatcher.call(
                    gimp_begin_direct_paint_stroke,
                    int(
                        message["image_id"]
                    ),
                    int(
                        message["layer_id"]
                    ),
                    str(
                        message["stroke_id"]
                    ),
                    str(message.get("tool", "PAINTBRUSH")),
                    message.get("source_image_id"),
                    message.get("source_layer_id"),
                    message.get("source_x"),
                    message.get("source_y"),
                    timeout=5.0,
                )

                response = {
                    "type": "PAINT_STROKE_BEGUN",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "BEGIN_PAINT_STROKE "
                    f"stroke={result['stroke_id']} "
                    f"image ID {result['image_id']} "
                    f"layer ID {result['layer_id']} "
                    f"tool={result.get('tool', 'PAINTBRUSH')}"
                    + (
                        f" source_image={result.get('source_image_id')} "
                        f"source_layer={result.get('source_layer_id')} "
                        f"source=({float(result.get('source_x', 0.0)):.1f},"
                        f"{float(result.get('source_y', 0.0)):.1f})"
                        if result.get("tool") in {"CLONE", "HEAL"}
                        else ""
                    )
                )

                return response

            except Exception as exc:
                log(
                    f"BEGIN_PAINT_STROKE failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="BEGIN_PAINT_STROKE",
                    error=str(exc),
                )

        if message_type == "PAINT_STROKE_CHUNK":
            try:
                result = self.dispatcher.call(
                    gimp_paint_direct_stroke_chunk,
                    int(
                        message["image_id"]
                    ),
                    int(
                        message["layer_id"]
                    ),
                    str(
                        message["stroke_id"]
                    ),
                    message.get(
                        "strokes",
                        []
                    ),
                    message.get(
                        "segments"
                    ),
                    message.get(
                        "input_samples"
                    ),
                    message.get(
                        "input_segments"
                    ),
                    timeout=10.0,
                )

                response = {
                    "type": "PAINT_STROKE_CHUNKED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "PAINT_STROKE_CHUNK "
                    f"stroke={result['stroke_id']} "
                    f"chunk={result['chunk_index']} "
                    f"segments={result.get('segment_count', 1)} "
                    f"points={result['point_count']} "
                    f"total={result['total_point_count']} "
                    f"tool={result.get('tool', 'PAINTBRUSH')} "
                    f"tablet_samples={result.get('tablet_sample_count', 0)} "
                    f"pressure={float(result.get('pressure_min', 1.0)):.3f}-"
                    f"{float(result.get('pressure_max', 1.0)):.3f} "
                    f"apply={result.get('pressure_application', 'metadata-only')} "
                    f"pressure_calls={int(result.get('pressure_subsegments', 0))} "
                    f"tilt_max={float(result.get('tilt_max', 0.0)):.3f}"
                )

                return response

            except Exception as exc:
                log(
                    f"PAINT_STROKE_CHUNK failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="PAINT_STROKE_CHUNK",
                    error=str(exc),
                )

        if message_type == "END_PAINT_STROKE":
            log("END_PAINT_STROKE received")

            try:
                result = self.dispatcher.call(
                    gimp_end_direct_paint_stroke,
                    str(
                        message["stroke_id"]
                    ),
                    timeout=5.0,
                )

                response = {
                    "type": "PAINT_STROKE_ENDED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "END_PAINT_STROKE "
                    f"stroke={result['stroke_id']} "
                    f"chunks={result.get('chunk_count', 0)} "
                    f"points={result.get('point_count', 0)} "
                    f"tool={result.get('tool', 'PAINTBRUSH')} "
                    f"tablet_samples={result.get('tablet_sample_count', 0)} "
                    f"pressure={float(result.get('pressure_min', 1.0)):.3f}-"
                    f"{float(result.get('pressure_max', 1.0)):.3f} "
                    f"avg={float(result.get('pressure_avg', 1.0)):.3f} "
                    f"apply={result.get('pressure_application', 'metadata-only')} "
                    f"pressure_calls={int(result.get('pressure_subsegments', 0))} "
                    f"tilt_max={float(result.get('tilt_max', 0.0)):.3f}"
                )

                return response

            except Exception as exc:
                log(
                    f"END_PAINT_STROKE failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="END_PAINT_STROKE",
                    error=str(exc),
                )

        if message_type == "PAINT_STROKE":
            log("PAINT_STROKE received")

            try:
                image_id = int(
                    message["image_id"]
                )

                layer_id = int(
                    message["layer_id"]
                )

                strokes = message.get(
                    "strokes",
                    []
                )

                result = self.dispatcher.call(
                    gimp_paint_stroke,
                    image_id,
                    layer_id,
                    strokes,
                    str(message.get("tool", "PAINTBRUSH")),
                    timeout=15.0,
                )

                response = {
                    "type": "STROKE_PAINTED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "PAINT_STROKE "
                    f"image ID {image_id} layer ID {layer_id} -> "
                    f"{result['point_count']} point(s), "
                    f"brush={result.get('brush_name', '')}, "
                    f"size={result.get('brush_size', 0):.1f}"
                )

                return response

            except Exception as exc:
                log(
                    f"PAINT_STROKE failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="PAINT_STROKE",
                    error=str(exc),
                )


        if message_type == "ENSURE_PAINT_LAYER":
            log("ENSURE_PAINT_LAYER received")

            try:
                image_id = int(
                    message["image_id"]
                )

                name = str(
                    message.get(
                        "name",
                        BLENDGIMP_PAINT_LAYER_NAME
                    )
                )

                result = self.dispatcher.call(
                    gimp_ensure_blendgimp_paint_layer,
                    image_id,
                    name,
                    timeout=10.0,
                )

                response = {
                    "type": "PAINT_LAYER_READY",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "ENSURE_PAINT_LAYER "
                    f"image ID {image_id} -> "
                    f"layer ID {result['layer_id']} "
                    f"name={result['name']} "
                    f"created={result['created']}"
                )

                return response

            except Exception as exc:
                log(
                    f"ENSURE_PAINT_LAYER failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="ENSURE_PAINT_LAYER",
                    error=str(exc),
                )


        if message_type == "GET_LAYER_PIXELS_BINARY":
            log("GET_LAYER_PIXELS_BINARY received")
            try:
                image_id = int(message["image_id"])
                layer_id = int(message["layer_id"])
                supplied = all(key in message for key in ("x", "y", "width", "height"))
                result = self.dispatcher.call(
                    gimp_get_layer_pixels_binary,
                    image_id,
                    layer_id,
                    int(message["x"]) if supplied else None,
                    int(message["y"]) if supplied else None,
                    int(message["width"]) if supplied else None,
                    int(message["height"]) if supplied else None,
                    timeout=30.0,
                )
                response = {"type": "LAYER_PIXELS_BINARY", "ok": True, **result}
                self._copy_request_id(message, response)
                log(
                    "GET_LAYER_PIXELS_BINARY "
                    f"image ID {image_id} layer ID {layer_id} -> "
                    f"x={result['x']} y={result['y']} "
                    f"{result['width']}x{result['height']} "
                    f"{result['byte_length']} raw RGBA bytes"
                )
                return response
            except Exception as exc:
                log(f"GET_LAYER_PIXELS_BINARY failed: {exc}")
                return self._error_response(
                    message, command="GET_LAYER_PIXELS_BINARY", error=str(exc)
                )


        if message_type == "SET_LAYER_PIXELS_BINARY":
            log("SET_LAYER_PIXELS_BINARY received")

            try:

                image_id = int(
                    message["image_id"]
                )

                layer_id = int(
                    message["layer_id"]
                )

                image_x = int(
                    message.get(
                        "x",
                        0
                    )
                )

                image_y = int(
                    message.get(
                        "y",
                        0
                    )
                )

                region_width = int(
                    message["width"]
                )

                region_height = int(
                    message["height"]
                )

                raw_pixels = message.get(
                    "_binary_payload",
                    b""
                )

                result = self.dispatcher.call(
                    gimp_set_layer_pixels_binary,
                    image_id,
                    layer_id,
                    image_x,
                    image_y,
                    region_width,
                    region_height,
                    raw_pixels,
                    timeout=30.0,
                )

                response = {
                    "type": "LAYER_PIXELS_SET",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "SET_LAYER_PIXELS_BINARY "
                    f"image ID {image_id} layer ID {layer_id} -> "
                    f"x={result['image_x']} y={result['image_y']} "
                    f"{result['width']}x{result['height']} "
                    f"{result['byte_length']} raw RGBA bytes"
                )

                return response

            except Exception as exc:

                log(
                    f"SET_LAYER_PIXELS_BINARY failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="SET_LAYER_PIXELS_BINARY",
                    error=str(exc),
                )


        if message_type == "REBASE_IMAGE_DIRTY_BASELINE":
            log("REBASE_IMAGE_DIRTY_BASELINE received")

            try:
                image_id = int(message["image_id"])

                result = self.dispatcher.call(
                    gimp_rebase_image_dirty_baseline,
                    image_id,
                    timeout=30.0,
                )

                response = {
                    "type": "IMAGE_DIRTY_BASELINE_REBASED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(message, response)

                log(
                    "REBASE_IMAGE_DIRTY_BASELINE "
                    f"image ID {image_id} -> "
                    f"{result['width']}x{result['height']} "
                    f"layers={result['layer_count']} "
                    f"source={result['source']}"
                )

                return response

            except Exception as exc:
                log(
                    f"REBASE_IMAGE_DIRTY_BASELINE failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="REBASE_IMAGE_DIRTY_BASELINE",
                    error=str(exc),
                )


        if message_type == "GET_IMAGE_DIRTY_PIXELS_BINARY":
            log("GET_IMAGE_DIRTY_PIXELS_BINARY received")

            try:
                image_id = int(
                    message["image_id"]
                )
                full_width_rows = bool(
                    message.get("full_width_rows", False)
                )

                result = self.dispatcher.call(
                    gimp_get_image_dirty_pixels_binary,
                    image_id,
                    full_width_rows,
                    timeout=30.0,
                )

                response = {
                    "type": "IMAGE_DIRTY_PIXELS_BINARY",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                if result.get(
                    "changed",
                    False
                ):
                    log(
                        "GET_IMAGE_DIRTY_PIXELS_BINARY "
                        f"image ID {image_id} -> "
                        f"x={result['x']} y={result['y']} "
                        f"{result['region_width']}x"
                        f"{result['region_height']} "
                        f"{result['byte_length']} raw RGBA bytes"
                    )
                else:
                    log(
                        "GET_IMAGE_DIRTY_PIXELS_BINARY "
                        f"image ID {image_id} -> no pixel delta"
                    )

                return response

            except Exception as exc:
                log(
                    f"GET_IMAGE_DIRTY_PIXELS_BINARY failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="GET_IMAGE_DIRTY_PIXELS_BINARY",
                    error=str(exc),
                )


        if message_type == "GET_IMAGE_DIRTY_PIXELS":
            log("GET_IMAGE_DIRTY_PIXELS received")

            try:
                image_id = int(
                    message["image_id"]
                )

                result = self.dispatcher.call(
                    gimp_get_image_dirty_pixels,
                    image_id,
                    timeout=30.0,
                )

                response = {
                    "type": "IMAGE_DIRTY_PIXELS",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                if result.get(
                    "changed",
                    False
                ):
                    log(
                        "GET_IMAGE_DIRTY_PIXELS "
                        f"image ID {image_id} -> "
                        f"x={result['x']} y={result['y']} "
                        f"{result['region_width']}x"
                        f"{result['region_height']} "
                        f"{result['byte_length']} RGBA bytes"
                    )
                else:
                    log(
                        "GET_IMAGE_DIRTY_PIXELS "
                        f"image ID {image_id} -> no pixel delta"
                    )

                return response

            except Exception as exc:
                log(
                    f"GET_IMAGE_DIRTY_PIXELS failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="GET_IMAGE_DIRTY_PIXELS",
                    error=str(exc),
                )


        if message_type == "GET_IMAGE_PIXELS_BINARY":
            log("GET_IMAGE_PIXELS_BINARY received")

            try:
                image_id = int(
                    message["image_id"]
                )

                result = self.dispatcher.call(
                    gimp_get_image_pixels_binary,
                    image_id,
                    timeout=30.0,
                )

                response = {
                    "type": "IMAGE_PIXELS_BINARY",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "GET_IMAGE_PIXELS_BINARY "
                    f"image ID {image_id} -> "
                    f"{result['width']}x{result['height']} "
                    f"{result['byte_length']} raw RGBA bytes"
                )

                return response

            except Exception as exc:
                log(
                    f"GET_IMAGE_PIXELS_BINARY failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="GET_IMAGE_PIXELS_BINARY",
                    error=str(exc),
                )


        if message_type == "GET_IMAGE_PIXELS":
            log("GET_IMAGE_PIXELS received")

            try:
                image_id = int(
                    message["image_id"]
                )

                result = self.dispatcher.call(
                    gimp_get_image_pixels,
                    image_id,
                    timeout=30.0,
                )

                response = {
                    "type": "IMAGE_PIXELS",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    "GET_IMAGE_PIXELS "
                    f"image ID {image_id} -> "
                    f"{result['width']}x{result['height']} "
                    f"{result['byte_length']} RGBA bytes"
                )

                return response

            except Exception as exc:
                log(
                    f"GET_IMAGE_PIXELS failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="GET_IMAGE_PIXELS",
                    error=str(exc),
                )


        if message_type == "GET_IMAGE_STATE":
            image_id = -1

            try:
                image_id = int(
                    message["image_id"]
                )

                result = self.dispatcher.call(
                    gimp_get_image_state,
                    image_id,
                    timeout=5.0,
                    log_exceptions=False,
                )

                response = {
                    "type": "IMAGE_STATE",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                if result.get(
                    "changed",
                    False
                ):
                    detector = str(
                        result.get(
                            "detector",
                            "unknown"
                        )
                    )

                    log(
                        "IMAGE_STATE "
                        f"image ID {image_id} "
                        f"revision={result['revision']} "
                        f"detector={detector} "
                        f"fingerprint_changed="
                        f"{result.get('fingerprint_changed', False)} "
                        f"native_changed="
                        f"{result.get('native_changed', False)} "
                        f"suppressed="
                        f"{result.get('self_originated_suppressed', False)} "
                        f"damage={result.get('damage_width', 0)}x"
                        f"{result.get('damage_height', 0)} "
                        f"@ {result.get('damage_x', 0)},"
                        f"{result.get('damage_y', 0)}"
                    )

                return response

            except ValueError as exc:
                response = {
                    "type": "IMAGE_NOT_FOUND",
                    "ok": False,
                    "image_id": image_id,
                    "error": str(exc),
                }
                self._copy_request_id(message, response)
                return response

            except Exception as exc:
                log(f"GET_IMAGE_STATE failed: {exc}")

                return self._error_response(
                    message,
                    command="GET_IMAGE_STATE",
                    error=str(exc),
                )


        if message_type == "EXPORT_COMPOSITE":
            log("EXPORT_COMPOSITE received")

            try:
                image_id = int(message["image_id"])

                result = self.dispatcher.call(
                    gimp_export_composite,
                    image_id,
                    timeout=30.0,
                )

                response = {
                    "type": "COMPOSITE_EXPORTED",
                    "ok": True,
                    **result,
                }

                self._copy_request_id(
                    message,
                    response,
                )

                log(
                    f"EXPORT_COMPOSITE image ID {image_id} -> "
                    f"{result['path']} ({result['width']}x{result['height']})"
                )

                return response

            except Exception as exc:
                log(
                    f"EXPORT_COMPOSITE failed: {exc}"
                )

                return self._error_response(
                    message,
                    command="EXPORT_COMPOSITE",
                    error=str(exc),
                )

        return self._error_response(
            message,
            command=message_type,
            error=f"Unknown command: {message_type}",
        )

    @staticmethod
    def _copy_request_id(request, response):
        if "request_id" in request:
            response["request_id"] = request["request_id"]

    @staticmethod
    def _error_response(request, command, error):
        response = {
            "type": "ERROR",
            "ok": False,
            "error": error,
        }

        if command is not None:
            response["command"] = command

        if isinstance(request, dict) and "request_id" in request:
            response["request_id"] = request["request_id"]

        return response

    def _send_response(
        self,
        client,
        payload
    ):
        """
        Send either normal newline JSON or a small JSON header followed by an
        exact raw binary payload.

        `_binary_payload` is internal-only and is never serialized to JSON.
        """

        shutdown_after_response = False
        shutdown_force = False

        if isinstance(payload, dict):
            payload = dict(payload)
            shutdown_after_response = bool(
                payload.pop(
                    "_shutdown_after_response",
                    False
                )
            )
            shutdown_force = bool(
                payload.pop(
                    "_shutdown_force",
                    False
                )
            )

        if (
            isinstance(
                payload,
                dict
            )
            and "_binary_payload" in payload
        ):
            binary_payload = payload.get(
                "_binary_payload",
                b""
            )

            if binary_payload is None:
                binary_payload = b""

            if not isinstance(
                binary_payload,
                bytes
            ):
                binary_payload = bytes(
                    binary_payload
                )

            header = dict(
                payload
            )

            header.pop(
                "_binary_payload",
                None
            )

            header[
                "binary_payload"
            ] = True

            header[
                "binary_length"
            ] = len(
                binary_payload
            )

            self._send_json(
                client,
                header
            )

            if binary_payload:
                client.sendall(
                    binary_payload
                )

            if shutdown_after_response:
                self._schedule_application_shutdown(
                    shutdown_force
                )

            return

        self._send_json(
            client,
            payload
        )

        if shutdown_after_response:
            self._schedule_application_shutdown(
                shutdown_force
            )

    def _schedule_application_shutdown(
        self,
        force=False
    ):
        """Ask GIMP itself to exit after the IPC acknowledgement is sent."""

        if self._shutdown_scheduled:
            return

        self._shutdown_scheduled = True

        GLib.idle_add(
            self._quit_gimp_application,
            bool(force)
        )

    def _quit_gimp_application(
        self,
        force=False
    ):
        """MAIN THREAD ONLY. Invoke GIMP's application quit procedure."""

        try:
            pdb = Gimp.get_pdb()
            procedure = pdb.lookup_procedure(
                "gimp-quit"
            )

            if procedure is None:
                raise RuntimeError(
                    "The gimp-quit procedure is unavailable"
                )

            config = procedure.create_config()

            if config.find_property("force") is not None:
                config.set_property(
                    "force",
                    bool(force)
                )

            log("Requesting clean GIMP application exit")
            procedure.run(config)

        except Exception:
            self._shutdown_scheduled = False
            log(
                "Clean GIMP application exit failed:\n"
                + traceback.format_exc()
            )

        return GLib.SOURCE_REMOVE

    @staticmethod
    def _send_json(client, payload):
        encoded = (
            json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
            + "\n"
        ).encode("utf-8")

        client.sendall(encoded)


# -----------------------------------------------------------------------------
# Persistent GIMP procedure
# -----------------------------------------------------------------------------

def blendgimp_run(procedure, config, run_data):
    """Lifetime entry point for the automatic persistent BlendGimp plug-in."""

    plug_in = procedure.get_plug_in()
    return plug_in.run_blendgimp(procedure)


class BlendGimpPlugin(Gimp.PlugIn):
    def __init__(self):
        super().__init__()
        self._main_loop = None
        self._dispatcher = None
        self._ipc_server = None
        self._shutting_down = False

    def do_set_i18n(self, procedure_name):
        # BlendGimp has no localization catalog yet. Explicitly disable GIMP's
        # default locale lookup so startup stays clean.
        log("Localization disabled")
        return False, None, None

    def do_query_procedures(self):
        return [PLUGIN_PROC]

    def do_create_procedure(self, name):
        if name != PLUGIN_PROC:
            return None

        procedure = Gimp.Procedure.new(
            self,
            name,
            Gimp.PDBProcType.PERSISTENT,
            blendgimp_run,
            None,
        )

        procedure.set_documentation(
            "BlendGimp persistent integration service",
            "Maintains the local IPC connection used by the BlendGimp Blender extension.",
            name,
        )
        procedure.set_attribution(
            "Afro Lion Studios, LLC",
            "Afro Lion Studios, LLC",
            "2026",
        )

        return procedure

    def run_blendgimp(self, procedure):
        log("BlendGimp plug-in executable loaded")

        # Any GIMP API values needed by the worker thread are captured here,
        # before that worker starts.
        gimp_version = str(Gimp.version())

        # Construct the dispatcher on this thread. GLib idle callbacks then
        # bring requested GIMP API work back here from the socket worker.
        self._dispatcher = GimpMainThreadDispatcher()
        self._ipc_server = BlendGimpIPCServer(
            dispatcher=self._dispatcher,
            gimp_version=gimp_version,
        )

        # Because this persistent plug-in remains inside a GLib main loop,
        # enable asynchronous processing of messages from GIMP.
        self.persistent_enable()

        # REQUIRED for PERSISTENT procedures. GIMP waits for this notification.
        procedure.persistent_ready()
        log("Persistent procedure READY")

        self._ipc_server.start()

        self._main_loop = GLib.MainLoop()

        try:
            self._main_loop.run()
        except KeyboardInterrupt:
            log("KeyboardInterrupt received")
        except Exception:
            log("Persistent main loop failed:\n" + traceback.format_exc())
        finally:
            self._shutdown()

        return procedure.new_return_values(
            Gimp.PDBStatusType.SUCCESS,
            None,
        )

    def do_quit(self):
        self._shutdown()

    def _shutdown(self):
        if self._shutting_down:
            return

        self._shutting_down = True
        log("Shutting down")

        if self._ipc_server is not None:
            self._ipc_server.stop()

        if self._main_loop is not None and self._main_loop.is_running():
            self._main_loop.quit()


# -----------------------------------------------------------------------------
# GIMP entry point
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    Gimp.main(BlendGimpPlugin.__gtype__, sys.argv)
