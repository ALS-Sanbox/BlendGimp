"""BlendGimp Phase 6.1 texture-editor foundation.

This module intentionally stays Blender-side.  It does not send new protocol
messages and does not alter the headless GIMP engine, Auto Sync, dirty-region
transfer, or direct-paint ownership.  It presents the already synchronized
BlendGimp Image datablock in a dedicated Blender Image Editor workspace and
controls Blender's native UV overlay.
"""

import bpy


WORKSPACE_NAME = "BlendGimp Texture"
TEXTURE_EDITOR_POLL_INTERVAL = 0.35


# -----------------------------------------------------------------------------
# BlendGimp image/session helpers
# -----------------------------------------------------------------------------


def _image_gimp_id(image):
    if image is None:
        return -1

    try:
        return int(image.get("blendgimp_gimp_image_id", -1))
    except (TypeError, ValueError):
        return -1


def _find_blendgimp_image(image_id):
    try:
        image_id = int(image_id)
    except (TypeError, ValueError):
        return None

    if image_id < 0:
        return None

    for image in bpy.data.images:
        if _image_gimp_id(image) == image_id:
            return image

    return None


def _blendgimp_images():
    images = []

    for image in bpy.data.images:
        image_id = _image_gimp_id(image)
        if image_id >= 0:
            images.append((image_id, image))

    images.sort(key=lambda item: (item[0], item[1].name.lower()))
    return images


def _active_material_image_id(context):
    obj = getattr(context, "active_object", None)
    if obj is None:
        return -1

    material = getattr(obj, "active_material", None)
    if material is None:
        return -1

    try:
        material_image_id = int(
            material.get("blendgimp_gimp_image_id", -1)
        )
    except (TypeError, ValueError):
        material_image_id = -1

    if material_image_id >= 0 and _find_blendgimp_image(material_image_id):
        return material_image_id

    node_tree = getattr(material, "node_tree", None)
    nodes = getattr(node_tree, "nodes", None)
    if nodes is None:
        return -1

    active_node = getattr(nodes, "active", None)
    candidate_nodes = []
    if active_node is not None:
        candidate_nodes.append(active_node)
    candidate_nodes.extend(node for node in nodes if node is not active_node)

    for node in candidate_nodes:
        image = getattr(node, "image", None)
        image_id = _image_gimp_id(image)
        if image_id >= 0:
            return image_id

    return -1


def _existing_scene_image_id(scene, property_name):
    if not hasattr(scene, property_name):
        return -1

    try:
        image_id = int(getattr(scene, property_name))
    except (TypeError, ValueError):
        return -1

    if image_id >= 0 and _find_blendgimp_image(image_id) is not None:
        return image_id

    return -1


def _resolve_follow_image_id(context):
    """Resolve the current artist-facing BlendGimp texture.

    Existing Phase 4/5 ownership is only observed, never modified.  The order
    intentionally prefers explicit synchronization owners, then the active
    material, then the Texture Editor's prior valid selection.
    """

    scene = context.scene

    owner_properties = (
        "blendgimp_auto_sync_image_id",
        "blendgimp_blender_paint_sync_image_id",
        "blendgimp_direct_paint_image_id",
    )

    for property_name in owner_properties:
        image_id = _existing_scene_image_id(scene, property_name)
        if image_id >= 0:
            return image_id

    material_image_id = _active_material_image_id(context)
    if material_image_id >= 0:
        return material_image_id

    current_id = _existing_scene_image_id(
        scene,
        "blendgimp_texture_editor_image_id",
    )
    if current_id >= 0:
        return current_id

    images = _blendgimp_images()
    if images:
        return images[0][0]

    return -1


def _set_active_texture(scene, image_id):
    try:
        image_id = int(image_id)
    except (TypeError, ValueError):
        image_id = -1

    image = _find_blendgimp_image(image_id)
    if image is None:
        image_id = -1

    scene.blendgimp_texture_editor_image_id = image_id
    scene.blendgimp_texture_editor_image_name = (
        image.name if image is not None else ""
    )

    return image


# -----------------------------------------------------------------------------
# Image Editor configuration
# -----------------------------------------------------------------------------


def _iter_texture_editor_areas():
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return

    for window in wm.windows:
        workspace = getattr(window, "workspace", None)
        if workspace is None or workspace.name != WORKSPACE_NAME:
            continue

        screen = getattr(window, "screen", None)
        if screen is None:
            continue

        for area in screen.areas:
            if area.type == "IMAGE_EDITOR":
                yield window, area


def _set_if_present(target, property_name, value):
    if target is None or not hasattr(target, property_name):
        return False

    try:
        setattr(target, property_name, value)
        return True
    except (AttributeError, TypeError, ValueError):
        return False


def _apply_uv_overlay_to_space(space, scene):
    if space is None:
        return

    # Keep transparency visible in the texture canvas.
    _set_if_present(space, "display_channels", "COLOR_ALPHA")

    overlay = getattr(space, "overlay", None)
    show_uv = bool(
        scene.blendgimp_texture_editor_show_uv
        and scene.blendgimp_texture_editor_show_islands
    )

    # General Image/UV editor overlay master switch.
    _set_if_present(overlay, "show_overlays", True)

    uv_editor = getattr(space, "uv_editor", None)
    if uv_editor is None:
        return

    _set_if_present(uv_editor, "show_uv", show_uv)
    _set_if_present(uv_editor, "edge_display_type", "OUTLINE")

    opacity = float(scene.blendgimp_texture_editor_uv_opacity)

    # Blender 5.x exposes separate object/edit-mode UV opacities.  Setting all
    # available variants keeps the BlendGimp control meaningful across the
    # supported Blender API revisions without hard-coding one exact minor.
    _set_if_present(uv_editor, "uv_opacity", opacity)
    _set_if_present(uv_editor, "uv_edge_opacity", opacity)
    _set_if_present(uv_editor, "uv_face_opacity", min(opacity * 0.30, 1.0))

    # Native face fill provides Blender's active/selected-face highlighting in
    # Edit Mode.  It is intentionally disabled when the artist turns off the
    # BlendGimp active-face highlight control.
    _set_if_present(
        uv_editor,
        "show_faces",
        bool(scene.blendgimp_texture_editor_active_face_highlight),
    )


def _configure_image_editor_space(space, scene, image=None, set_mode=False):
    if space is None:
        return

    if image is not None and getattr(space, "image", None) is not image:
        try:
            space.image = image
        except (AttributeError, TypeError):
            pass

    if set_mode:
        # Phase 6.1 is the UV/canvas foundation.  Later Phase 6 painting tools
        # may switch this space to PAINT, so the recurring timer never forces
        # the mode back to UV.
        _set_if_present(space, "mode", "UV")

    _apply_uv_overlay_to_space(space, scene)


def _sync_texture_workspace(context, set_mode=False):
    scene = context.scene
    image = _find_blendgimp_image(scene.blendgimp_texture_editor_image_id)

    for _window, area in _iter_texture_editor_areas():
        space = area.spaces.active
        _configure_image_editor_space(
            space,
            scene,
            image=image,
            set_mode=set_mode,
        )
        area.tag_redraw()

    return image


def _texture_editor_property_update(_self, context):
    if context is None or getattr(context, "scene", None) is None:
        return

    _sync_texture_workspace(context)


def _follow_property_update(_self, context):
    if context is None or getattr(context, "scene", None) is None:
        return

    scene = context.scene
    if scene.blendgimp_texture_editor_follow_active:
        image_id = _resolve_follow_image_id(context)
        _set_active_texture(scene, image_id)

    _sync_texture_workspace(context)


def blendgimp_texture_editor_timer():
    """Keep the Texture workspace following the active BlendGimp image.

    This reads Blender-side state only.  It performs no GIMP/IPC polling and
    therefore does not compete with Auto Sync or direct-paint refresh ownership.
    """

    try:
        context = bpy.context
        scene = getattr(context, "scene", None)
        if scene is None or not hasattr(
            scene,
            "blendgimp_texture_editor_follow_active",
        ):
            return TEXTURE_EDITOR_POLL_INTERVAL

        if scene.blendgimp_texture_editor_follow_active:
            image_id = _resolve_follow_image_id(context)
            if image_id != scene.blendgimp_texture_editor_image_id:
                _set_active_texture(scene, image_id)

        _sync_texture_workspace(context)

    except Exception as exc:
        # The timer must never destabilize Blender or the existing sync engine.
        print(
            "BLENDGIMP: Texture Editor timer recovered from error: "
            f"{exc}"
        )

    return TEXTURE_EDITOR_POLL_INTERVAL


# -----------------------------------------------------------------------------
# Operators
# -----------------------------------------------------------------------------


class BLENDGIMP_OT_open_texture_workspace(bpy.types.Operator):
    bl_idname = "blendgimp.open_texture_workspace"
    bl_label = "Open BlendGimp Texture Editor"
    bl_description = (
        "Open the Blender-native BlendGimp texture workspace and show the "
        "active synchronized GIMP texture"
    )

    def execute(self, context):
        window = context.window
        if window is None:
            self.report({"ERROR"}, "BlendGimp requires a Blender window")
            return {"CANCELLED"}

        workspace = bpy.data.workspaces.get(WORKSPACE_NAME)

        if workspace is None:
            previous_workspace = window.workspace

            try:
                result = bpy.ops.workspace.duplicate()
            except RuntimeError as exc:
                self.report({"ERROR"}, f"Could not create workspace: {exc}")
                return {"CANCELLED"}

            if "FINISHED" not in result:
                self.report({"ERROR"}, "Could not create BlendGimp workspace")
                return {"CANCELLED"}

            workspace = window.workspace
            if workspace is previous_workspace:
                self.report({"ERROR"}, "Blender did not activate duplicated workspace")
                return {"CANCELLED"}

            workspace.name = WORKSPACE_NAME
        else:
            window.workspace = workspace

        screen = window.screen
        if screen is None:
            self.report({"ERROR"}, "BlendGimp workspace has no active screen")
            return {"CANCELLED"}

        image_areas = [area for area in screen.areas if area.type == "IMAGE_EDITOR"]

        if image_areas:
            target_area = max(image_areas, key=lambda area: area.width * area.height)
        else:
            preferred = [area for area in screen.areas if area.type == "VIEW_3D"]
            candidates = preferred or [
                area
                for area in screen.areas
                if area.type not in {"TOPBAR", "STATUSBAR"}
            ]

            if not candidates:
                self.report({"ERROR"}, "No suitable area for Texture Editor")
                return {"CANCELLED"}

            target_area = max(candidates, key=lambda area: area.width * area.height)
            target_area.type = "IMAGE_EDITOR"

        scene = context.scene
        if scene.blendgimp_texture_editor_follow_active:
            image_id = _resolve_follow_image_id(context)
            image = _set_active_texture(scene, image_id)
        else:
            image = _find_blendgimp_image(scene.blendgimp_texture_editor_image_id)

        _configure_image_editor_space(
            target_area.spaces.active,
            scene,
            image=image,
            set_mode=True,
        )
        target_area.tag_redraw()

        if image is None:
            scene.blendgimp_texture_editor_status = (
                "Texture workspace ready — no synchronized BlendGimp image yet"
            )
            self.report(
                {"INFO"},
                "Texture Editor ready; create or synchronize a BlendGimp texture",
            )
        else:
            scene.blendgimp_texture_editor_status = (
                f"Following {image.name}"
            )
            self.report({"INFO"}, f"Texture Editor: {image.name}")

        return {"FINISHED"}


class BLENDGIMP_OT_texture_editor_refresh(bpy.types.Operator):
    bl_idname = "blendgimp.texture_editor_refresh"
    bl_label = "Refresh Texture Canvas"
    bl_description = "Refresh which synchronized BlendGimp image the canvas follows"

    def execute(self, context):
        scene = context.scene

        if scene.blendgimp_texture_editor_follow_active:
            image_id = _resolve_follow_image_id(context)
            image = _set_active_texture(scene, image_id)
        else:
            image = _find_blendgimp_image(scene.blendgimp_texture_editor_image_id)

        _sync_texture_workspace(context)

        if image is None:
            self.report({"WARNING"}, "No synchronized BlendGimp texture found")
        else:
            scene.blendgimp_texture_editor_status = f"Following {image.name}"
            self.report({"INFO"}, f"Texture Canvas: {image.name}")

        return {"FINISHED"}


class BLENDGIMP_OT_texture_editor_set_image(bpy.types.Operator):
    bl_idname = "blendgimp.texture_editor_set_image"
    bl_label = "Use BlendGimp Texture"

    image_id: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        image = _set_active_texture(context.scene, self.image_id)
        if image is None:
            self.report({"ERROR"}, "BlendGimp texture is no longer available")
            return {"CANCELLED"}

        context.scene.blendgimp_texture_editor_follow_active = False
        context.scene.blendgimp_texture_editor_status = f"Pinned to {image.name}"
        _sync_texture_workspace(context)
        return {"FINISHED"}


class BLENDGIMP_OT_texture_view_fit(bpy.types.Operator):
    bl_idname = "blendgimp.texture_view_fit"
    bl_label = "Fit"
    bl_description = "Fit the whole texture in the BlendGimp canvas"

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == "IMAGE_EDITOR"

    def execute(self, _context):
        bpy.ops.image.view_all(fit_view=True)
        return {"FINISHED"}


class BLENDGIMP_OT_texture_view_100(bpy.types.Operator):
    bl_idname = "blendgimp.texture_view_100"
    bl_label = "100%"
    bl_description = "Set texture canvas zoom to one image pixel per screen pixel"

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == "IMAGE_EDITOR"

    def execute(self, _context):
        bpy.ops.image.view_zoom_ratio(ratio=1.0)
        return {"FINISHED"}


# -----------------------------------------------------------------------------
# Panels
# -----------------------------------------------------------------------------


class BLENDGIMP_PT_texture_workspace_launcher(bpy.types.Panel):
    bl_label = "Texture Editor"
    bl_idname = "BLENDGIMP_PT_texture_workspace_launcher"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "BlendGimp"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.operator(
            "blendgimp.open_texture_workspace",
            text="Open Texture Editor",
            icon="IMAGE_DATA",
        )

        image = _find_blendgimp_image(scene.blendgimp_texture_editor_image_id)
        if image is not None:
            layout.label(text=image.name, icon="IMAGE_DATA")


class BLENDGIMP_PT_texture_editor(bpy.types.Panel):
    bl_label = "BlendGimp Texture Editor"
    bl_idname = "BLENDGIMP_PT_texture_editor"
    bl_space_type = "IMAGE_EDITOR"
    bl_region_type = "UI"
    bl_category = "BlendGimp"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        image = _find_blendgimp_image(scene.blendgimp_texture_editor_image_id)

        canvas_box = layout.box()
        canvas_box.label(text="Texture Canvas", icon="IMAGE_DATA")

        if image is None:
            canvas_box.label(text="No BlendGimp texture", icon="INFO")
        else:
            canvas_box.label(text=image.name)
            canvas_box.label(
                text=f"{image.size[0]} × {image.size[1]}  |  GIMP ID {scene.blendgimp_texture_editor_image_id}"
            )

        canvas_box.prop(
            scene,
            "blendgimp_texture_editor_follow_active",
            text="Follow Active Texture",
        )

        canvas_box.operator(
            "blendgimp.texture_editor_refresh",
            text="Refresh Active Texture",
            icon="FILE_REFRESH",
        )

        if not scene.blendgimp_texture_editor_follow_active:
            images = _blendgimp_images()
            if images:
                manual_box = canvas_box.box()
                manual_box.label(text="Available BlendGimp Textures")
                for image_id, candidate in images:
                    operator = manual_box.operator(
                        "blendgimp.texture_editor_set_image",
                        text=candidate.name,
                        depress=(image_id == scene.blendgimp_texture_editor_image_id),
                        icon="IMAGE_DATA",
                    )
                    operator.image_id = image_id

        nav_box = layout.box()
        nav_box.label(text="View", icon="VIEWZOOM")
        row = nav_box.row(align=True)
        row.operator("blendgimp.texture_view_fit", text="Fit")
        row.operator("blendgimp.texture_view_100", text="100%")
        nav_box.label(text="MMB: Pan   •   Wheel: Zoom")
        nav_box.label(text="RGBA checkerboard enabled")

        uv_box = layout.box()
        uv_box.label(text="UV Overlay", icon="UV")
        uv_box.prop(
            scene,
            "blendgimp_texture_editor_show_uv",
            text="Show UV Overlay",
        )

        controls = uv_box.column()
        controls.enabled = scene.blendgimp_texture_editor_show_uv
        controls.prop(
            scene,
            "blendgimp_texture_editor_uv_opacity",
            text="Opacity",
            slider=True,
        )
        controls.prop(
            scene,
            "blendgimp_texture_editor_show_islands",
            text="Show UV Islands",
        )
        controls.prop(
            scene,
            "blendgimp_texture_editor_active_face_highlight",
            text="Active Face Highlight",
        )

        obj = context.active_object
        if obj is None or obj.type != "MESH":
            uv_box.label(text="Select a mesh to display UVs", icon="INFO")
        elif len(obj.data.uv_layers) == 0:
            uv_box.label(text="Active mesh has no UV map", icon="ERROR")
        else:
            uv_layer = obj.data.uv_layers.active
            uv_box.label(
                text=f"UV Map: {uv_layer.name if uv_layer else '[None]'}"
            )
            if scene.blendgimp_texture_editor_active_face_highlight:
                uv_box.label(text="Face highlight follows Blender Edit Mode selection")

        if scene.blendgimp_texture_editor_status:
            status_box = layout.box()
            status_box.label(text=scene.blendgimp_texture_editor_status)


classes = (
    BLENDGIMP_OT_open_texture_workspace,
    BLENDGIMP_OT_texture_editor_refresh,
    BLENDGIMP_OT_texture_editor_set_image,
    BLENDGIMP_OT_texture_view_fit,
    BLENDGIMP_OT_texture_view_100,
    BLENDGIMP_PT_texture_workspace_launcher,
    BLENDGIMP_PT_texture_editor,
)


# -----------------------------------------------------------------------------
# Registration
# -----------------------------------------------------------------------------


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.blendgimp_texture_editor_image_id = bpy.props.IntProperty(
        name="Active BlendGimp Texture ID",
        default=-1,
        options={"SKIP_SAVE"},
    )

    bpy.types.Scene.blendgimp_texture_editor_image_name = bpy.props.StringProperty(
        name="Active BlendGimp Texture",
        default="",
        options={"SKIP_SAVE"},
    )

    bpy.types.Scene.blendgimp_texture_editor_follow_active = bpy.props.BoolProperty(
        name="Follow Active Texture",
        description=(
            "Automatically follow the image owned by BlendGimp Auto Sync, "
            "3D Paint Sync, direct paint, or the active material"
        ),
        default=True,
        update=_follow_property_update,
    )

    bpy.types.Scene.blendgimp_texture_editor_show_uv = bpy.props.BoolProperty(
        name="Show UV Overlay",
        default=True,
        update=_texture_editor_property_update,
    )

    bpy.types.Scene.blendgimp_texture_editor_uv_opacity = bpy.props.FloatProperty(
        name="UV Overlay Opacity",
        default=0.85,
        min=0.0,
        max=1.0,
        subtype="FACTOR",
        update=_texture_editor_property_update,
    )

    bpy.types.Scene.blendgimp_texture_editor_show_islands = bpy.props.BoolProperty(
        name="Show UV Islands",
        description="Show or hide the active mesh UV islands over the texture",
        default=True,
        update=_texture_editor_property_update,
    )

    bpy.types.Scene.blendgimp_texture_editor_active_face_highlight = bpy.props.BoolProperty(
        name="Active Face Highlight",
        description=(
            "Use Blender's native UV face fill so active/selected faces are "
            "highlighted while editing the mesh"
        ),
        default=True,
        update=_texture_editor_property_update,
    )

    bpy.types.Scene.blendgimp_texture_editor_status = bpy.props.StringProperty(
        name="Texture Editor Status",
        default="",
        options={"SKIP_SAVE"},
    )

    if not bpy.app.timers.is_registered(blendgimp_texture_editor_timer):
        bpy.app.timers.register(
            blendgimp_texture_editor_timer,
            first_interval=TEXTURE_EDITOR_POLL_INTERVAL,
            persistent=True,
        )

    print("BLENDGIMP: Phase 6.1 Texture Editor registered")


def unregister():
    try:
        if bpy.app.timers.is_registered(blendgimp_texture_editor_timer):
            bpy.app.timers.unregister(blendgimp_texture_editor_timer)
    except Exception:
        pass

    property_names = (
        "blendgimp_texture_editor_status",
        "blendgimp_texture_editor_active_face_highlight",
        "blendgimp_texture_editor_show_islands",
        "blendgimp_texture_editor_uv_opacity",
        "blendgimp_texture_editor_show_uv",
        "blendgimp_texture_editor_follow_active",
        "blendgimp_texture_editor_image_name",
        "blendgimp_texture_editor_image_id",
    )

    for property_name in property_names:
        if hasattr(bpy.types.Scene, property_name):
            delattr(bpy.types.Scene, property_name)

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass

    print("BLENDGIMP: Phase 6.1 Texture Editor unregistered")
